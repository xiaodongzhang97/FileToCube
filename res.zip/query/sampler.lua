local Gen = require("gen")
local Schema = require("schema")

sysbench.cmdline.options = {
    db_suffix = { "database suffix", "ex" }
}

local SAMPLE_POINTS = { 1, 10, 100, 1000, 5000 }
local _queries = {}
local _f = io.open("results", "w")
local _con

local function _process_result(_res)
    local _num_rows = _res.nrows
    local _ret = {}
    for _ = 1, _num_rows do
        local _row = _res:fetch_row()
        local _r = {}
        for j = 1, _res.nfields do
            if _row[j] == nil then
                table.insert(_r, " ")
            else
                table.insert(_r, _row[j])
            end
        end
        table.insert(_ret, table.concat(_r, "|"))
    end

    return table.concat(_ret, "\n")
end

local function _run_point(_point)
    print("sampling point " .. _point)
    local _results = {}
    for _, _query in pairs(_queries) do
        local _res = _query(_point)
        table.insert(_results, { _res[1], _res[2], _process_result(_res[3]) })
    end

    for _, _result_desc in ipairs(_results) do
        local _app = _result_desc[1]
        local _id = _result_desc[2]
        local _res = _result_desc[3]
        _f:write(string.format(">%d;%s;%d\n", _point, _app, _id))
        _f:write(_res)
        _f:write("\n")
    end
    _f:flush()

    _results = {}
    collectgarbage()
end

local function cmd_group()
    local _drv = sysbench.sql.driver()
    _con = _drv:connect()
    for _, _point in ipairs(SAMPLE_POINTS) do
        _run_point(_point)
    end
end

sysbench.cmdline.commands = {
    group = { cmd_group }
}

function _queries.sagan_42(_point)
  _con:query("use sagan_" .. sysbench.opt.db_suffix)

  local _app = "sagan"
  local _stmt_id = 42
  local _sql = [[
  SELECT SQL_CALC_FOUND_ROWS draft
  FROM post
  ]]
  local _params = Gen.gen_sample_params(_point, _app, {
  })
  local _formatted_sql = string.format(_sql, unpack(_params))
  local _res = _con:query(_formatted_sql)
  return { _app, _stmt_id, _res }
end

function _queries.sagan_43(_point)
  _con:query("use sagan_" .. sysbench.opt.db_suffix)

  local _app = "sagan"
  local _stmt_id = 43
  local _sql = [[
  SELECT SQL_CALC_FOUND_ROWS draft
  FROM post
  GROUP BY draft
  ]]
  local _params = Gen.gen_sample_params(_point, _app, {
  })
  local _formatted_sql = string.format(_sql, unpack(_params))
  local _res = _con:query(_formatted_sql)
  return { _app, _stmt_id, _res }
end

function _queries.sagan_44(_point)
  _con:query("use sagan_" .. sysbench.opt.db_suffix)

  local _app = "sagan"
  local _stmt_id = 44
  local _sql = [[
  SELECT draft
  FROM post
  ]]
  local _params = Gen.gen_sample_params(_point, _app, {
  })
  local _formatted_sql = string.format(_sql, unpack(_params))
  local _res = _con:query(_formatted_sql)
  return { _app, _stmt_id, _res }
end

