local Util = require("util")
local Prepare = require("prepare")
local Workload = require("workload")
local OptWorkload = require("opt_workload")

local Config = require("config")
local Runtime = require("runtime")
--local _inspect = require("inspect")

sysbench.cmdline.options = {
    run_opt = { "whether to run workload.lua or opt-workload.lua", false },
    marker = { "marker of current run", "baseline" }
}

-- cache global to local
local _rand_uniform_f = sysbench.rand.uniform

local _funcs_t = {}
local _drv
local _con

local function _init_conn()
    _drv = sysbench.sql.driver()
    _con = _drv:connect()
    _con:query("SET FOREIGN_KEY_CHECKS=0")
end

local function _cmd_prepare()
    _init_conn()
    Prepare.populate_tables(_con)
end

function init()
    os.execute("rm -rf .records.old > /dev/null")
    os.execute("mv .records .records.old > /dev/null")
    os.execute("mkdir .records > /dev/null")
end

function thread_init()
    _init_conn()

    local _reg
    if sysbench.opt.run_opt then
        Util.log("running opt_workload.lua!!!\n")
        _reg = OptWorkload.funcs
    else
        Util.log("running workload.lua!!!\n")
        _reg = Workload.funcs
    end

    for _, _f in pairs(_reg) do
        table.insert(_funcs_t, _f)
    end
    Util.log(#_funcs_t .. " stmts to run\n")
    -- _init_picked_apis()
    -- _init_runtime_info(tables, get_table_size)
end

function event()
    _funcs_t[_rand_uniform_f(1, #_funcs_t)](_con)
end

function thread_done(_thread_id)
    Runtime.dump_timing(Config.app_name, _thread_id)
end

function sysbench.hooks.report_cumulative(_stat)
    sysbench.report_default(_stat)

    local suffix
    if sysbench.opt.run_opt and sysbench.opt.marker == "baseline" then
        suffix = "opt"
    else
        suffix = sysbench.opt.marker
    end

    os.execute(string.format("cat .records/stmt.* > %s.%s.timing", Config.app_name, suffix))
    --os.execute("cat .records/stmt.* | python3 collect_records.py > stmt.timing")
    --os.execute("cat .records/txn.* | python3 collect_records.py > txn.timing")
end

function sysbench.hooks.sql_error_ignorable(_err)
    --_log("SQL error occurs: ", _inspect(_err))
    Util.log("SQL error occurs")
    return true -- mutable all errors
end

sysbench.cmdline.commands = {
    prepare = { _cmd_prepare }
}
