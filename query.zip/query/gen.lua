local Rand = require("rand")
local Schema = require("schema")

local function _get_col_desc(_table_name, _col_name, _dummy)
    return Schema.tables[_table_name][_col_name]
end

local function _get_app_col_desc_func(_app)
    return function(_table_name, _col_name, _dummy)
        return Schema.tables[_app][_table_name][_col_name]
    end
end

local function _gen_params(_params)
    return Rand.gen_params(_params, _get_col_desc)
end

local function _gen_sample_params(_point, _app, _params)
    return Rand.gen_sample_params(_point, _params, _get_app_col_desc_func(_app))
end

return {
    TOTAL_ROWS = Rand.TOTAL_ROWS,
    gen_col = Rand.gen_col,
    gen_params = _gen_params,
    gen_sample_params = _gen_sample_params
}
