local Util = require("util")
local Runtime = require("runtime")
local Gen = require("gen")

-- sec, nsec, id
local _txn_timer = { -1, -1 }
local _stmt_timer = { -1, -1 }

local _funcs = {}

-- stmt 42
function _funcs._stmt_42(_con)
  local _sql = [[
  SELECT SQL_CALC_FOUND_ROWS draft
  FROM post
  ]]
  local _params = Gen.gen_params({
  })
  local _formatted_sql = string.format(_sql, unpack(_params))

  Util.timing_start(_stmt_timer)
    local _res = _con:query(_formatted_sql)
  Runtime.record_timing(0, 42, Util.timing_end(_stmt_timer))
  Runtime.record_params_and_result(_params, _res)
  _res = nil
  collectgarbage()
end

-- stmt 43
function _funcs._stmt_43(_con)
  local _sql = [[
  SELECT SQL_CALC_FOUND_ROWS draft
  FROM post
  GROUP BY draft
  ]]
  local _params = Gen.gen_params({
  })
  local _formatted_sql = string.format(_sql, unpack(_params))

  Util.timing_start(_stmt_timer)
    local _res = _con:query(_formatted_sql)
  Runtime.record_timing(0, 43, Util.timing_end(_stmt_timer))
  Runtime.record_params_and_result(_params, _res)
  _res = nil
  collectgarbage()
end

-- stmt 44
function _funcs._stmt_44(_con)
  local _sql = [[
  SELECT draft
  FROM post
  ]]
  local _params = Gen.gen_params({
  })
  local _formatted_sql = string.format(_sql, unpack(_params))

  Util.timing_start(_stmt_timer)
    local _res = _con:query(_formatted_sql)
  Runtime.record_timing(0, 44, Util.timing_end(_stmt_timer))
  Runtime.record_params_and_result(_params, _res)
  _res = nil
  collectgarbage()
end

return { funcs = _funcs }