local _app_name = "query"
return {
	app_name = _app_name
}
