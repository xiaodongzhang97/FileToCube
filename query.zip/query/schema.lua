local _tables = {
["sagan"] = {
  ["schema_version"] = {
    ["version_rank"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["installed_rank"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["version"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 50, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 200, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 20, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = true,
      refers_to = {}
    },
    ["script"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 1000, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["checksum"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["installed_by"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 100, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["installed_on"] = {
      ordinal = 9,
      data_type = {"datetime_like", "timestamp", -1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["execution_time"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["success"] = {
      ordinal = 11,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
  },
  ["project_repository"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["url"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["snapshots_enabled"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
  },
  ["project_sample_list"] = {
    ["title"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["url"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["display_order"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["project_id"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["post"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["broadcast"] = {
      ordinal = 2,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
    ["category"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "timestamp", -1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["draft"] = {
      ordinal = 5,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
    ["format"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["public_slug"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["publish_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "timestamp", -1, -1},
      is_indexed = true, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["raw_content"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["rendered_content"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["rendered_summary"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["title"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["author_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["member_profile"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["avatar_url"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["bio"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["latitude"] = {
      ordinal = 4,
      data_type = {"decimal", "double", -1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["longitude"] = {
      ordinal = 5,
      data_type = {"decimal", "double", -1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["github_id"] = {
      ordinal = 6,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["github_username"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["gravatar_email"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["hidden"] = {
      ordinal = 9,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
    ["lanyrd_username"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["location"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["speakerdeck_username"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["twitter_username"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["username"] = {
      ordinal = 15,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["video_embeds"] = {
      ordinal = 16,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["job_title"] = {
      ordinal = 17,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spring_tools_platform_downloads"] = {
    ["spring_tools_platform_id"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["download_url"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["label"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["project"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["repo_url"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["category"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["site_url"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stack_overflow_tags"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["raw_boot_config"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["rendered_boot_config"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["raw_overview"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["rendered_overview"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["parent_project_id"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["display_order"] = {
      ordinal = 12,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["post_public_slug_aliases"] = {
    ["post_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["public_slug_aliases"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["project_release_list"] = {
    ["project_id"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["repository_id"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["api_doc_url"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["artifact_id"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["group_id"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["is_current"] = {
      ordinal = 6,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = true, is_enum = false,
      refers_to = {}
    },
    ["ref_doc_url"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["release_status"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = true,
      refers_to = {}
    },
    ["version_name"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_primary_key = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spring_tools_platform"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_primary_key = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
},
}

return { tables = _tables }