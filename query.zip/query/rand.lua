local _TOTAL_ROWS = 10000
local _NUM_ENUMS = 8
local _string_enum_0 = { "00", "01", "10", "11" }
local _string_enum_1 = { "000", "001", "010", "011", "100", "101", "110", "111" }
local _limit_offset_values = { 0, 2000, 4000, 6000, 800 }

local _datetime_start = { 2010, 1, 1, 0, 0, 0, 0 }
local _datetime_end = { 2030, 12, 31, 23, 59, 59, 999 }
local _datetime_format = "'%d-%02d-%02d %02d.%02d.%02d.%d'"

local _random_string = "Lorem ipsum dolor sit amet, ex eos munere interesset, id ferri doming eum, id veri singulis contentiones has. Pro veri mollis debitis te, eos cu appareat disputando, his legere libris animal cu. In epicurei perfecto qui, eu purto deseruisse eos. Ea suas efficiantur mea, appareat maluisset reformidans usu ea. Vidit nostro eos et, vis agam vidit inermis no, munere appareat nam id.Zril vituperata vim ei, veri nihil verear et mea, soluta essent delenit cu duo. Altera euripidis eu est. Id vel etiam dolorum salutandi. Veri qualisque similique vix ea, eum accusata antiopam deterruisset id, ea est quas dolor.Congue soluta putent et eam. Mel congue oblique apeirian ne, qui te exerci legendos lobortis, eum accusamus definitionem ut. An causae iriure inermis vim. Legimus democritum vel ex, te idque nihil nam. Usu ut tamquam sanctus voluptaria. Movet utamur ceteros id vel. Ex essent fabulas per, paulo liberavisse no vim.Sed te brute idque omnes, ei feugait salutandi his. Possit denique explicari has ad, an mea brute audire convenire, at nibh salutatus ius. An his sale fugit theophrastus, vis eu novum omnesque tincidunt. His ei vidisse ocurreret. Vocent laoreet delectus ex vix, ne vidisse accusam sea.No eam alterum docendi. Quo nullam debitis eu. Pro ei vitae pertinacia temporibus, eius comprehensam no mel. Libris hendrerit disputando ut pro."
local _random_string_len = string.len(_random_string)
local _tokens = {}
for _token in _random_string:gmatch("[a-zA-Z]+") do
    table.insert(_tokens, _token)
end

function table.isempty(t)
    if next(t) == nil then
        return true
    end
    return false
end

local function _rand_seed(_seed)
    math.randomseed(_seed)
end

-- forward the random generator by n step
local function _rand_forward(_n)
    for _ = 1, _n do
        math.random()
    end
end

local function _rand_int(_a, _b)
    local _lower, _upper
    if _b == nil then
        _lower = 0
        _upper = _a
    else
        _lower = _a
        _upper = _b
    end

    return math.random(_a, _b)
end

local function _rand_decimal(_a, _b)
    local _lower, _upper
    if _b == nil then
        _lower = 0
        _upper = _a
    else
        _lower = _a
        _upper = _b
    end
    return (math.random() * (_upper - _lower)) + _lower
end

local function _datetime_to_str(_datetime)
    return string.format(_datetime_format, _datetime[1], _datetime[2], _datetime[3], _datetime[4], _datetime[5], _datetime[6], _datetime[7])
end

local function _datetime_to_int(_datetime)
    return os.time({ year = _datetime[1], month = _datetime[2], day = _datetime[3], hour = _datetime[4], min = _datetime[5], sec = _datetime[6] })
end

local function _int_to_datetime(_i)
    local _date = os.date("*t", _i)
    return { _date.year, _date.month, _date.day, _date.hour, _date.min, _date.sec, 0 }
end

local function _rand_datetime(_start, _end)
    local _start_time = _datetime_to_int(_start)
    local _end_time = _datetime_to_int(_end)
    local _ret = _int_to_datetime(_rand_int(_start_time, _end_time - 1))
    _ret[7] = _rand_int(0, 999)
    return _ret
end

local function _rand_datetime_str()
    return _datetime_to_str(_rand_datetime(_datetime_start, _datetime_end))
end

local function _rand_str(_len)
    local _idx_start = _rand_int(1, _random_string_len - _len + 1)
    local _idx_end = _idx_start + _len - 1
    return string.sub(_random_string, _idx_start, _idx_end)
end

local function _range_of(_type, _width, _precision)
    if _type == "bit" then
        return 0, bit.lshift(1, _width - 1)
    elseif _type == "tinyint" then
        return 0, 127
    elseif _type == "smallint" then
        return 0, 32767
    elseif _type == "mediumint" then
        return 0, 8388607
    elseif _type == "int" or _type == "integer" or _type == "bigint" then
        return 0, 2147483647
    elseif _type == "float" or _type == "decimal" or _type == "double" or _type == "numeric" then
        _width = math.min(_width - _precision, 8)
        local _limit = math.pow(10, _width) - 1
        return 0, _limit
    else
        return 0, 0
    end
end

local function _gen_primary_key(_table_name, _col_name, _data_type, _line_num)
    local _category = _data_type[1]
    if _category == "integral" then
        return _line_num
    elseif _category == "string_like" then
        return string.format("\'%05d\'", _line_num)
    else
        io.stderr:write(string.format("unhandled type in _gen_primary_key - %s.%s:%s %s\n",
                _table_name,
                _col_name,
                _category,
                _data_type[2]))
        return "NULL"
    end
end

local function _gen_unique_val(_table_name, _col_name, _data_type, _line_num)
    local _category = _data_type[1]
    local _type = _data_type[2]
    local _width = _data_type[3]
    local _precision = _data_type[4]

    if _category == "integral" then
        local _, _upper = _range_of(_type, _width, _precision)

        if _upper < _TOTAL_ROWS then
            io.stderr:write("cannot force uniqueness\n")
        end

        local _factor = math.floor(_upper / _TOTAL_ROWS)
        return (_rand_int(1, _factor) - 1) * _TOTAL_ROWS + _line_num

    elseif _category == "string_like" then
        if _width == -1 or _width > 20 then
            _width = 20
        end

        _width = _width - 5

        return "\"" .. _rand_str(_width) .. string.format("%05d", _line_num) .. "\""

    else
        io.stderr:write(string.format("unhandled type in _gen_unique_val - %s.%s:%s %s\n",
                _table_name,
                _col_name,
                _category,
                _data_type[2]))
        return "NULL"
    end
end

local function _gen_rand_val(_table_name, _col_name, _col_desc)
    local _is_boolean = _col_desc.is_boolean
    local _is_enum = _col_desc.is_enum
    local _is_fk = not table.isempty(_col_desc.refers_to)
    local _data_type = _col_desc.data_type

    local _category = _data_type[1]
    local _type = _data_type[2]
    local _width = _data_type[3]
    local _precision = _data_type[4]

    if _category == "integral" then
        local _lower, _upper

        if _is_boolean then
            _lower, _upper = 0, 1
        elseif _is_enum then
            _lower, _upper = 1, _NUM_ENUMS
        elseif _is_fk then
            _lower, _upper = 1, 10000
        else
            _lower, _upper = _range_of(_type, _width, _precision)
        end

        return _rand_int(_lower, _upper)

    elseif _category == "decimal" then
        local _lower, _upper = _range_of(_type, _width, _precision)

        if _is_boolean or _is_enum or _is_fk then
            io.stderr:write(string.format("unhandled boolean/enum/fk of a decimal column: %s.%s\n", _table_name, _col_name))
        end

        return _rand_decimal(_lower, _upper)

    elseif _category == "string_like" then
        if _is_boolean then
            if _rand_int(0, 1) == 1 then
                return "\'Y\'"
            else
                return "\'N\'"
            end
        elseif _is_enum then
            if _width < 3 then
                return "\'" .. _string_enum_0[_rand_int(1, 4)] .. "\'"
            else
                return "\'" .. _string_enum_1[_rand_int(1, 8)] .. "\'"
            end
        elseif _is_fk then
            return string.format("\'%05d\'", _rand_int(1, _TOTAL_ROWS))
        else
            if _width == -1 or _width > 20 then
                _width = 20
            end

            return "\"" .. _rand_str(_width) .. "\""
        end

    elseif _category == "datetime_like" then
        return _rand_datetime_str()
    elseif _category == "lob" then
        return string.format("0x%x", _rand_int(1, 65536))
    else
        io.stderr:write(string.format("unhandled type in _gen_unique_val - %s.%s:%s %s\n",
                _table_name,
                _col_name,
                _category,
                _data_type[2]))
        return "NULL"
    end
end

local INT_MAX = 2147483647
local INT_MIN = -2147483648

local function _str_hash(_str)
    local _hash = 0
    for _i = 1, string.len(_str) do
        _hash = _hash * 31 + string.byte(_str, _i)
        while _hash > INT_MAX do
            _hash = _hash - INT_MAX + INT_MIN
        end
        while _hash < INT_MIN do
            _hash = _hash - INT_MIN + INT_MAX
        end
    end
    return _hash
end

local function _get_seed(_table_name, _col_name, _row_num)
    return _str_hash(_table_name .. _col_name) + _row_num
end

local function _gen_col_data(_for_population, _table_name, _col_name, _col_desc, _row_num)
    -- Deterministically generate value based on column and row number

    -- 1. for auto_increment column, just return NULL
    if _col_desc.is_auto_increment then
        if _for_population then
            return "NULL"
        else
            return _row_num
        end
    end

    -- 2. set random seed as _row_num
    _rand_seed(_get_seed(_table_name, _col_name, _row_num))
    -- 3. for the random gen by (_col_desc.ordinal * 2) steps
    _rand_forward(_col_desc.ordinal * 3)

    -- 4. for nullable column, return NULL at 5% probability
    if not _col_desc.is_not_null then
        if _rand_int(1, 99) < 5 then
            return "NULL"
        end
    end

    local _data_type = _col_desc.data_type

    if _col_desc.is_primary_key then
        return _gen_primary_key(_table_name, _col_name, _data_type, _row_num)
    elseif _col_desc.is_unique then
        return _gen_unique_val(_table_name, _col_name, _data_type, _row_num)
    else
        return _gen_rand_val(_table_name, _col_name, _col_desc)
    end

end

local function _is_on_same_table(_params)
    local _seen

    for _, _param in ipairs(_params) do
        local _table = _param[3]
        if _table ~= "" then
            if _seen ~= nil and _seen ~= _table then
                return false
            else
                _seen = _table
            end
        end
    end

    return true
end

local function _gen_limit_offset()
    return _limit_offset_values[_rand_int(1, #_limit_offset_values)]
end

local function _gen_token()
    return _tokens[_rand_int(1, #_tokens)]
end

local function _gen_rand_val_of_type(_data_type)
    local _category = _data_type[1]
    local _type = _data_type[2]
    local _width = _data_type[3]
    local _precision = _data_type[4]

    if _category == "integral" then
        local _lower, _upper = _range_of(_type, _width, _precision)
        return _rand_int(_lower, _upper)

    elseif _category == "decimal" then
        local _lower, _upper = _range_of(_type, _width, _precision)
        return _rand_decimal(_lower, _upper)

    elseif _category == "string_like" then
        if _width == -1 or _width > 20 then
            _width = 20
        end

        return "\"" .. _rand_str(_width) .. "\""

    elseif _category == "datetime_like" then
        return _rand_datetime_str()
    elseif _category == "lob" then
        return string.format("0x%x", _rand_int(1, 65536))
    else
        io.stderr:write(string.format("unhandled type in _gen_unique_val - %s.%s:%s %s\n",
                _table_name,
                _col_name,
                _category,
                _data_type[2]))
        return "NULL"
    end

end

-- param: {
--   [1] = api,
--   [2] = sql,
--   [3] = table_name,
--   [4] = col_name
--   [5] = {
--     [1] = stmt_type, [2] = clause, [3] = position, [4] = prefixed_wildcard
--   },
--   [6] = guessed_data_type,
--   [7] = col_desc (only available in verifier)
-- }
local function _gen_params(_params, _get_col_desc_f)
    local _ret = {}
    local _on_same_table = _is_on_same_table(_params)
    local _row_num = _rand_int(1, _TOTAL_ROWS)
    local _val

    for _, _param in ipairs(_params) do
        local _table = _param[3]
        local _col = _param[4]
        local _param_position = _param[5]
        local _guessed_data_type = _param[6]

        local _clause = _param_position[2]
        local _wildcard_type = _param_position[4]

        if _clause == "limit" then
            _val = _gen_limit_offset()
        elseif _clause == "match_against" then
            _val = _gen_token()
        elseif _table == "" then
            _val = _gen_rand_val_of_type(_guessed_data_type)
        else
            local _col_desc = _get_col_desc_f(_table, _col, _param)
            if _col_desc == nil then
                _val = "NULL"
                io.stderr:write("unknown column: " .. _table .. "." .. _col .. "\n")
            elseif _on_same_table then
                _val = _gen_col_data(false, _table, _col, _col_desc, _row_num)
            else
                _val = _gen_col_data(false, _table, _col, _col_desc, _rand_int(1, _TOTAL_ROWS))
            end
        end

        if _wildcard_type ~= 0 then
            _val = string.sub(_val, 2, -2)
            if _wildcard_type == 1 then
                _val = "\"" .. _val .. "%\""
            elseif _wildcard_type == 2 then
                _val = "\"%" .. _val .. "\""
            elseif _wildcard_type == 3 then
                _val = "\"%" .. _val .. "%\""
            end
        end

        if _param_position == "regexp" then
            _val = string.sub(_val, 1, -2) .. ".*\""
        end

        table.insert(_ret, _val)
    end

    return _ret
end

local function _get_col_desc_from_param_desc(_table_name, _col_name, _param_desc)
    return _param_desc[7]
end

local function _gen_params_for_verifier(_params)
    return _gen_params(_params, _get_col_desc_from_param_desc)
end

local function _gen_col_data_1(_for_population, _table_name, _col_name, _col_desc, _row_num)
    if _col_desc.is_auto_increment then
        if _for_population then
            return "NULL"
        else
            return _row_num
        end
    end

    local _data_type = _col_desc.data_type
    local _category = _data_type[1]
    local _type = _data_type[2]
    local _width = _data_type[3]
    local _precision = _data_type[4]

    local _is_fk = not table.isempty(_col_desc.refers_to)
    local _is_boolean = _col_desc.is_boolean or _type == "bit"
    local _is_enum = _col_desc.is_enum
    local _is_unique = _col_desc.is_unique

    if _category == "integral" then
        if _is_boolean or _type == "bit" then
            return _row_num % 2
        elseif _is_enum then
            return _row_num % 8
        elseif _is_unique then
            return _row_num
        elseif _is_fk then
            _rand_seed(_row_num)
            return _rand_int(1, 10000)
        else
            _rand_seed(_row_num)
            _rand_forward(1)
            return _rand_int(1, 100)
        end

    elseif _category == "decimal" then
        if _width - _precision >= 5 then
            return _row_num
        else
            return _row_num % 100 -- sloppy
        end

    elseif _category == "string_like" then
        if _is_boolean then
            return string.format("\'%d\'", _row_num % 2)
        elseif _is_enum then
            return string.format("\'%d\'", _row_num % 8)
        elseif _is_unique then
            return string.format("\'%d\'", _row_num)
        elseif _is_fk then
            _rand_seed(_row_num)
            _rand_forward(2)
            return string.format("\'%d\'", _rand_int(1, 10000))
        else
            _rand_seed(_row_num)
            _rand_forward(3)
            return string.format("\'%d\'", _rand_int(1, 200))
        end

    elseif _category == "datetime_like" then
        _rand_seed(_row_num)
        _rand_forward(4)
        local _ret = _int_to_datetime(_datetime_to_int(_datetime_start) + _rand_int(1, 300))
        return _datetime_to_str(_ret)

    elseif _category == "lob" then
        return string.format("0x%x", _row_num)

    else
        io.stderr:write(string.format("unhandled type in _gen_unique_val - %s.%s:%s %s\n",
                _table_name,
                _col_name,
                _category,
                _data_type[2]))
        return "NULL"
    end
end

local function _gen_sample_params(_point, _params, _get_col_desc_f)
    local _ret = {}
    local _val

    for _, _param in ipairs(_params) do
        local _table = _param[3]
        local _col = _param[4]
        local _param_position = _param[5]

        local _clause = _param_position[2]
        local _wildcard_type = _param_position[4]

        if _clause == "limit" then
            _val = 17
        elseif _table == "" then
            _val = _point
        else
            local _col_desc = _get_col_desc_f(_table, _col, _param)
            if _col_desc == nil then
                _val = "NULL"
                io.stderr:write("unknown column: " .. _table .. "." .. _col .. "\n")
            else
                _val = _gen_col_data_1(false, _table, _col, _col_desc, _point)
            end
        end

        if _wildcard_type ~= 0 then
            _val = string.sub(_val, 2, -2)
            if _wildcard_type == 1 then
                _val = "\"" .. _val .. "%\""
            elseif _wildcard_type == 2 then
                _val = "\"%" .. _val .. "\""
            elseif _wildcard_type == 3 then
                _val = "\"%" .. _val .. "%\""
            end
        end

        if _param_position == "regexp" then
            _val = string.sub(_val, 1, -2) .. ".*\""
        end

        table.insert(_ret, _val)
    end

    return _ret
end

return {
    TOTAL_ROWS = _TOTAL_ROWS,
    gen_col = _gen_col_data_1,
    gen_params = _gen_params,
    gen_params_for_verifier = _gen_params_for_verifier,
    gen_sample_params = _gen_sample_params
}
