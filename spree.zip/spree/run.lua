local Util = require("util")
local Prepare = require("prepare")
local Exec = require("exec")
local Runtime = require("runtime")

sysbench.cmdline.options = {
    app = { "app name" },
    workload = { "workload name", "baseline" },
    tag = { "tag of current run", "baseline" },
}

-- cache global to local
local _rand_uniform_f = sysbench.rand.uniform
local SAMPLE_POINTS = { 57, 723, 3251, 5314, 8269 }

local _drv
local _con

local BLACKLIST_STMT = { 52, 53, 93, 96, 97, 101, 102, 103 }

local function _init_conn()
    _drv = sysbench.sql.driver()
    _con = _drv:connect()
    if sysbench.opt.db_driver ~= "pgsql" then
        _con:query("SET FOREIGN_KEY_CHECKS=0")
        _con:query("SET UNIQUE_CHECKS=0")
    end
end

local function _process_result(_res)
    local _num_rows = _res.nrows
    local _ret = {}
    for _ = 1, _num_rows do
        local _row = _res:fetch_row()
        local _r = {}
        for j = 1, _res.nfields do
            if _row[j] == nil then
                table.insert(_r, " ")
            else
                table.insert(_r, _row[j])
            end
        end
        table.insert(_ret, table.concat(_r, "|"))
    end

    return table.concat(_ret, "\n")
end

local function _cmd_prepare()
    _init_conn()
    Prepare.populate_tables(_con)
end

local function _is_blacklist(_stmt_desc)
    if _stmt_desc.app ~= "febs" or sysbench.opt.workload ~= "baseline" then
        return false
    end
    for _, _id in ipairs(BLACKLIST_STMT) do
        if _id == _stmt_desc.stmt_id then
            return true
        end
    end
    return false
end

local function _find_stmt(_workload, _stmt_id)
    for _, _stmt_desc in ipairs(_workload) do
        if _stmt_desc.stmt_id == _stmt_id then
            return _stmt_desc
        end
    end
    return nil
end

local function _cmd_profile()
    _init_conn()

    local _workload_name
    if sysbench.opt.workload == "baseline" then
        _workload_name = "workload"
    else
        _workload_name = sysbench.opt.workload .. "_workload"
    end
    Util.log(string.format("[Profile] loading from %s.lua\n", _workload_name))

    local _stmts = require(_workload_name)
    Util.log(string.format("[Profile] %d stmts to run\n", #_stmts))

    for _i = 1, (#_stmts * 100) do
        local _stmt_desc = _stmts[_rand_uniform_f(1, #_stmts)]
        if (_i / #_stmts) % 10 == 0 then
            Util.log(".")
        end
        if not _is_blacklist(_stmt_desc) then
            Exec.execute(_con, _stmt_desc)
            collectgarbage()
        end
    end

    if sysbench.opt.app == "febs" and sysbench.opt.workload == "baseline" then
        Util.log("\n[Profile] Running blacklist in febs ")
    end

    for _, _stmt_id in ipairs(BLACKLIST_STMT) do
        local _stmt_desc = _find_stmt(_stmts, _stmt_id)
        if _stmt_desc ~= nil then
            Util.log(".")
            for _ = 1, 3 do
                Exec.execute(_con, _stmt_desc)
                collectgarbage()
            end
        end
    end

    Util.log(" done\n")
    Runtime.dump_timing(sysbench.opt.app, 0)
end

local function _cmd_sample()
    _init_conn()
    local _f = io.open(sysbench.opt.app .. ".sample", "w")
    local _stmts = require("workload")

    for _, _point in ipairs(SAMPLE_POINTS) do
        Util.log("[Sample] sampling point " .. _point .. "\n")

        local _results = {}
        for _, _stmt_desc in ipairs(_stmts) do
            local _app = _stmt_desc.app
            local _stmt_id = _stmt_desc.stmt_id
            local _res = Exec.execute(_con, _stmt_desc, _point)
            table.insert(_results, { _app, _stmt_id, _process_result(_res) })
        end

        for _, _result_desc in ipairs(_results) do
            local _app = _result_desc[1]
            local _stmt_id = _result_desc[2]
            local _res = _result_desc[3]
            _f:write(string.format(">%d;%s;%d\n", _point, _app, _stmt_id))
            _f:write(_res)
            _f:write("\n")
        end
        _f:flush()

        _results = {}
        collectgarbage()
    end
end

function init()
    os.execute("rm -rf .records.old > /dev/null")
    os.execute("mv .records .records.old > /dev/null")
    os.execute("mkdir .records > /dev/null")
end

function sysbench.hooks.report_cumulative(_stat)
    sysbench.report_default(_stat)
    os.execute(string.format("cat .records/stmt.* > %s.%s.timing", sysbench.opt.app, sysbench.opt.tag))
    --os.execute("cat .records/stmt.* | python3 collect_records.py > stmt.timing")
    --os.execute("cat .records/txn.* | python3 collect_records.py > txn.timing")
end

function sysbench.hooks.sql_error_ignorable(_err)
    --_log("SQL error occurs: ", _inspect(_err))
    Util.log("SQL error occurs")
    return true -- mutable all errors
end

sysbench.cmdline.commands = {
    prepare = { _cmd_prepare },
    profile = { _cmd_profile },
    sample = { _cmd_sample }
}
