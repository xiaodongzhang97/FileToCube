local Util = require("util")

local TOTAL_ROWS = 10000
local NUM_ENUMS = 8

local function _get_forward_step(_col_desc)
    local _data_type = _col_desc.data_type
    local _type_category = _data_type and _data_type[1]
    local _type_name = _data_type and _data_type[2]
    local _is_fk = not table.isempty(_col_desc.refers_to)
    local _is_boolean = _col_desc.is_boolean
    local _is_enum = _col_desc.is_enum

    if _is_fk then
        return 1
    elseif _is_boolean or _type_name == "bit" then
        return 2
    elseif _is_enum then
        return 3
    elseif _type_category == "integral" then
        return 4
    elseif _type_category == "string_like" then
        return 5
    elseif _type_category == "datetime_like" then
        return 6
    else
        return 7
    end
end

local function _get_raw_at(_row_num, _forward_step)
    Util.rand_seed(_row_num)
    Util.rand_forward(_forward_step)
    return Util.rand_int(1, TOTAL_ROWS)
end

local function _get_seed_at(_row_num, _col_desc)
    local _raw_val = _get_raw_at(_row_num, _get_forward_step(_col_desc))

    local _data_type = _col_desc.data_type
    local _type_category = _data_type and _data_type[1]
    local _type_name = _data_type and _data_type[2]
    local _is_fk = not table.isempty(_col_desc.refers_to)
    local _is_pk = _col_desc.is_pk
    local _is_pk_part = _col_desc.is_pk_part
    local _is_unique = _col_desc.is_unique
    local _is_boolean = _col_desc.is_boolean or _type_name == "bit" or _type_category == "boolean"
    local _is_enum = _col_desc.is_enum

    if _is_pk or (_is_pk_part and _is_fk) or _is_unique then
        return _row_num
    elseif _is_fk then
        return _raw_val
    elseif _is_boolean then
        return _raw_val % 2
    elseif _is_enum then
        return _raw_val % NUM_ENUMS
    elseif _type_category == "integral" or _type_category == "decimal" then
        return _raw_val % 100
    elseif _type_category == "string_like" or _type_category == "datetime_like" then
        return _raw_val % 200
    else
        return _raw_val
    end
end

local function _convert_type(_val, _data_type)
    local _type_category = _data_type[1]

    if _type_category == "integral" or _type_category == "decimal" then
        return _val

    elseif _type_category == "string_like" then
        return string.format("\'%d\'", _val)

    elseif _type_category == "datetime_like" then
        local _ret = Util.datetime_to_str(Util.int_to_datetime(Util.base_datetime() + 43200 * (_val - 100)))
        if sysbench.opt.db_driver == "pgsql" then
            _ret = _ret .. "::timestamp"
        end
        return _ret

    elseif _type_category == "boolean" then
        if _val == 0 then
            return "FALSE"
        else
            return "TRUE"
        end

    elseif _type_category == "lob" then
        return string.format("0x%x", _val)

    elseif _type_category == "json" then
        return "'{}'::json"
    elseif _type_category == "tsvector" then
        return "'hello world'::tsvector"
    elseif _type_category == "inet" then
        return "'127.0.0.1'::inet"
    elseif _type_category == "uuid" then
        -- https://stackoverflow.com/questions/12505158/generating-a-uuid-in-postgres-for-insert-statement
        return "uuid_in(md5(random()::text || clock_timestamp()::text)::cstring)"
    elseif _type_category == "bytea" then
        return "''::bytea"
    else
        return nil
    end
end

local function _get_val_at(_row_num, _col_desc)
    return _convert_type(_get_seed_at(_row_num, _col_desc), _col_desc.data_type)
end

local function _get_ref_val_at(_row_num)
    return _get_raw_at(_row_num, 1)
end

return {
    TOTAL_ROWS = TOTAL_ROWS,
    convert_type = _convert_type,
    get_seed_at = _get_seed_at,
    get_ref_at = _get_ref_val_at,
    get_val_at = _get_val_at
}