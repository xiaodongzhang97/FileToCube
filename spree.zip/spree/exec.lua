local Gen = require("arggen")
local Util = require("util")
local Runtime = require("runtime")

local function _execute(_con, _stmt_desc, _primary_row_num)
    local _for_sampling = _primary_row_num ~= nil

    local _stmt_id = _stmt_desc.stmt_id
    local _sql = _stmt_desc.sql
    local _params = _stmt_desc.params

    local _args = Gen.gen_args(_params, _primary_row_num)
    local _formatted_sql = string.format(_sql, unpack(_args))

    local _start
    if not _for_sampling then
        _start = Util.timing_start()
    end

    local _res = _con:query(_formatted_sql)

    if not _for_sampling then
        Runtime.record_timing(0, _stmt_id, Util.timing_end(_start))
    end

    return _res
end

return {
    execute = _execute
}
