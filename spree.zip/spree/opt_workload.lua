local _stmts = {}
-- stmt 1
table.insert(_stmts, {
  app = "spree", stmt_id = 1,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`number` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 2
table.insert(_stmts, {
  app = "spree", stmt_id = 2,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`numcode` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "numcode", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 3
table.insert(_stmts, {
  app = "spree", stmt_id = 3,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stores`
  WHERE `spree_stores`.`default` = %s
  ]],
  params = {
    {table = "spree_stores", col = "default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 4
table.insert(_stmts, {
  app = "spree", stmt_id = 4,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  ORDER BY `spree_shipping_categories`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 5
table.insert(_stmts, {
  app = "spree", stmt_id = 5,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  ORDER BY `spree_tax_categories`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 6
table.insert(_stmts, {
  app = "spree", stmt_id = 6,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ORDER BY `spree_countries`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 7
table.insert(_stmts, {
  app = "spree", stmt_id = 7,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ORDER BY `spree_states`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 8
table.insert(_stmts, {
  app = "spree", stmt_id = 8,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  ORDER BY `spree_variants`.`id` ASC
  LIMIT 1000
  ]],
  params = {
  }
})

-- stmt 9
table.insert(_stmts, {
  app = "spree", stmt_id = 9,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`position` IS NOT NULL
  ORDER BY `spree_variants`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 10
table.insert(_stmts, {
  app = "spree", stmt_id = 10,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 11
table.insert(_stmts, {
  app = "spree", stmt_id = 11,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 12
table.insert(_stmts, {
  app = "spree", stmt_id = 12,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`propagate_all_variants` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "propagate_all_variants", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 13
table.insert(_stmts, {
  app = "spree", stmt_id = 13,
  sql = [[
  SELECT `friendly_id_slugs`.`id` AS _friendly_id_slugs_id
  FROM `friendly_id_slugs`
  WHERE `friendly_id_slugs`.`deleted_at` IS NULL
  	AND `friendly_id_slugs`.`sluggable_id` = %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 14
table.insert(_stmts, {
  app = "spree", stmt_id = 14,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 15
table.insert(_stmts, {
  app = "spree", stmt_id = 15,
  sql = [[
  SELECT SUM(`spree_stock_items`.`count_on_hand`)
  FROM `spree_stock_items`
  	INNER JOIN `spree_stock_locations` ON `spree_stock_locations`.`id` = `spree_stock_items`.`stock_location_id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_locations`.`active` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 16
table.insert(_stmts, {
  app = "spree", stmt_id = 16,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  	INNER JOIN `spree_stock_locations` ON `spree_stock_locations`.`id` = `spree_stock_items`.`stock_location_id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_locations`.`active` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 17
table.insert(_stmts, {
  app = "spree", stmt_id = 17,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id, `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zones`
  	LEFT JOIN `spree_zone_members` ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  WHERE (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = %s)
  	OR (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = %s)
  ORDER BY spree_zones.zone_members_count, spree_zones.created_at
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 18
table.insert(_stmts, {
  app = "spree", stmt_id = 18,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`default_tax` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_zones", col = "default_tax", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 19
table.insert(_stmts, {
  app = "spree", stmt_id = 19,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 20
table.insert(_stmts, {
  app = "spree", stmt_id = 20,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` NOT IN (%s)
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 21
table.insert(_stmts, {
  app = "spree", stmt_id = 21,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 22
table.insert(_stmts, {
  app = "spree", stmt_id = 22,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY amount ASC, created_at DESC, id DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 23
table.insert(_stmts, {
  app = "spree", stmt_id = 23,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`included` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "included", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 24
table.insert(_stmts, {
  app = "spree", stmt_id = 24,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 25
table.insert(_stmts, {
  app = "spree", stmt_id = 25,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = %s
  ]],
  params = {
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 26
table.insert(_stmts, {
  app = "spree", stmt_id = 26,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 27
table.insert(_stmts, {
  app = "spree", stmt_id = 27,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_zones", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 28
table.insert(_stmts, {
  app = "spree", stmt_id = 28,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ]],
  params = {
  }
})

-- stmt 29
table.insert(_stmts, {
  app = "spree", stmt_id = 29,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND `spree_zone_members`.`zoneable_type` IS NOT NULL
  ORDER BY created_at ASC
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 30
table.insert(_stmts, {
  app = "spree", stmt_id = 30,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND (zoneable_id IS NULL
  		OR zoneable_type != %s)
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 31
table.insert(_stmts, {
  app = "spree", stmt_id = 31,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 32
table.insert(_stmts, {
  app = "spree", stmt_id = 32,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 33
table.insert(_stmts, {
  app = "spree", stmt_id = 33,
  sql = [[
  SELECT SUM(`spree_line_items`.`quantity`)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 34
table.insert(_stmts, {
  app = "spree", stmt_id = 34,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 35
table.insert(_stmts, {
  app = "spree", stmt_id = 35,
  sql = [[
  SELECT SUM(price * quantity)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 36
table.insert(_stmts, {
  app = "spree", stmt_id = 36,
  sql = [[
  SELECT SUM(`spree_shipments`.`cost`)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 37
table.insert(_stmts, {
  app = "spree", stmt_id = 37,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 38
table.insert(_stmts, {
  app = "spree", stmt_id = 38,
  sql = [[
  SELECT SUM(`spree_line_items`.`adjustment_total`)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 39
table.insert(_stmts, {
  app = "spree", stmt_id = 39,
  sql = [[
  SELECT SUM(`spree_shipments`.`adjustment_total`)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 40
table.insert(_stmts, {
  app = "spree", stmt_id = 40,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 41
table.insert(_stmts, {
  app = "spree", stmt_id = 41,
  sql = [[
  SELECT SUM(`spree_line_items`.`included_tax_total`)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 42
table.insert(_stmts, {
  app = "spree", stmt_id = 42,
  sql = [[
  SELECT SUM(`spree_shipments`.`included_tax_total`)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 43
table.insert(_stmts, {
  app = "spree", stmt_id = 43,
  sql = [[
  SELECT SUM(`spree_line_items`.`additional_tax_total`)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 44
table.insert(_stmts, {
  app = "spree", stmt_id = 44,
  sql = [[
  SELECT SUM(`spree_shipments`.`additional_tax_total`)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 45
table.insert(_stmts, {
  app = "spree", stmt_id = 45,
  sql = [[
  SELECT SUM(`spree_line_items`.`promo_total`)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 46
table.insert(_stmts, {
  app = "spree", stmt_id = 46,
  sql = [[
  SELECT SUM(`spree_shipments`.`promo_total`)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 47
table.insert(_stmts, {
  app = "spree", stmt_id = 47,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 48
table.insert(_stmts, {
  app = "spree", stmt_id = 48,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`shipment_id` = %s
  	AND `spree_shipping_rates`.`selected` = %s
  ORDER BY `spree_shipping_rates`.`cost` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipping_rates", col = "selected", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 49
table.insert(_stmts, {
  app = "spree", stmt_id = 49,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 50
table.insert(_stmts, {
  app = "spree", stmt_id = 50,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_locations", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 51
table.insert(_stmts, {
  app = "spree", stmt_id = 51,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id, `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_inventory_units`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`id` = `spree_inventory_units`.`variant_id`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 52
table.insert(_stmts, {
  app = "spree", stmt_id = 52,
  sql = [[
  SELECT DISTINCT spree_shipping_categories.`id`, spree_shipping_categories.`name`, spree_shipping_categories.`created_at`, spree_shipping_categories.`updated_at`
  FROM `spree_shipping_categories`
  	INNER JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`shipping_category_id` = `spree_shipping_categories`.`id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  WHERE `spree_variants`.`id` = %s
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 53
table.insert(_stmts, {
  app = "spree", stmt_id = 53,
  sql = [[
  SELECT `spree_shipping_method_categories`.`id` AS _spree_shipping_method_categories_id
  FROM `spree_shipping_method_categories`
  WHERE `spree_shipping_method_categories`.`shipping_category_id` = %s
  ]],
  params = {
    {table = "spree_shipping_method_categories", col = "shipping_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 54
table.insert(_stmts, {
  app = "spree", stmt_id = 54,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`id` = %s
  ]],
  params = {
    {table = "spree_shipping_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 55
table.insert(_stmts, {
  app = "spree", stmt_id = 55,
  sql = [[
  SELECT `spree_calculators`.`id` AS _spree_calculators_id
  FROM `spree_calculators`
  WHERE `spree_calculators`.`deleted_at` IS NULL
  	AND `spree_calculators`.`calculable_id` = %s
  	AND `spree_calculators`.`calculable_type` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_calculators", col = "calculable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_calculators", col = "calculable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 56
table.insert(_stmts, {
  app = "spree", stmt_id = 56,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  	INNER JOIN `spree_shipping_method_zones` ON `spree_zones`.`id` = `spree_shipping_method_zones`.`zone_id`
  WHERE `spree_shipping_method_zones`.`shipping_method_id` = %s
  ]],
  params = {
    {table = "spree_shipping_method_zones", col = "shipping_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 57
table.insert(_stmts, {
  app = "spree", stmt_id = 57,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 58
table.insert(_stmts, {
  app = "spree", stmt_id = 58,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`shipment_id` = %s
  ORDER BY `spree_shipping_rates`.`cost` ASC
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 59
table.insert(_stmts, {
  app = "spree", stmt_id = 59,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_rates", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 60
table.insert(_stmts, {
  app = "spree", stmt_id = 60,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`position` IS NOT NULL
  ORDER BY `spree_payment_methods`.`position` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 61
table.insert(_stmts, {
  app = "spree", stmt_id = 61,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  	AND `spree_payments`.`id` != %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 62
table.insert(_stmts, {
  app = "spree", stmt_id = 62,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  WHERE `spree_refunds`.`payment_id` = %s
  ]],
  params = {
    {table = "spree_refunds", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 63
table.insert(_stmts, {
  app = "spree", stmt_id = 63,
  sql = [[
  SELECT SUM(`spree_refunds`.`amount`)
  FROM `spree_refunds`
  WHERE `spree_refunds`.`payment_id` = %s
  ]],
  params = {
    {table = "spree_refunds", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 64
table.insert(_stmts, {
  app = "spree", stmt_id = 64,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 65
table.insert(_stmts, {
  app = "spree", stmt_id = 65,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 66
table.insert(_stmts, {
  app = "spree", stmt_id = 66,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_addresses", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 67
table.insert(_stmts, {
  app = "spree", stmt_id = 67,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 68
table.insert(_stmts, {
  app = "spree", stmt_id = 68,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 69
table.insert(_stmts, {
  app = "spree", stmt_id = 69,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`included` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "included", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 70
table.insert(_stmts, {
  app = "spree", stmt_id = 70,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`gateway_customer_profile_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "gateway_customer_profile_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 71
table.insert(_stmts, {
  app = "spree", stmt_id = 71,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ORDER BY `spree_inventory_units`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 72
table.insert(_stmts, {
  app = "spree", stmt_id = 72,
  sql = [[
  SELECT DISTINCT `spree_zones`.`id`
  FROM `spree_zones`
  	INNER JOIN `spree_zone_members`
  	ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  		AND `spree_zone_members`.`zoneable_type` = %s
  	INNER JOIN `spree_countries` ON `spree_countries`.`id` = `spree_zone_members`.`zoneable_id`
  	INNER JOIN `spree_zone_members` `zone_members_spree_countries_join`
  	ON `zone_members_spree_countries_join`.`zoneable_id` = `spree_countries`.`id`
  		AND `zone_members_spree_countries_join`.`zoneable_type` = %s
  	INNER JOIN `spree_zones` `zones_spree_countries` ON `zones_spree_countries`.`id` = `zone_members_spree_countries_join`.`zone_id`
  WHERE zone_members_spree_countries_join.zone_id = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 73
table.insert(_stmts, {
  app = "spree", stmt_id = 73,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`zone_id` = %s
  ]],
  params = {
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 74
table.insert(_stmts, {
  app = "spree", stmt_id = 74,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_products", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 75
table.insert(_stmts, {
  app = "spree", stmt_id = 75,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_shipping_methods", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 76
table.insert(_stmts, {
  app = "spree", stmt_id = 76,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`inventory_unit_id` = %s
  	AND `spree_return_items`.`reception_status` IN (%s)
  ORDER BY `spree_return_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "inventory_unit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "reception_status", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 77
table.insert(_stmts, {
  app = "spree", stmt_id = 77,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  	AND (`spree_adjustments`.`source_type` != %s
  		OR `spree_adjustments`.`source_type` IS NULL)
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 78
table.insert(_stmts, {
  app = "spree", stmt_id = 78,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 79
table.insert(_stmts, {
  app = "spree", stmt_id = 79,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`inventory_unit_id` = %s
  	AND `spree_return_items`.`id` != %s
  	AND `spree_return_items`.`reception_status` != %s
  ]],
  params = {
    {table = "spree_return_items", col = "inventory_unit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "reception_status", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 80
table.insert(_stmts, {
  app = "spree", stmt_id = 80,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 81
table.insert(_stmts, {
  app = "spree", stmt_id = 81,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`reception_status` != %s
  	AND `spree_return_items`.`inventory_unit_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "reception_status", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "inventory_unit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 82
table.insert(_stmts, {
  app = "spree", stmt_id = 82,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`iso` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "iso", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 83
table.insert(_stmts, {
  app = "spree", stmt_id = 83,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  WHERE `spree_stores`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stores", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 84
table.insert(_stmts, {
  app = "spree", stmt_id = 84,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 85
table.insert(_stmts, {
  app = "spree", stmt_id = 85,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  ORDER BY `spree_products`.`name` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 86
table.insert(_stmts, {
  app = "spree", stmt_id = 86,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`is_master` = %s
  	AND `spree_variants`.`product_id` IN (%s)
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 87
table.insert(_stmts, {
  app = "spree", stmt_id = 87,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`is_master` = %s
  	AND `spree_variants`.`product_id` IN (%s)
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 88
table.insert(_stmts, {
  app = "spree", stmt_id = 88,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`viewable_id` IN (%s)
  ORDER BY `spree_assets`.`position` ASC
  ]],
  params = {
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 89
table.insert(_stmts, {
  app = "spree", stmt_id = 89,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`deleted_at` IS NULL
  	AND `spree_prices`.`currency` = %s
  	AND `spree_prices`.`variant_id` IN (%s)
  ]],
  params = {
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 90
table.insert(_stmts, {
  app = "spree", stmt_id = 90,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  WHERE `spree_stores`.`default` = %s
  ORDER BY `spree_stores`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stores", col = "default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 91
table.insert(_stmts, {
  app = "spree", stmt_id = 91,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  WHERE url LIKE %s
  ORDER BY `spree_stores`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stores", col = "url", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 92
table.insert(_stmts, {
  app = "spree", stmt_id = 92,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`id` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 93
table.insert(_stmts, {
  app = "spree", stmt_id = 93,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.`name` LIKE %s
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 94
table.insert(_stmts, {
  app = "spree", stmt_id = 94,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.`name` LIKE %s
  ORDER BY `spree_products`.`name` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 95
table.insert(_stmts, {
  app = "spree", stmt_id = 95,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND (`spree_products`.`name` LIKE %s
  		AND `spree_variants`.`sku` LIKE %s)
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 96
table.insert(_stmts, {
  app = "spree", stmt_id = 96,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND (`spree_products`.`name` LIKE %s
  		AND `spree_variants`.`sku` LIKE %s)
  ORDER BY `spree_products`.`name` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 97
table.insert(_stmts, {
  app = "spree", stmt_id = 97,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`is_master` = %s
  	AND `spree_variants`.`product_id` = %s
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 98
table.insert(_stmts, {
  app = "spree", stmt_id = 98,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`is_master` = %s
  	AND `spree_variants`.`product_id` = %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 99
table.insert(_stmts, {
  app = "spree", stmt_id = 99,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`viewable_id` = %s
  ORDER BY `spree_assets`.`position` ASC
  ]],
  params = {
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 100
table.insert(_stmts, {
  app = "spree", stmt_id = 100,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`deleted_at` IS NULL
  	AND `spree_prices`.`currency` = %s
  	AND `spree_prices`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 101
table.insert(_stmts, {
  app = "spree", stmt_id = 101,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  ORDER BY `spree_variants`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 102
table.insert(_stmts, {
  app = "spree", stmt_id = 102,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`variant_id` = %s
  ORDER BY `spree_stock_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 103
table.insert(_stmts, {
  app = "spree", stmt_id = 103,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`id` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_stock_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 104
table.insert(_stmts, {
  app = "spree", stmt_id = 104,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id, `spree_inventory_units`.`id` AS _spree_inventory_units_id, `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_inventory_units`
  	LEFT JOIN `spree_shipments` ON `spree_shipments`.`id` = `spree_inventory_units`.`shipment_id`
  	LEFT JOIN `spree_orders` ON `spree_orders`.`id` = `spree_inventory_units`.`order_id`
  WHERE `spree_shipments`.`state` != %s
  	AND `spree_inventory_units`.`variant_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_inventory_units`.`state` = %s
  ORDER BY spree_orders.completed_at ASC
  ]],
  params = {
    {table = "spree_shipments", col = "state", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 105
table.insert(_stmts, {
  app = "spree", stmt_id = 105,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`line_item_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "line_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 106
table.insert(_stmts, {
  app = "spree", stmt_id = 106,
  sql = [[
  SELECT DISTINCT `spree_promotions`.`name`, `spree_promotions`.`id`
  FROM `spree_promotions`
  	INNER JOIN spree_order_promotions ON spree_order_promotions.promotion_id = spree_promotions.id
  ]],
  params = {
  }
})

-- stmt 107
table.insert(_stmts, {
  app = "spree", stmt_id = 107,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  ORDER BY `spree_stores`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 108
table.insert(_stmts, {
  app = "spree", stmt_id = 108,
  sql = [[
  SELECT DISTINCT `spree_orders`.`channel`
  FROM `spree_orders`
  ]],
  params = {
  }
})

-- stmt 109
table.insert(_stmts, {
  app = "spree", stmt_id = 109,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
  }
})

-- stmt 110
table.insert(_stmts, {
  app = "spree", stmt_id = 110,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 111
table.insert(_stmts, {
  app = "spree", stmt_id = 111,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 112
table.insert(_stmts, {
  app = "spree", stmt_id = 112,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 113
table.insert(_stmts, {
  app = "spree", stmt_id = 113,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 114
table.insert(_stmts, {
  app = "spree", stmt_id = 114,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`number` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 115
table.insert(_stmts, {
  app = "spree", stmt_id = 115,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`number` LIKE %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 116
table.insert(_stmts, {
  app = "spree", stmt_id = 116,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`number` LIKE %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 117
table.insert(_stmts, {
  app = "spree", stmt_id = 117,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`number` LIKE %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 118
table.insert(_stmts, {
  app = "spree", stmt_id = 118,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`id` = %s
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 119
table.insert(_stmts, {
  app = "spree", stmt_id = 119,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`completed_at` > %s
  ]],
  params = {
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 120
table.insert(_stmts, {
  app = "spree", stmt_id = 120,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`completed_at` > %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 121
table.insert(_stmts, {
  app = "spree", stmt_id = 121,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`completed_at` > %s
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 122
table.insert(_stmts, {
  app = "spree", stmt_id = 122,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  	LEFT JOIN `spree_line_items` ON `spree_line_items`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_variants`.`sku` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 123
table.insert(_stmts, {
  app = "spree", stmt_id = 123,
  sql = [[
  SELECT DISTINCT spree_orders.`id`, spree_orders.`number`, spree_orders.`item_total`, spree_orders.`total`, spree_orders.`state`
  	, spree_orders.`adjustment_total`, spree_orders.`user_id`, spree_orders.`completed_at`, spree_orders.`bill_address_id`, spree_orders.`ship_address_id`
  	, spree_orders.`payment_total`, spree_orders.`shipment_state`, spree_orders.`payment_state`, spree_orders.`email`, spree_orders.`special_instructions`
  	, spree_orders.`created_at`, spree_orders.`updated_at`, spree_orders.`currency`, spree_orders.`last_ip_address`, spree_orders.`created_by_id`
  	, spree_orders.`shipment_total`, spree_orders.`additional_tax_total`, spree_orders.`promo_total`, spree_orders.`channel`, spree_orders.`included_tax_total`
  	, spree_orders.`item_count`, spree_orders.`approver_id`, spree_orders.`approved_at`, spree_orders.`confirmation_delivered`, spree_orders.`considered_risky`
  	, spree_orders.`token`, spree_orders.`canceled_at`, spree_orders.`canceler_id`, spree_orders.`store_id`, spree_orders.`state_lock_version`
  	, spree_orders.`taxable_adjustment_total`, spree_orders.`non_taxable_adjustment_total`
  FROM `spree_orders`
  	LEFT JOIN `spree_line_items` ON `spree_line_items`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_variants`.`sku` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 124
table.insert(_stmts, {
  app = "spree", stmt_id = 124,
  sql = [[
  SELECT DISTINCT spree_orders.`id`, spree_orders.`number`, spree_orders.`item_total`, spree_orders.`total`, spree_orders.`state`
  	, spree_orders.`adjustment_total`, spree_orders.`user_id`, spree_orders.`completed_at`, spree_orders.`bill_address_id`, spree_orders.`ship_address_id`
  	, spree_orders.`payment_total`, spree_orders.`shipment_state`, spree_orders.`payment_state`, spree_orders.`email`, spree_orders.`special_instructions`
  	, spree_orders.`created_at`, spree_orders.`updated_at`, spree_orders.`currency`, spree_orders.`last_ip_address`, spree_orders.`created_by_id`
  	, spree_orders.`shipment_total`, spree_orders.`additional_tax_total`, spree_orders.`promo_total`, spree_orders.`channel`, spree_orders.`included_tax_total`
  	, spree_orders.`item_count`, spree_orders.`approver_id`, spree_orders.`approved_at`, spree_orders.`confirmation_delivered`, spree_orders.`considered_risky`
  	, spree_orders.`token`, spree_orders.`canceled_at`, spree_orders.`canceler_id`, spree_orders.`store_id`, spree_orders.`state_lock_version`
  	, spree_orders.`taxable_adjustment_total`, spree_orders.`non_taxable_adjustment_total`
  FROM `spree_orders`
  	LEFT JOIN `spree_line_items` ON `spree_line_items`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_variants`.`sku` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 125
table.insert(_stmts, {
  app = "spree", stmt_id = 125,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  ]],
  params = {
  }
})

-- stmt 126
table.insert(_stmts, {
  app = "spree", stmt_id = 126,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 127
table.insert(_stmts, {
  app = "spree", stmt_id = 127,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  ORDER BY `spree_orders`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 128
table.insert(_stmts, {
  app = "spree", stmt_id = 128,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`considered_risky` = %s
  ]],
  params = {
    {table = "spree_orders", col = "considered_risky", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 129
table.insert(_stmts, {
  app = "spree", stmt_id = 129,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`considered_risky` = %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "considered_risky", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 130
table.insert(_stmts, {
  app = "spree", stmt_id = 130,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`considered_risky` = %s
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "considered_risky", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 131
table.insert(_stmts, {
  app = "spree", stmt_id = 131,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`payment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "payment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 132
table.insert(_stmts, {
  app = "spree", stmt_id = 132,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`payment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "payment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 133
table.insert(_stmts, {
  app = "spree", stmt_id = 133,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`payment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "payment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 134
table.insert(_stmts, {
  app = "spree", stmt_id = 134,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  	LEFT JOIN `spree_order_promotions` ON `spree_order_promotions`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_promotions`.`id` IN (%s)
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_promotions", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 135
table.insert(_stmts, {
  app = "spree", stmt_id = 135,
  sql = [[
  SELECT DISTINCT spree_orders.`id`, spree_orders.`number`, spree_orders.`item_total`, spree_orders.`total`, spree_orders.`state`
  	, spree_orders.`adjustment_total`, spree_orders.`user_id`, spree_orders.`completed_at`, spree_orders.`bill_address_id`, spree_orders.`ship_address_id`
  	, spree_orders.`payment_total`, spree_orders.`shipment_state`, spree_orders.`payment_state`, spree_orders.`email`, spree_orders.`special_instructions`
  	, spree_orders.`created_at`, spree_orders.`updated_at`, spree_orders.`currency`, spree_orders.`last_ip_address`, spree_orders.`created_by_id`
  	, spree_orders.`shipment_total`, spree_orders.`additional_tax_total`, spree_orders.`promo_total`, spree_orders.`channel`, spree_orders.`included_tax_total`
  	, spree_orders.`item_count`, spree_orders.`approver_id`, spree_orders.`approved_at`, spree_orders.`confirmation_delivered`, spree_orders.`considered_risky`
  	, spree_orders.`token`, spree_orders.`canceled_at`, spree_orders.`canceler_id`, spree_orders.`store_id`, spree_orders.`state_lock_version`
  	, spree_orders.`taxable_adjustment_total`, spree_orders.`non_taxable_adjustment_total`
  FROM `spree_orders`
  	LEFT JOIN `spree_order_promotions` ON `spree_order_promotions`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_promotions`.`id` IN (%s)
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_promotions", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 136
table.insert(_stmts, {
  app = "spree", stmt_id = 136,
  sql = [[
  SELECT DISTINCT spree_orders.`id`, spree_orders.`number`, spree_orders.`item_total`, spree_orders.`total`, spree_orders.`state`
  	, spree_orders.`adjustment_total`, spree_orders.`user_id`, spree_orders.`completed_at`, spree_orders.`bill_address_id`, spree_orders.`ship_address_id`
  	, spree_orders.`payment_total`, spree_orders.`shipment_state`, spree_orders.`payment_state`, spree_orders.`email`, spree_orders.`special_instructions`
  	, spree_orders.`created_at`, spree_orders.`updated_at`, spree_orders.`currency`, spree_orders.`last_ip_address`, spree_orders.`created_by_id`
  	, spree_orders.`shipment_total`, spree_orders.`additional_tax_total`, spree_orders.`promo_total`, spree_orders.`channel`, spree_orders.`included_tax_total`
  	, spree_orders.`item_count`, spree_orders.`approver_id`, spree_orders.`approved_at`, spree_orders.`confirmation_delivered`, spree_orders.`considered_risky`
  	, spree_orders.`token`, spree_orders.`canceled_at`, spree_orders.`canceler_id`, spree_orders.`store_id`, spree_orders.`state_lock_version`
  	, spree_orders.`taxable_adjustment_total`, spree_orders.`non_taxable_adjustment_total`
  FROM `spree_orders`
  	LEFT JOIN `spree_order_promotions` ON `spree_order_promotions`.`order_id` = `spree_orders`.`id`
  	LEFT JOIN `spree_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_promotions`.`id` IN (%s)
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_promotions", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 137
table.insert(_stmts, {
  app = "spree", stmt_id = 137,
  sql = [[
  SELECT COUNT(DISTINCT `spree_orders`.`id`)
  FROM `spree_orders`
  WHERE `spree_orders`.`shipment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "shipment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 138
table.insert(_stmts, {
  app = "spree", stmt_id = 138,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`shipment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "shipment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 139
table.insert(_stmts, {
  app = "spree", stmt_id = 139,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`shipment_state` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "shipment_state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 140
table.insert(_stmts, {
  app = "spree", stmt_id = 140,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ]],
  params = {
  }
})

-- stmt 141
table.insert(_stmts, {
  app = "spree", stmt_id = 141,
  sql = [[
  SELECT `spree_state_changes`.`id` AS _spree_state_changes_id
  FROM `spree_state_changes`
  WHERE `spree_state_changes`.`stateful_id` = %s
  	AND `spree_state_changes`.`stateful_type` = %s
  ]],
  params = {
    {table = "spree_state_changes", col = "stateful_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "stateful_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 142
table.insert(_stmts, {
  app = "spree", stmt_id = 142,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 143
table.insert(_stmts, {
  app = "spree", stmt_id = 143,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  	AND `spree_inventory_units`.`line_item_id` = %s
  	AND `spree_inventory_units`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "line_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 144
table.insert(_stmts, {
  app = "spree", stmt_id = 144,
  sql = [[
  SELECT SUM(`spree_inventory_units`.`quantity`)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 145
table.insert(_stmts, {
  app = "spree", stmt_id = 145,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 146
table.insert(_stmts, {
  app = "spree", stmt_id = 146,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 147
table.insert(_stmts, {
  app = "spree", stmt_id = 147,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  ORDER BY `spree_orders`.`created_at` DESC
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 148
table.insert(_stmts, {
  app = "spree", stmt_id = 148,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`slug` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 149
table.insert(_stmts, {
  app = "spree", stmt_id = 149,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `friendly_id_slugs`
  	ON `friendly_id_slugs`.`deleted_at` IS NULL
  		AND `friendly_id_slugs`.`sluggable_id` = `spree_products`.`id`
  		AND `friendly_id_slugs`.`sluggable_type` = %s
  WHERE `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`slug` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 150
table.insert(_stmts, {
  app = "spree", stmt_id = 150,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  	AND `spree_products_taxons`.`position` IS NOT NULL
  ORDER BY `spree_products_taxons`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 151
table.insert(_stmts, {
  app = "spree", stmt_id = 151,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 152
table.insert(_stmts, {
  app = "spree", stmt_id = 152,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_return_authorizations`
  ]],
  params = {
  }
})

-- stmt 153
table.insert(_stmts, {
  app = "spree", stmt_id = 153,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  ORDER BY `spree_return_authorizations`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 154
table.insert(_stmts, {
  app = "spree", stmt_id = 154,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`position` IS NOT NULL
  ORDER BY `spree_taxonomies`.`position` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 155
table.insert(_stmts, {
  app = "spree", stmt_id = 155,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`taxonomy_id` = %s
  	AND `spree_taxons`.`parent_id` IS NULL
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "taxonomy_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 156
table.insert(_stmts, {
  app = "spree", stmt_id = 156,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`id` = %s
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxonomies", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 157
table.insert(_stmts, {
  app = "spree", stmt_id = 157,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  ORDER BY `spree_taxons`.`rgt` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 158
table.insert(_stmts, {
  app = "spree", stmt_id = 158,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 159
table.insert(_stmts, {
  app = "spree", stmt_id = 159,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`type` = %s
  	AND `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 160
table.insert(_stmts, {
  app = "spree", stmt_id = 160,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 161
table.insert(_stmts, {
  app = "spree", stmt_id = 161,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 162
table.insert(_stmts, {
  app = "spree", stmt_id = 162,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  	AND `spree_taxons`.`id` != %s
  ]],
  params = {
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 163
table.insert(_stmts, {
  app = "spree", stmt_id = 163,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 164
table.insert(_stmts, {
  app = "spree", stmt_id = 164,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 165
table.insert(_stmts, {
  app = "spree", stmt_id = 165,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 166
table.insert(_stmts, {
  app = "spree", stmt_id = 166,
  sql = [[
  SELECT `spree_customer_returns`.`id` AS _spree_customer_returns_id
  FROM `spree_customer_returns`
  ORDER BY `spree_customer_returns`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 167
table.insert(_stmts, {
  app = "spree", stmt_id = 167,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`deleted_at` IS NULL
  	AND `spree_prices`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 168
table.insert(_stmts, {
  app = "spree", stmt_id = 168,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  	AND `spree_inventory_units`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 169
table.insert(_stmts, {
  app = "spree", stmt_id = 169,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  	INNER JOIN `spree_stock_items` ON `spree_stock_locations`.`id` = `spree_stock_items`.`stock_location_id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 170
table.insert(_stmts, {
  app = "spree", stmt_id = 170,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`variant_id` = %s
  	AND `spree_prices`.`currency` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 171
table.insert(_stmts, {
  app = "spree", stmt_id = 171,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 172
table.insert(_stmts, {
  app = "spree", stmt_id = 172,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`state` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 173
table.insert(_stmts, {
  app = "spree", stmt_id = 173,
  sql = [[
  SELECT spree_promotions.`id`, spree_promotions.`description`, spree_promotions.`expires_at`, spree_promotions.`starts_at`, spree_promotions.`name`
  	, spree_promotions.`type`, spree_promotions.`usage_limit`, spree_promotions.`match_policy`, spree_promotions.`code`, spree_promotions.`advertise`
  	, spree_promotions.`path`, spree_promotions.`created_at`, spree_promotions.`updated_at`, spree_promotions.`promotion_category_id`, `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  UNION
  SELECT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`, `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND `spree_promotions`.`code` IS NULL
  	AND `spree_promotions`.`path` IS NULL
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 1, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 174
table.insert(_stmts, {
  app = "spree", stmt_id = 174,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`position` IS NOT NULL
  ORDER BY `spree_option_values`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 175
table.insert(_stmts, {
  app = "spree", stmt_id = 175,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`taxonomy_id` = %s
  	AND `spree_taxons`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "taxonomy_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 176
table.insert(_stmts, {
  app = "spree", stmt_id = 176,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`lft` >= %s
  	AND `spree_taxons`.`lft` < %s
  	AND `spree_taxons`.`id` != %s
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 177
table.insert(_stmts, {
  app = "spree", stmt_id = 177,
  sql = [[
  SELECT `spree_shipping_method_categories`.`id` AS _spree_shipping_method_categories_id
  FROM `spree_shipping_method_categories`
  WHERE `spree_shipping_method_categories`.`shipping_method_id` = %s
  ]],
  params = {
    {table = "spree_shipping_method_categories", col = "shipping_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 178
table.insert(_stmts, {
  app = "spree", stmt_id = 178,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  WHERE `spree_roles`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_roles", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 179
table.insert(_stmts, {
  app = "spree", stmt_id = 179,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_orders`
  ]],
  params = {
  }
})

-- stmt 180
table.insert(_stmts, {
  app = "spree", stmt_id = 180,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ORDER BY `spree_orders`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 181
table.insert(_stmts, {
  app = "spree", stmt_id = 181,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_line_items` ON `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 182
table.insert(_stmts, {
  app = "spree", stmt_id = 182,
  sql = [[
  SELECT DISTINCT spree_orders.`id`, spree_orders.`number`, spree_orders.`item_total`, spree_orders.`total`, spree_orders.`state`
  	, spree_orders.`adjustment_total`, spree_orders.`user_id`, spree_orders.`completed_at`, spree_orders.`bill_address_id`, spree_orders.`ship_address_id`
  	, spree_orders.`payment_total`, spree_orders.`shipment_state`, spree_orders.`payment_state`, spree_orders.`email`, spree_orders.`special_instructions`
  	, spree_orders.`created_at`, spree_orders.`updated_at`, spree_orders.`currency`, spree_orders.`last_ip_address`, spree_orders.`created_by_id`
  	, spree_orders.`shipment_total`, spree_orders.`additional_tax_total`, spree_orders.`promo_total`, spree_orders.`channel`, spree_orders.`included_tax_total`
  	, spree_orders.`item_count`, spree_orders.`approver_id`, spree_orders.`approved_at`, spree_orders.`confirmation_delivered`, spree_orders.`considered_risky`
  	, spree_orders.`token`, spree_orders.`canceled_at`, spree_orders.`canceler_id`, spree_orders.`store_id`, spree_orders.`state_lock_version`
  	, spree_orders.`taxable_adjustment_total`, spree_orders.`non_taxable_adjustment_total`
  FROM `spree_orders`
  	LEFT JOIN `spree_line_items` ON `spree_line_items`.`order_id` = `spree_orders`.`id`
  WHERE `spree_line_items`.`variant_id` IN (%s)
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_line_items", col = "variant_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 183
table.insert(_stmts, {
  app = "spree", stmt_id = 183,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE `spree_promotions`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 184
table.insert(_stmts, {
  app = "spree", stmt_id = 184,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_promotion_rules`
  WHERE `spree_promotion_rules`.`promotion_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rules", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 185
table.insert(_stmts, {
  app = "spree", stmt_id = 185,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` = %s
  ]],
  params = {
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 186
table.insert(_stmts, {
  app = "spree", stmt_id = 186,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  ]],
  params = {
  }
})

-- stmt 187
table.insert(_stmts, {
  app = "spree", stmt_id = 187,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 188
table.insert(_stmts, {
  app = "spree", stmt_id = 188,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  ORDER BY `spree_payment_methods`.`position` ASC
  ]],
  params = {
  }
})

-- stmt 189
table.insert(_stmts, {
  app = "spree", stmt_id = 189,
  sql = [[
  SELECT `spree_refund_reasons`.`id` AS _spree_refund_reasons_id
  FROM `spree_refund_reasons`
  WHERE `spree_refund_reasons`.`name` = %s
  	AND `spree_refund_reasons`.`mutable` = %s
  ORDER BY LOWER(spree_refund_reasons.name)
  LIMIT 2
  ]],
  params = {
    {table = "spree_refund_reasons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_refund_reasons", col = "mutable", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 190
table.insert(_stmts, {
  app = "spree", stmt_id = 190,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 191
table.insert(_stmts, {
  app = "spree", stmt_id = 191,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_refunds`
  WHERE `spree_refunds`.`payment_id` = %s
  ]],
  params = {
    {table = "spree_refunds", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 192
table.insert(_stmts, {
  app = "spree", stmt_id = 192,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  WHERE `spree_reimbursements`.`order_id` = %s
  	AND `spree_reimbursements`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_reimbursements", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_reimbursements", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 193
table.insert(_stmts, {
  app = "spree", stmt_id = 193,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`reimbursement_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "reimbursement_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 194
table.insert(_stmts, {
  app = "spree", stmt_id = 194,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 195
table.insert(_stmts, {
  app = "spree", stmt_id = 195,
  sql = [[
  SELECT `spree_customer_returns`.`id` AS _spree_customer_returns_id
  FROM `spree_customer_returns`
  WHERE `spree_customer_returns`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_customer_returns", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 196
table.insert(_stmts, {
  app = "spree", stmt_id = 196,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 197
table.insert(_stmts, {
  app = "spree", stmt_id = 197,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 198
table.insert(_stmts, {
  app = "spree", stmt_id = 198,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  WHERE `spree_reimbursements`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_reimbursements", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 199
table.insert(_stmts, {
  app = "spree", stmt_id = 199,
  sql = [[
  SELECT SUM(`spree_payments`.`amount`)
  FROM `spree_payments`
  WHERE `spree_payments`.`source_id` = %s
  	AND (source_type = %s
  		AND amount < %s
  		AND state = %s)
  ]],
  params = {
    {table = "spree_payments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "amount", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 200
table.insert(_stmts, {
  app = "spree", stmt_id = 200,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 201
table.insert(_stmts, {
  app = "spree", stmt_id = 201,
  sql = [[
  SELECT SUM(`spree_refunds`.`amount`)
  FROM `spree_refunds`
  	INNER JOIN `spree_payments` ON `spree_refunds`.`payment_id` = `spree_payments`.`id`
  WHERE `spree_payments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 202
table.insert(_stmts, {
  app = "spree", stmt_id = 202,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  WHERE `spree_refunds`.`reimbursement_id` = %s
  ]],
  params = {
    {table = "spree_refunds", col = "reimbursement_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 203
table.insert(_stmts, {
  app = "spree", stmt_id = 203,
  sql = [[
  SELECT `spree_reimbursement_credits`.`id` AS _spree_reimbursement_credits_id
  FROM `spree_reimbursement_credits`
  WHERE `spree_reimbursement_credits`.`reimbursement_id` = %s
  ]],
  params = {
    {table = "spree_reimbursement_credits", col = "reimbursement_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 204
table.insert(_stmts, {
  app = "spree", stmt_id = 204,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  WHERE `spree_refunds`.`payment_id` = %s
  ORDER BY `spree_refunds`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_refunds", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 205
table.insert(_stmts, {
  app = "spree", stmt_id = 205,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  	AND `spree_return_items`.`acceptance_status` = %s
  	AND `spree_return_items`.`reimbursement_id` IS NULL
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "acceptance_status", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 206
table.insert(_stmts, {
  app = "spree", stmt_id = 206,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_reimbursements`
  WHERE `spree_reimbursements`.`order_id` = %s
  ]],
  params = {
    {table = "spree_reimbursements", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 207
table.insert(_stmts, {
  app = "spree", stmt_id = 207,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 208
table.insert(_stmts, {
  app = "spree", stmt_id = 208,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`id` = %s
  ]],
  params = {
    {table = "spree_orders", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 209
table.insert(_stmts, {
  app = "spree", stmt_id = 209,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 210
table.insert(_stmts, {
  app = "spree", stmt_id = 210,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`included` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "included", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 211
table.insert(_stmts, {
  app = "spree", stmt_id = 211,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`state` = %s
  ]],
  params = {
    {table = "spree_return_authorizations", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 212
table.insert(_stmts, {
  app = "spree", stmt_id = 212,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`state` = %s
  ORDER BY `spree_return_authorizations`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_return_authorizations", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 213
table.insert(_stmts, {
  app = "spree", stmt_id = 213,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`number` LIKE %s
  ]],
  params = {
    {table = "spree_return_authorizations", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 214
table.insert(_stmts, {
  app = "spree", stmt_id = 214,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`number` LIKE %s
  ORDER BY `spree_return_authorizations`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_return_authorizations", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 215
table.insert(_stmts, {
  app = "spree", stmt_id = 215,
  sql = [[
  SELECT DISTINCT spree_shipping_categories.`id`, spree_shipping_categories.`name`, spree_shipping_categories.`created_at`, spree_shipping_categories.`updated_at`
  FROM `spree_shipping_categories`
  	INNER JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`shipping_category_id` = `spree_shipping_categories`.`id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  WHERE `spree_variants`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 216
table.insert(_stmts, {
  app = "spree", stmt_id = 216,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  LIMIT 3
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 217
table.insert(_stmts, {
  app = "spree", stmt_id = 217,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  ORDER BY id
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 218
table.insert(_stmts, {
  app = "spree", stmt_id = 218,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  ORDER BY id
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 219
table.insert(_stmts, {
  app = "spree", stmt_id = 219,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  WHERE `spree_reimbursements`.`customer_return_id` = %s
  ]],
  params = {
    {table = "spree_reimbursements", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 220
table.insert(_stmts, {
  app = "spree", stmt_id = 220,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` IS NOT NULL
  ORDER BY `spree_dummy_models`.`position` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 221
table.insert(_stmts, {
  app = "spree", stmt_id = 221,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_dummy_models`
  ]],
  params = {
  }
})

-- stmt 222
table.insert(_stmts, {
  app = "spree", stmt_id = 222,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_dummy_models", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 223
table.insert(_stmts, {
  app = "spree", stmt_id = 223,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 224
table.insert(_stmts, {
  app = "spree", stmt_id = 224,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`active` = %s
  	AND `spree_payment_methods`.`display_on` IN (%s)
  ORDER BY `spree_payment_methods`.`position` ASC
  ]],
  params = {
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "display_on", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 225
table.insert(_stmts, {
  app = "spree", stmt_id = 225,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ORDER BY `spree_stock_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 226
table.insert(_stmts, {
  app = "spree", stmt_id = 226,
  sql = [[
  SELECT `spree_product_option_types`.`id` AS _spree_product_option_types_id
  FROM `spree_product_option_types`
  WHERE `spree_product_option_types`.`product_id` = %s
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 227
table.insert(_stmts, {
  app = "spree", stmt_id = 227,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`state` NOT IN (%s)
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 228
table.insert(_stmts, {
  app = "spree", stmt_id = 228,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`id` = %s
  ]],
  params = {
    {table = "spree_credit_cards", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 229
table.insert(_stmts, {
  app = "spree", stmt_id = 229,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`id` = %s
  ORDER BY `spree_credit_cards`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 230
table.insert(_stmts, {
  app = "spree", stmt_id = 230,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 231
table.insert(_stmts, {
  app = "spree", stmt_id = 231,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_log_entries`
  WHERE `spree_log_entries`.`source_type` = %s
  	AND `spree_log_entries`.`source_id` = %s
  ]],
  params = {
    {table = "spree_log_entries", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_log_entries", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 232
table.insert(_stmts, {
  app = "spree", stmt_id = 232,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 233
table.insert(_stmts, {
  app = "spree", stmt_id = 233,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`name` = %s
  ORDER BY `spree_option_values`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 234
table.insert(_stmts, {
  app = "spree", stmt_id = 234,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 235
table.insert(_stmts, {
  app = "spree", stmt_id = 235,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 236
table.insert(_stmts, {
  app = "spree", stmt_id = 236,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_shipments`.`state` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 237
table.insert(_stmts, {
  app = "spree", stmt_id = 237,
  sql = [[
  SELECT `spree_state_changes`.`id` AS _spree_state_changes_id
  FROM `spree_state_changes`
  WHERE `spree_state_changes`.`stateful_id` = %s
  	AND `spree_state_changes`.`stateful_type` = %s
  ORDER BY `spree_state_changes`.`created_at` DESC
  ]],
  params = {
    {table = "spree_state_changes", col = "stateful_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "stateful_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 238
table.insert(_stmts, {
  app = "spree", stmt_id = 238,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`position` IS NOT NULL
  ORDER BY `spree_option_types`.`position` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 239
table.insert(_stmts, {
  app = "spree", stmt_id = 239,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_zones`
  ]],
  params = {
  }
})

-- stmt 240
table.insert(_stmts, {
  app = "spree", stmt_id = 240,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  ORDER BY `spree_states`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 241
table.insert(_stmts, {
  app = "spree", stmt_id = 241,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ORDER BY `spree_countries`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 242
table.insert(_stmts, {
  app = "spree", stmt_id = 242,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ORDER BY `spree_zones`.`name` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 243
table.insert(_stmts, {
  app = "spree", stmt_id = 243,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ORDER BY `spree_zones`.`description` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 244
table.insert(_stmts, {
  app = "spree", stmt_id = 244,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ORDER BY `spree_inventory_units`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 245
table.insert(_stmts, {
  app = "spree", stmt_id = 245,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`adjustable_id` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 246
table.insert(_stmts, {
  app = "spree", stmt_id = 246,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ORDER BY `spree_shipments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 247
table.insert(_stmts, {
  app = "spree", stmt_id = 247,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 248
table.insert(_stmts, {
  app = "spree", stmt_id = 248,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_option_value_variants`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 249
table.insert(_stmts, {
  app = "spree", stmt_id = 249,
  sql = [[
  SELECT `spree_product_option_types`.`id` AS _spree_product_option_types_id
  FROM `spree_product_option_types`
  WHERE `spree_product_option_types`.`product_id` = %s
  	AND `spree_product_option_types`.`position` IS NOT NULL
  ORDER BY `spree_product_option_types`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 250
table.insert(_stmts, {
  app = "spree", stmt_id = 250,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 251
table.insert(_stmts, {
  app = "spree", stmt_id = 251,
  sql = [[
  SELECT `spree_option_value_variants`.`id` AS _spree_option_value_variants_id
  FROM `spree_option_value_variants`
  WHERE `spree_option_value_variants`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 252
table.insert(_stmts, {
  app = "spree", stmt_id = 252,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`id` = %s
  ]],
  params = {
    {table = "spree_option_values", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 253
table.insert(_stmts, {
  app = "spree", stmt_id = 253,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_option_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 254
table.insert(_stmts, {
  app = "spree", stmt_id = 254,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`name` = %s
  ORDER BY `spree_option_types`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_types", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 255
table.insert(_stmts, {
  app = "spree", stmt_id = 255,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ORDER BY `spree_stock_items`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 256
table.insert(_stmts, {
  app = "spree", stmt_id = 256,
  sql = [[
  SELECT `spree_reimbursement_types`.`id` AS _spree_reimbursement_types_id
  FROM `spree_reimbursement_types`
  WHERE `spree_reimbursement_types`.`id` = %s
  ORDER BY LOWER(spree_reimbursement_types.name)
  LIMIT 2
  ]],
  params = {
    {table = "spree_reimbursement_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 257
table.insert(_stmts, {
  app = "spree", stmt_id = 257,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_reimbursement_types`
  ]],
  params = {
  }
})

-- stmt 258
table.insert(_stmts, {
  app = "spree", stmt_id = 258,
  sql = [[
  SELECT `spree_reimbursement_types`.`id` AS _spree_reimbursement_types_id
  FROM `spree_reimbursement_types`
  ORDER BY LOWER(spree_reimbursement_types.name)
  ]],
  params = {
  }
})

-- stmt 259
table.insert(_stmts, {
  app = "spree", stmt_id = 259,
  sql = [[
  SELECT `spree_reimbursement_types`.`id` AS _spree_reimbursement_types_id
  FROM `spree_reimbursement_types`
  WHERE `spree_reimbursement_types`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_reimbursement_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 260
table.insert(_stmts, {
  app = "spree", stmt_id = 260,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  	AND `spree_inventory_units`.`state` = %s
  ORDER BY `spree_inventory_units`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 261
table.insert(_stmts, {
  app = "spree", stmt_id = 261,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_customer_returns`
  ]],
  params = {
  }
})

-- stmt 262
table.insert(_stmts, {
  app = "spree", stmt_id = 262,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ORDER BY `spree_shipments`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 263
table.insert(_stmts, {
  app = "spree", stmt_id = 263,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 264
table.insert(_stmts, {
  app = "spree", stmt_id = 264,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_authorizations", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 265
table.insert(_stmts, {
  app = "spree", stmt_id = 265,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  	INNER JOIN `spree_role_users` ON `spree_roles`.`id` = `spree_role_users`.`role_id`
  WHERE `spree_role_users`.`user_id` = %s
  ]],
  params = {
    {table = "spree_role_users", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 266
table.insert(_stmts, {
  app = "spree", stmt_id = 266,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 267
table.insert(_stmts, {
  app = "spree", stmt_id = 267,
  sql = [[
  SELECT `spree_shipping_method_zones`.`id` AS _spree_shipping_method_zones_id
  FROM `spree_shipping_method_zones`
  WHERE `spree_shipping_method_zones`.`shipping_method_id` = %s
  ]],
  params = {
    {table = "spree_shipping_method_zones", col = "shipping_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 268
table.insert(_stmts, {
  app = "spree", stmt_id = 268,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`id` = %s
  ]],
  params = {
    {table = "spree_zones", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 269
table.insert(_stmts, {
  app = "spree", stmt_id = 269,
  sql = [[
  SELECT `spree_calculators`.`id` AS _spree_calculators_id
  FROM `spree_calculators`
  WHERE `spree_calculators`.`deleted_at` IS NULL
  	AND `spree_calculators`.`calculable_type` = %s
  	AND `spree_calculators`.`calculable_id` = %s
  ]],
  params = {
    {table = "spree_calculators", col = "calculable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_calculators", col = "calculable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 270
table.insert(_stmts, {
  app = "spree", stmt_id = 270,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  ]],
  params = {
  }
})

-- stmt 271
table.insert(_stmts, {
  app = "spree", stmt_id = 271,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ]],
  params = {
  }
})

-- stmt 272
table.insert(_stmts, {
  app = "spree", stmt_id = 272,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  ORDER BY `spree_tax_categories`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 273
table.insert(_stmts, {
  app = "spree", stmt_id = 273,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  WHERE `spree_shipping_categories`.`id` = %s
  ]],
  params = {
    {table = "spree_shipping_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 274
table.insert(_stmts, {
  app = "spree", stmt_id = 274,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 275
table.insert(_stmts, {
  app = "spree", stmt_id = 275,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  ORDER BY `spree_shipping_methods`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 276
table.insert(_stmts, {
  app = "spree", stmt_id = 276,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`position` IS NOT NULL
  ORDER BY `spree_assets`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 277
table.insert(_stmts, {
  app = "spree", stmt_id = 277,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 278
table.insert(_stmts, {
  app = "spree", stmt_id = 278,
  sql = [[
  SELECT `active_storage_attachments`.`id` AS _active_storage_attachments_id
  FROM `active_storage_attachments`
  WHERE `active_storage_attachments`.`record_id` = %s
  	AND `active_storage_attachments`.`record_type` = %s
  	AND `active_storage_attachments`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "active_storage_attachments", col = "record_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "record_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 279
table.insert(_stmts, {
  app = "spree", stmt_id = 279,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`slug` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 280
table.insert(_stmts, {
  app = "spree", stmt_id = 280,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 281
table.insert(_stmts, {
  app = "spree", stmt_id = 281,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` = %s
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 282
table.insert(_stmts, {
  app = "spree", stmt_id = 282,
  sql = [[
  SELECT `active_storage_blobs`.`id` AS _active_storage_blobs_id
  FROM `active_storage_blobs`
  WHERE `active_storage_blobs`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "active_storage_blobs", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 283
table.insert(_stmts, {
  app = "spree", stmt_id = 283,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`payment_method_id` = %s
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  ]],
  params = {
    {table = "spree_credit_cards", col = "payment_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 284
table.insert(_stmts, {
  app = "spree", stmt_id = 284,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 285
table.insert(_stmts, {
  app = "spree", stmt_id = 285,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`adjustable_id` IN (
  		SELECT `spree_line_items`.`id`
  		FROM `spree_line_items`
  		WHERE `spree_line_items`.`order_id` = %s
  		ORDER BY `spree_line_items`.`created_at` ASC
  	)
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 286
table.insert(_stmts, {
  app = "spree", stmt_id = 286,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`adjustable_id` IN (
  		SELECT `spree_shipments`.`id`
  		FROM `spree_shipments`
  		WHERE `spree_shipments`.`order_id` = %s
  	)
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 287
table.insert(_stmts, {
  app = "spree", stmt_id = 287,
  sql = [[
  SELECT DISTINCT spree_stock_locations.`id`, spree_stock_locations.`name`, spree_stock_locations.`created_at`, spree_stock_locations.`updated_at`, spree_stock_locations.`default`
  	, spree_stock_locations.`address1`, spree_stock_locations.`address2`, spree_stock_locations.`city`, spree_stock_locations.`state_id`, spree_stock_locations.`state_name`
  	, spree_stock_locations.`country_id`, spree_stock_locations.`zipcode`, spree_stock_locations.`phone`, spree_stock_locations.`active`, spree_stock_locations.`backorderable_default`
  	, spree_stock_locations.`propagate_all_variants`, spree_stock_locations.`admin_name`
  FROM `spree_stock_locations`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = `spree_stock_locations`.`id`
  WHERE `spree_stock_locations`.`active` = %s
  	AND `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 288
table.insert(_stmts, {
  app = "spree", stmt_id = 288,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_order_promotions`.`order_id` = %s
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 289
table.insert(_stmts, {
  app = "spree", stmt_id = 289,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`type` = %s
  	AND `spree_promotion_actions`.`deleted_at` IS NULL
  ]],
  params = {
    {table = "spree_promotion_actions", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 290
table.insert(_stmts, {
  app = "spree", stmt_id = 290,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND `spree_promotions`.`path` IS NULL
  ]],
  params = {
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 291
table.insert(_stmts, {
  app = "spree", stmt_id = 291,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 292
table.insert(_stmts, {
  app = "spree", stmt_id = 292,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` = %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 293
table.insert(_stmts, {
  app = "spree", stmt_id = 293,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  ]],
  params = {
  }
})

-- stmt 294
table.insert(_stmts, {
  app = "spree", stmt_id = 294,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` NOT IN (%s)
  ORDER BY `spree_payments`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 295
table.insert(_stmts, {
  app = "spree", stmt_id = 295,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 296
table.insert(_stmts, {
  app = "spree", stmt_id = 296,
  sql = [[
  SELECT `spree_option_value_variants`.`id` AS _spree_option_value_variants_id
  FROM `spree_option_value_variants`
  WHERE `spree_option_value_variants`.`variant_id` IN (%s)
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 297
table.insert(_stmts, {
  app = "spree", stmt_id = 297,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_option_values", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 298
table.insert(_stmts, {
  app = "spree", stmt_id = 298,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`id` IN (%s)
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_option_types", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 299
table.insert(_stmts, {
  app = "spree", stmt_id = 299,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`deleted_at` IS NULL
  	AND `spree_prices`.`variant_id` = %s
  	AND `spree_prices`.`currency` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 300
table.insert(_stmts, {
  app = "spree", stmt_id = 300,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 301
table.insert(_stmts, {
  app = "spree", stmt_id = 301,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  ORDER BY `spree_assets`.`position` ASC
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 302
table.insert(_stmts, {
  app = "spree", stmt_id = 302,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NOT NULL
  	AND `spree_variants`.`product_id` = %s
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 303
table.insert(_stmts, {
  app = "spree", stmt_id = 303,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_line_items` ON `spree_adjustments`.`adjustable_id` = `spree_line_items`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 304
table.insert(_stmts, {
  app = "spree", stmt_id = 304,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 305
table.insert(_stmts, {
  app = "spree", stmt_id = 305,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 306
table.insert(_stmts, {
  app = "spree", stmt_id = 306,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	LEFT JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 307
table.insert(_stmts, {
  app = "spree", stmt_id = 307,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	LEFT JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  ORDER BY `spree_prices`.`amount` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 308
table.insert(_stmts, {
  app = "spree", stmt_id = 308,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  ORDER BY `spree_products`.`name` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 309
table.insert(_stmts, {
  app = "spree", stmt_id = 309,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 310
table.insert(_stmts, {
  app = "spree", stmt_id = 310,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`inventory_unit_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "inventory_unit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 311
table.insert(_stmts, {
  app = "spree", stmt_id = 311,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  	AND `spree_store_credit_events`.`action` = %s
  ORDER BY `spree_store_credit_events`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "action", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 312
table.insert(_stmts, {
  app = "spree", stmt_id = 312,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  	AND `spree_store_credits`.`user_id` = %s
  ]],
  params = {
    {table = "spree_store_credits", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 313
table.insert(_stmts, {
  app = "spree", stmt_id = 313,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 314
table.insert(_stmts, {
  app = "spree", stmt_id = 314,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  ]],
  params = {
  }
})

-- stmt 315
table.insert(_stmts, {
  app = "spree", stmt_id = 315,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  	INNER JOIN `spree_role_users` ON `spree_roles`.`id` = `spree_role_users`.`role_id`
  WHERE `spree_role_users`.`user_id` = %s
  ]],
  params = {
    {table = "spree_role_users", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 316
table.insert(_stmts, {
  app = "spree", stmt_id = 316,
  sql = [[
  SELECT SUM(`spree_orders`.`total`)
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 317
table.insert(_stmts, {
  app = "spree", stmt_id = 317,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 318
table.insert(_stmts, {
  app = "spree", stmt_id = 318,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 319
table.insert(_stmts, {
  app = "spree", stmt_id = 319,
  sql = [[
  SELECT `spree_role_users`.`id` AS _spree_role_users_id
  FROM `spree_role_users`
  WHERE `spree_role_users`.`user_id` = %s
  ]],
  params = {
    {table = "spree_role_users", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 320
table.insert(_stmts, {
  app = "spree", stmt_id = 320,
  sql = [[
  SELECT `spree_promotion_rule_users`.`id` AS _spree_promotion_rule_users_id
  FROM `spree_promotion_rule_users`
  WHERE `spree_promotion_rule_users`.`user_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rule_users", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 321
table.insert(_stmts, {
  app = "spree", stmt_id = 321,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  	AND `spree_store_credits`.`user_id` = %s
  ORDER BY `spree_store_credits`.`id` DESC
  ]],
  params = {
    {table = "spree_store_credits", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 322
table.insert(_stmts, {
  app = "spree", stmt_id = 322,
  sql = [[
  SELECT `spree_store_credit_types`.`id` AS _spree_store_credit_types_id
  FROM `spree_store_credit_types`
  WHERE `spree_store_credit_types`.`id` = %s
  ]],
  params = {
    {table = "spree_store_credit_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 323
table.insert(_stmts, {
  app = "spree", stmt_id = 323,
  sql = [[
  SELECT `spree_store_credit_categories`.`id` AS _spree_store_credit_categories_id
  FROM `spree_store_credit_categories`
  WHERE `spree_store_credit_categories`.`id` = %s
  ]],
  params = {
    {table = "spree_store_credit_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 324
table.insert(_stmts, {
  app = "spree", stmt_id = 324,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  	AND `spree_store_credits`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credits", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 325
table.insert(_stmts, {
  app = "spree", stmt_id = 325,
  sql = [[
  SELECT `spree_store_credit_categories`.`id` AS _spree_store_credit_categories_id
  FROM `spree_store_credit_categories`
  WHERE `spree_store_credit_categories`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 326
table.insert(_stmts, {
  app = "spree", stmt_id = 326,
  sql = [[
  SELECT `spree_store_credit_categories`.`id` AS _spree_store_credit_categories_id
  FROM `spree_store_credit_categories`
  ORDER BY `spree_store_credit_categories`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 327
table.insert(_stmts, {
  app = "spree", stmt_id = 327,
  sql = [[
  SELECT `spree_store_credit_types`.`id` AS _spree_store_credit_types_id
  FROM `spree_store_credit_types`
  WHERE `spree_store_credit_types`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 328
table.insert(_stmts, {
  app = "spree", stmt_id = 328,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credits", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 329
table.insert(_stmts, {
  app = "spree", stmt_id = 329,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  	AND `spree_store_credits`.`id` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 330
table.insert(_stmts, {
  app = "spree", stmt_id = 330,
  sql = [[
  SELECT `spree_store_credit_types`.`id` AS _spree_store_credit_types_id
  FROM `spree_store_credit_types`
  WHERE `spree_store_credit_types`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_types", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 331
table.insert(_stmts, {
  app = "spree", stmt_id = 331,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 332
table.insert(_stmts, {
  app = "spree", stmt_id = 332,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  ORDER BY `spree_store_credits`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 333
table.insert(_stmts, {
  app = "spree", stmt_id = 333,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  		LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  	WHERE `spree_users`.`id` = %s
  	ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 334
table.insert(_stmts, {
  app = "spree", stmt_id = 334,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 335
table.insert(_stmts, {
  app = "spree", stmt_id = 335,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  		LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  	WHERE `spree_users`.`id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 336
table.insert(_stmts, {
  app = "spree", stmt_id = 336,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`id` ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 337
table.insert(_stmts, {
  app = "spree", stmt_id = 337,
  sql = [[
  SELECT `spree_return_authorization_reasons`.`id` AS _spree_return_authorization_reasons_id
  FROM `spree_return_authorization_reasons`
  WHERE `spree_return_authorization_reasons`.`active` = %s
  ORDER BY LOWER(spree_return_authorization_reasons.name)
  ]],
  params = {
    {table = "spree_return_authorization_reasons", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 338
table.insert(_stmts, {
  app = "spree", stmt_id = 338,
  sql = [[
  SELECT `spree_reimbursement_types`.`id` AS _spree_reimbursement_types_id
  FROM `spree_reimbursement_types`
  WHERE `spree_reimbursement_types`.`active` = %s
  ORDER BY LOWER(spree_reimbursement_types.name)
  ]],
  params = {
    {table = "spree_reimbursement_types", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 339
table.insert(_stmts, {
  app = "spree", stmt_id = 339,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`completed_at` > %s
  ORDER BY `spree_orders`.`completed_at` DESC
  ]],
  params = {
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 340
table.insert(_stmts, {
  app = "spree", stmt_id = 340,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND (`spree_orders`.`completed_at` > %s
  		AND `spree_orders`.`completed_at` < %s)
  ORDER BY `spree_orders`.`completed_at` DESC
  ]],
  params = {
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "completed_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 341
table.insert(_stmts, {
  app = "spree", stmt_id = 341,
  sql = [[
  SELECT `spree_preferences`.`id` AS _spree_preferences_id
  FROM `spree_preferences`
  WHERE `spree_preferences`.`key` = %s
  ORDER BY `spree_preferences`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_preferences", col = "key", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 342
table.insert(_stmts, {
  app = "spree", stmt_id = 342,
  sql = [[
  SELECT `spree_oauth_access_tokens`.`id` AS _spree_oauth_access_tokens_id
  FROM `spree_oauth_access_tokens`
  WHERE `spree_oauth_access_tokens`.`token` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_oauth_access_tokens", col = "token", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 343
table.insert(_stmts, {
  app = "spree", stmt_id = 343,
  sql = [[
  SELECT `spree_preferences`.`id` AS _spree_preferences_id
  FROM `spree_preferences`
  WHERE `spree_preferences`.`key` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_preferences", col = "key", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 344
table.insert(_stmts, {
  app = "spree", stmt_id = 344,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`token` = %s
  	AND `spree_orders`.`currency` = %s
  	AND `spree_orders`.`store_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "token", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 345
table.insert(_stmts, {
  app = "spree", stmt_id = 345,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 346
table.insert(_stmts, {
  app = "spree", stmt_id = 346,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 347
table.insert(_stmts, {
  app = "spree", stmt_id = 347,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_line_items` ON `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 348
table.insert(_stmts, {
  app = "spree", stmt_id = 348,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  	AND `spree_adjustments`.amount != %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 349
table.insert(_stmts, {
  app = "spree", stmt_id = 349,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 350
table.insert(_stmts, {
  app = "spree", stmt_id = 350,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`token` IS NULL
  	AND `spree_orders`.`currency` = %s
  	AND `spree_orders`.`store_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 351
table.insert(_stmts, {
  app = "spree", stmt_id = 351,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`store_id` = %s
  	AND `spree_orders`.`user_id` = %s
  ORDER BY `spree_orders`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 352
table.insert(_stmts, {
  app = "spree", stmt_id = 352,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`type` = %s
  	AND `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`active` = %s
  	AND `spree_payment_methods`.`display_on` IN (%s)
  ORDER BY `spree_payment_methods`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "display_on", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 353
table.insert(_stmts, {
  app = "spree", stmt_id = 353,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id, `spree_store_credit_types`.`id` AS _spree_store_credit_types_id
  FROM `spree_store_credits`
  	LEFT JOIN `spree_store_credit_types` ON `spree_store_credit_types`.`id` = `spree_store_credits`.`type_id`
  WHERE `spree_store_credits`.`deleted_at` IS NULL
  	AND `spree_store_credits`.`user_id` = %s
  ORDER BY spree_store_credit_types.priority ASC
  ]],
  params = {
    {table = "spree_store_credits", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 354
table.insert(_stmts, {
  app = "spree", stmt_id = 354,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 355
table.insert(_stmts, {
  app = "spree", stmt_id = 355,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 356
table.insert(_stmts, {
  app = "spree", stmt_id = 356,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 357
table.insert(_stmts, {
  app = "spree", stmt_id = 357,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE LOWER(iso) = %s
  	OR LOWER(iso3) = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "iso", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "iso3", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 358
table.insert(_stmts, {
  app = "spree", stmt_id = 358,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  	AND `spree_addresses`.`firstname` = %s
  	AND `spree_addresses`.`lastname` = %s
  	AND `spree_addresses`.`address1` = %s
  	AND `spree_addresses`.`address2` IS NULL
  	AND `spree_addresses`.`city` = %s
  	AND `spree_addresses`.`zipcode` = %s
  	AND `spree_addresses`.`phone` = %s
  	AND `spree_addresses`.`state_name` IS NULL
  	AND `spree_addresses`.`alternative_phone` IS NULL
  	AND `spree_addresses`.`company` IS NULL
  	AND `spree_addresses`.`state_id` = %s
  	AND `spree_addresses`.`country_id` = %s
  	AND `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  ORDER BY updated_at DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "firstname", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "lastname", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "address1", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "city", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "zipcode", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "phone", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "state_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 359
table.insert(_stmts, {
  app = "spree", stmt_id = 359,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`zone_id` IN (%s)
  ]],
  params = {
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 360
table.insert(_stmts, {
  app = "spree", stmt_id = 360,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`shipping_method_id` = %s
  ORDER BY `spree_shipping_rates`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipping_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 361
table.insert(_stmts, {
  app = "spree", stmt_id = 361,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_shipments`.`id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 362
table.insert(_stmts, {
  app = "spree", stmt_id = 362,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`id` = %s
  	AND `spree_payment_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 363
table.insert(_stmts, {
  app = "spree", stmt_id = 363,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 364
table.insert(_stmts, {
  app = "spree", stmt_id = 364,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ORDER BY `spree_shipments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 365
table.insert(_stmts, {
  app = "spree", stmt_id = 365,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` NOT IN (%s)
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 366
table.insert(_stmts, {
  app = "spree", stmt_id = 366,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  	AND `spree_payments`.`source_type` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 367
table.insert(_stmts, {
  app = "spree", stmt_id = 367,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ORDER BY `spree_payments`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 368
table.insert(_stmts, {
  app = "spree", stmt_id = 368,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  ORDER BY `spree_shipping_rates`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 369
table.insert(_stmts, {
  app = "spree", stmt_id = 369,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`shipment_id` = %s
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 370
table.insert(_stmts, {
  app = "spree", stmt_id = 370,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`product_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 371
table.insert(_stmts, {
  app = "spree", stmt_id = 371,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 372
table.insert(_stmts, {
  app = "spree", stmt_id = 372,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`lft` >= %s
  	AND `spree_taxons`.`lft` < %s
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 373
table.insert(_stmts, {
  app = "spree", stmt_id = 373,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_taxons`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 374
table.insert(_stmts, {
  app = "spree", stmt_id = 374,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  		INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_taxons`.`id` = %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 375
table.insert(_stmts, {
  app = "spree", stmt_id = 375,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_taxons`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 376
table.insert(_stmts, {
  app = "spree", stmt_id = 376,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` = %s
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 377
table.insert(_stmts, {
  app = "spree", stmt_id = 377,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 378
table.insert(_stmts, {
  app = "spree", stmt_id = 378,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  		, spree_prices.amount
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_prices`.`currency` = %s
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 379
table.insert(_stmts, {
  app = "spree", stmt_id = 379,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  		, spree_prices.amount
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_prices`.`currency` = %s
  	ORDER BY spree_prices.amount DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 380
table.insert(_stmts, {
  app = "spree", stmt_id = 380,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_prices`.`currency` = %s
  ORDER BY spree_prices.amount DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 381
table.insert(_stmts, {
  app = "spree", stmt_id = 381,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` IN (%s)
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 382
table.insert(_stmts, {
  app = "spree", stmt_id = 382,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`product_id` IN (%s)
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 383
table.insert(_stmts, {
  app = "spree", stmt_id = 383,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` IN (%s)
  ORDER BY `spree_product_properties`.`position` ASC
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 384
table.insert(_stmts, {
  app = "spree", stmt_id = 384,
  sql = [[
  SELECT `spree_product_option_types`.`id` AS _spree_product_option_types_id
  FROM `spree_product_option_types`
  WHERE `spree_product_option_types`.`product_id` IN (%s)
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 385
table.insert(_stmts, {
  app = "spree", stmt_id = 385,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  ORDER BY `spree_option_values`.`position` ASC
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 386
table.insert(_stmts, {
  app = "spree", stmt_id = 386,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  	AND (spree_stock_items.count_on_hand > %s
  		OR spree_variants.track_inventory = %s
  		OR `spree_stock_items`.`backorderable` = %s)
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "track_inventory", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "backorderable", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 387
table.insert(_stmts, {
  app = "spree", stmt_id = 387,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 388
table.insert(_stmts, {
  app = "spree", stmt_id = 388,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY spree_prices.amount DESC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 389
table.insert(_stmts, {
  app = "spree", stmt_id = 389,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  		, spree_prices.amount
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_prices`.`currency` = %s
  	ORDER BY spree_prices.amount ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 390
table.insert(_stmts, {
  app = "spree", stmt_id = 390,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_prices`.`currency` = %s
  ORDER BY spree_prices.amount ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 391
table.insert(_stmts, {
  app = "spree", stmt_id = 391,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY spree_prices.amount
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 392
table.insert(_stmts, {
  app = "spree", stmt_id = 392,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 393
table.insert(_stmts, {
  app = "spree", stmt_id = 393,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	ORDER BY `spree_products`.`updated_at` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 394
table.insert(_stmts, {
  app = "spree", stmt_id = 394,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`updated_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 395
table.insert(_stmts, {
  app = "spree", stmt_id = 395,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`updated_at` ASC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 396
table.insert(_stmts, {
  app = "spree", stmt_id = 396,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	ORDER BY `spree_products`.`updated_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 397
table.insert(_stmts, {
  app = "spree", stmt_id = 397,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`updated_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 398
table.insert(_stmts, {
  app = "spree", stmt_id = 398,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`updated_at` DESC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 399
table.insert(_stmts, {
  app = "spree", stmt_id = 399,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`name` LIKE %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 400
table.insert(_stmts, {
  app = "spree", stmt_id = 400,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`name` LIKE %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 401
table.insert(_stmts, {
  app = "spree", stmt_id = 401,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`name` LIKE %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 402
table.insert(_stmts, {
  app = "spree", stmt_id = 402,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  ]],
  params = {
  }
})

-- stmt 403
table.insert(_stmts, {
  app = "spree", stmt_id = 403,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 404
table.insert(_stmts, {
  app = "spree", stmt_id = 404,
  sql = [[
  SELECT DISTINCT `id`, `name`, `description`, `available_on`, `discontinue_on`
  	, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`
  	, `shipping_category_id`, `created_at`, `updated_at`, `promotionable`, `meta_title`
  FROM `spree_products`
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 405
table.insert(_stmts, {
  app = "spree", stmt_id = 405,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  	INNER JOIN `spree_prices` `prices_spree_variants`
  	ON `prices_spree_variants`.`deleted_at` IS NULL
  		AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_prices`.`amount` BETWEEN %s AND %s
  	AND `spree_prices`.`currency` = %s
  	AND `spree_products`.`name` LIKE %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 406
table.insert(_stmts, {
  app = "spree", stmt_id = 406,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  			AND `spree_prices`.`currency` = %s
  		INNER JOIN `spree_prices` `prices_spree_variants`
  		ON `prices_spree_variants`.`deleted_at` IS NULL
  			AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_prices`.`amount` BETWEEN %s AND %s
  		AND `spree_prices`.`currency` = %s
  		AND `spree_products`.`name` LIKE %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 407
table.insert(_stmts, {
  app = "spree", stmt_id = 407,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  	INNER JOIN `spree_prices` `prices_spree_variants`
  	ON `prices_spree_variants`.`deleted_at` IS NULL
  		AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_prices`.`amount` BETWEEN %s AND %s
  	AND `spree_prices`.`currency` = %s
  	AND `spree_products`.`name` LIKE %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 408
table.insert(_stmts, {
  app = "spree", stmt_id = 408,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  	INNER JOIN `spree_prices` `prices_spree_variants`
  	ON `prices_spree_variants`.`deleted_at` IS NULL
  		AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_prices`.`amount` BETWEEN %s AND %s
  	AND `spree_prices`.`currency` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 409
table.insert(_stmts, {
  app = "spree", stmt_id = 409,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  			AND `spree_prices`.`currency` = %s
  		INNER JOIN `spree_prices` `prices_spree_variants`
  		ON `prices_spree_variants`.`deleted_at` IS NULL
  			AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_prices`.`amount` BETWEEN %s AND %s
  		AND `spree_prices`.`currency` = %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 410
table.insert(_stmts, {
  app = "spree", stmt_id = 410,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		AND `spree_prices`.`currency` = %s
  	INNER JOIN `spree_prices` `prices_spree_variants`
  	ON `prices_spree_variants`.`deleted_at` IS NULL
  		AND `prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_prices`.`amount` BETWEEN %s AND %s
  	AND `spree_prices`.`currency` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 411
table.insert(_stmts, {
  app = "spree", stmt_id = 411,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 412
table.insert(_stmts, {
  app = "spree", stmt_id = 412,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`id` = %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 413
table.insert(_stmts, {
  app = "spree", stmt_id = 413,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 414
table.insert(_stmts, {
  app = "spree", stmt_id = 414,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 415
table.insert(_stmts, {
  app = "spree", stmt_id = 415,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 416
table.insert(_stmts, {
  app = "spree", stmt_id = 416,
  sql = [[
  SELECT DISTINCT `id`, `name`, `description`, `available_on`, `discontinue_on`
  	, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`
  	, `shipping_category_id`, `created_at`, `updated_at`, `promotionable`, `meta_title`
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 417
table.insert(_stmts, {
  app = "spree", stmt_id = 417,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 418
table.insert(_stmts, {
  app = "spree", stmt_id = 418,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 419
table.insert(_stmts, {
  app = "spree", stmt_id = 419,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 420
table.insert(_stmts, {
  app = "spree", stmt_id = 420,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 421
table.insert(_stmts, {
  app = "spree", stmt_id = 421,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`) AS count_id, spree_products.id AS spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  	INNER JOIN `spree_variants` `masters_spree_products`
  	ON `masters_spree_products`.`deleted_at` IS NULL
  		AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  		AND `masters_spree_products`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND spree_option_values.name = %s
  	AND spree_option_values.option_type_id = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  GROUP BY spree_products.id
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 422
table.insert(_stmts, {
  app = "spree", stmt_id = 422,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`) AS count_id, spree_products.id AS spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  	INNER JOIN `spree_variants` `masters_spree_products`
  	ON `masters_spree_products`.`deleted_at` IS NULL
  		AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  		AND `masters_spree_products`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND spree_option_values.name = %s
  	AND spree_option_values.option_type_id = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  GROUP BY spree_products.id
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 423
table.insert(_stmts, {
  app = "spree", stmt_id = 423,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  	INNER JOIN `spree_variants` `masters_spree_products`
  	ON `masters_spree_products`.`deleted_at` IS NULL
  		AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  		AND `masters_spree_products`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND spree_option_values.name = %s
  	AND spree_option_values.option_type_id = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  GROUP BY spree_products.id
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 424
table.insert(_stmts, {
  app = "spree", stmt_id = 424,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  ORDER BY `spree_assets`.`position` ASC
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 425
table.insert(_stmts, {
  app = "spree", stmt_id = 425,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_variants` `masters_spree_products`
  	ON `masters_spree_products`.`deleted_at` IS NULL
  		AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  		AND `masters_spree_products`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_variants`.`sku` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 426
table.insert(_stmts, {
  app = "spree", stmt_id = 426,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  		INNER JOIN `spree_variants` `masters_spree_products`
  		ON `masters_spree_products`.`deleted_at` IS NULL
  			AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  			AND `masters_spree_products`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND `spree_variants`.`sku` = %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 427
table.insert(_stmts, {
  app = "spree", stmt_id = 427,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_variants` `masters_spree_products`
  	ON `masters_spree_products`.`deleted_at` IS NULL
  		AND `masters_spree_products`.`product_id` = `spree_products`.`id`
  		AND `masters_spree_products`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `masters_spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_variants`.`sku` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 428
table.insert(_stmts, {
  app = "spree", stmt_id = 428,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 429
table.insert(_stmts, {
  app = "spree", stmt_id = 429,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 430
table.insert(_stmts, {
  app = "spree", stmt_id = 430,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 431
table.insert(_stmts, {
  app = "spree", stmt_id = 431,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` LIKE %s
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 432
table.insert(_stmts, {
  app = "spree", stmt_id = 432,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`name` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 433
table.insert(_stmts, {
  app = "spree", stmt_id = 433,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 434
table.insert(_stmts, {
  app = "spree", stmt_id = 434,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`type` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`viewable_id` = %s
  ]],
  params = {
    {table = "spree_assets", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 435
table.insert(_stmts, {
  app = "spree", stmt_id = 435,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  ORDER BY `spree_products_taxons`.`position` ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 436
table.insert(_stmts, {
  app = "spree", stmt_id = 436,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`id` = %s
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at
  ]],
  params = {
    {table = "spree_taxonomies", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 437
table.insert(_stmts, {
  app = "spree", stmt_id = 437,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 438
table.insert(_stmts, {
  app = "spree", stmt_id = 438,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` IS NULL
  	AND `spree_taxons`.`taxonomy_id` = %s
  ]],
  params = {
    {table = "spree_taxons", col = "taxonomy_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 439
table.insert(_stmts, {
  app = "spree", stmt_id = 439,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  	AND `spree_taxons`.`id` != %s
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 440
table.insert(_stmts, {
  app = "spree", stmt_id = 440,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 441
table.insert(_stmts, {
  app = "spree", stmt_id = 441,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`id` IN (%s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 442
table.insert(_stmts, {
  app = "spree", stmt_id = 442,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` IN (%s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 443
table.insert(_stmts, {
  app = "spree", stmt_id = 443,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` IN (%s)
  ORDER BY `spree_taxons`.`lft` ASC
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 444
table.insert(_stmts, {
  app = "spree", stmt_id = 444,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` IN (%s)
  ORDER BY `spree_products_taxons`.`position` ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 445
table.insert(_stmts, {
  app = "spree", stmt_id = 445,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`type` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`viewable_id` IN (%s)
  ]],
  params = {
    {table = "spree_assets", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 446
table.insert(_stmts, {
  app = "spree", stmt_id = 446,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` IS NULL
  ]],
  params = {
  }
})

-- stmt 447
table.insert(_stmts, {
  app = "spree", stmt_id = 447,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`parent_id` IS NULL
  	ORDER BY `spree_taxons`.`lft` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 448
table.insert(_stmts, {
  app = "spree", stmt_id = 448,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` IS NULL
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 449
table.insert(_stmts, {
  app = "spree", stmt_id = 449,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 450
table.insert(_stmts, {
  app = "spree", stmt_id = 450,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`parent_id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 451
table.insert(_stmts, {
  app = "spree", stmt_id = 451,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 452
table.insert(_stmts, {
  app = "spree", stmt_id = 452,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  ]],
  params = {
  }
})

-- stmt 453
table.insert(_stmts, {
  app = "spree", stmt_id = 453,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 454
table.insert(_stmts, {
  app = "spree", stmt_id = 454,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 455
table.insert(_stmts, {
  app = "spree", stmt_id = 455,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 456
table.insert(_stmts, {
  app = "spree", stmt_id = 456,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 457
table.insert(_stmts, {
  app = "spree", stmt_id = 457,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`permalink` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "permalink", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 458
table.insert(_stmts, {
  app = "spree", stmt_id = 458,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  ORDER BY `spree_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 459
table.insert(_stmts, {
  app = "spree", stmt_id = 459,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`spree_api_key` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_users", col = "spree_api_key", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 460
table.insert(_stmts, {
  app = "spree", stmt_id = 460,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  	INNER JOIN `spree_role_users` ON `spree_roles`.`id` = `spree_role_users`.`role_id`
  WHERE `spree_role_users`.`user_id` = %s
  ]],
  params = {
    {table = "spree_role_users", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 461
table.insert(_stmts, {
  app = "spree", stmt_id = 461,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 462
table.insert(_stmts, {
  app = "spree", stmt_id = 462,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` IN (%s)
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 463
table.insert(_stmts, {
  app = "spree", stmt_id = 463,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_stock_locations", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 464
table.insert(_stmts, {
  app = "spree", stmt_id = 464,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_variants`.`id` AS count_column
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 465
table.insert(_stmts, {
  app = "spree", stmt_id = 465,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 466
table.insert(_stmts, {
  app = "spree", stmt_id = 466,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`name` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 467
table.insert(_stmts, {
  app = "spree", stmt_id = 467,
  sql = [[
  SELECT SUM(`spree_stock_items`.`count_on_hand`)
  FROM `spree_stock_items`
  	INNER JOIN `spree_variants` ON `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 468
table.insert(_stmts, {
  app = "spree", stmt_id = 468,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_products`.`name` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 469
table.insert(_stmts, {
  app = "spree", stmt_id = 469,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	LEFT JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`id` = `spree_variants`.`product_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  	AND (`spree_products`.`name` LIKE %s
  		OR `spree_variants`.`sku` LIKE %s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 470
table.insert(_stmts, {
  app = "spree", stmt_id = 470,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`id` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 471
table.insert(_stmts, {
  app = "spree", stmt_id = 471,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_variants`.`id` AS count_column
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		LEFT JOIN `spree_products`
  		ON `spree_products`.`deleted_at` IS NULL
  			AND `spree_products`.`id` = `spree_variants`.`product_id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  		AND (`spree_products`.`name` LIKE %s
  			OR `spree_variants`.`sku` LIKE %s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 472
table.insert(_stmts, {
  app = "spree", stmt_id = 472,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 473
table.insert(_stmts, {
  app = "spree", stmt_id = 473,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 474
table.insert(_stmts, {
  app = "spree", stmt_id = 474,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 475
table.insert(_stmts, {
  app = "spree", stmt_id = 475,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 476
table.insert(_stmts, {
  app = "spree", stmt_id = 476,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_products`.`id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 477
table.insert(_stmts, {
  app = "spree", stmt_id = 477,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`default` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 478
table.insert(_stmts, {
  app = "spree", stmt_id = 478,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`user_id` = %s
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 479
table.insert(_stmts, {
  app = "spree", stmt_id = 479,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`payment_method_id` = %s
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "payment_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 480
table.insert(_stmts, {
  app = "spree", stmt_id = 480,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 481
table.insert(_stmts, {
  app = "spree", stmt_id = 481,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 482
table.insert(_stmts, {
  app = "spree", stmt_id = 482,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 483
table.insert(_stmts, {
  app = "spree", stmt_id = 483,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`token` IS NULL
  	AND `spree_orders`.`currency` IS NULL
  	AND `spree_orders`.`store_id` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 484
table.insert(_stmts, {
  app = "spree", stmt_id = 484,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`store_id` IS NULL
  	AND `spree_orders`.`user_id` = %s
  ORDER BY `spree_orders`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 485
table.insert(_stmts, {
  app = "spree", stmt_id = 485,
  sql = [[
  SELECT DISTINCT `spree_promotions`.`id` AS alias_0, `spree_promotions`.`id`
  FROM `spree_promotions`
  	LEFT JOIN `spree_promotion_rules` ON `spree_promotion_rules`.`promotion_id` = `spree_promotions`.`id`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  ORDER BY `spree_promotions`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 486
table.insert(_stmts, {
  app = "spree", stmt_id = 486,
  sql = [[
  SELECT DISTINCT `spree_promotions`.`id` AS alias_0, `spree_promotions`.`id`
  FROM `spree_promotions`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  ORDER BY `spree_promotions`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 487
table.insert(_stmts, {
  app = "spree", stmt_id = 487,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id, `spree_promotions`.`id` AS _spree_promotions_id, `spree_promotion_rules`.`id` AS _spree_promotion_rules_id
  FROM `spree_promotions`
  	LEFT JOIN `spree_promotion_rules` ON `spree_promotion_rules`.`promotion_id` = `spree_promotions`.`id`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  	AND `spree_promotions`.`id` = %s
  ORDER BY `spree_promotions`.`id` ASC
  ]],
  params = {
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 488
table.insert(_stmts, {
  app = "spree", stmt_id = 488,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 489
table.insert(_stmts, {
  app = "spree", stmt_id = 489,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_actions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 490
table.insert(_stmts, {
  app = "spree", stmt_id = 490,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 491
table.insert(_stmts, {
  app = "spree", stmt_id = 491,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 492
table.insert(_stmts, {
  app = "spree", stmt_id = 492,
  sql = [[
  SELECT `spree_order_promotions`.`id` AS _spree_order_promotions_id
  FROM `spree_order_promotions`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND `spree_order_promotions`.`promotion_id` = %s
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_order_promotions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 493
table.insert(_stmts, {
  app = "spree", stmt_id = 493,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` IN (
  		SELECT `spree_promotion_actions`.`id`
  		FROM `spree_promotion_actions`
  		WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  			AND `spree_promotion_actions`.`promotion_id` = %s
  	)
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 494
table.insert(_stmts, {
  app = "spree", stmt_id = 494,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ORDER BY `spree_orders`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 495
table.insert(_stmts, {
  app = "spree", stmt_id = 495,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  	INNER JOIN `spree_shipments` ON `spree_adjustments`.`adjustable_id` = `spree_shipments`.`id`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND (`spree_adjustments`.`source_type` != %s
  		OR `spree_adjustments`.`source_type` IS NULL)
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 496
table.insert(_stmts, {
  app = "spree", stmt_id = 496,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 497
table.insert(_stmts, {
  app = "spree", stmt_id = 497,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND `spree_promotions`.`code` IS NOT NULL
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 498
table.insert(_stmts, {
  app = "spree", stmt_id = 498,
  sql = [[
  SELECT DISTINCT `spree_promotions`.`id` AS alias_0, `spree_promotions`.`id`
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  ORDER BY `spree_promotions`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 499
table.insert(_stmts, {
  app = "spree", stmt_id = 499,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id, `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  	AND `spree_promotions`.`id` = %s
  ORDER BY `spree_promotions`.`id` ASC
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 500
table.insert(_stmts, {
  app = "spree", stmt_id = 500,
  sql = [[
  SELECT `spree_order_promotions`.`id` AS _spree_order_promotions_id
  FROM `spree_order_promotions`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND `spree_order_promotions`.`promotion_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_order_promotions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 501
table.insert(_stmts, {
  app = "spree", stmt_id = 501,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 502
table.insert(_stmts, {
  app = "spree", stmt_id = 502,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` = %s
  	AND `spree_promotion_actions`.`type` = %s
  ]],
  params = {
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_actions", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 503
table.insert(_stmts, {
  app = "spree", stmt_id = 503,
  sql = [[
  SELECT `spree_promotion_action_line_items`.`id` AS _spree_promotion_action_line_items_id
  FROM `spree_promotion_action_line_items`
  ORDER BY `spree_promotion_action_line_items`.`id` ASC
  LIMIT 1000
  ]],
  params = {
  }
})

-- stmt 504
table.insert(_stmts, {
  app = "spree", stmt_id = 504,
  sql = [[
  SELECT `spree_order_promotions`.`id` AS _spree_order_promotions_id
  FROM `spree_order_promotions`
  WHERE `spree_order_promotions`.`order_id` = %s
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 505
table.insert(_stmts, {
  app = "spree", stmt_id = 505,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id, `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zones`
  	LEFT JOIN `spree_zone_members` ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  WHERE (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = %s)
  	OR (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = NULL)
  ORDER BY spree_zones.zone_members_count, spree_zones.created_at
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 506
table.insert(_stmts, {
  app = "spree", stmt_id = 506,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  ORDER BY `spree_products`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 507
table.insert(_stmts, {
  app = "spree", stmt_id = 507,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.`slug` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 508
table.insert(_stmts, {
  app = "spree", stmt_id = 508,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `friendly_id_slugs`
  	ON `friendly_id_slugs`.`deleted_at` IS NULL
  		AND `friendly_id_slugs`.`sluggable_id` = `spree_products`.`id`
  		AND `friendly_id_slugs`.`sluggable_type` = %s
  WHERE (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`slug` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 509
table.insert(_stmts, {
  app = "spree", stmt_id = 509,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 510
table.insert(_stmts, {
  app = "spree", stmt_id = 510,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ORDER BY updated_at DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 511
table.insert(_stmts, {
  app = "spree", stmt_id = 511,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 512
table.insert(_stmts, {
  app = "spree", stmt_id = 512,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_countries`
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 513
table.insert(_stmts, {
  app = "spree", stmt_id = 513,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 514
table.insert(_stmts, {
  app = "spree", stmt_id = 514,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 515
table.insert(_stmts, {
  app = "spree", stmt_id = 515,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 516
table.insert(_stmts, {
  app = "spree", stmt_id = 516,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`iso3` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "iso3", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 517
table.insert(_stmts, {
  app = "spree", stmt_id = 517,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_countries", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 518
table.insert(_stmts, {
  app = "spree", stmt_id = 518,
  sql = [[
  SELECT DISTINCT spree_countries.`id`, spree_countries.`iso_name`, spree_countries.`iso`, spree_countries.`iso3`, spree_countries.`name`
  	, spree_countries.`numcode`, spree_countries.`states_required`, spree_countries.`updated_at`, spree_countries.`zipcode_required`
  FROM `spree_countries`
  	INNER JOIN `spree_zone_members`
  	ON `spree_zone_members`.`zoneable_id` = `spree_countries`.`id`
  		AND `spree_zone_members`.`zoneable_type` = %s
  	INNER JOIN `spree_zones` ON `spree_zones`.`id` = `spree_zone_members`.`zone_id`
  	INNER JOIN `spree_shipping_method_zones` ON `spree_shipping_method_zones`.`zone_id` = `spree_zones`.`id`
  	INNER JOIN `spree_shipping_methods`
  	ON `spree_shipping_methods`.`deleted_at` IS NULL
  		AND `spree_shipping_methods`.`deleted_at` IS NULL
  		AND `spree_shipping_methods`.`id` = `spree_shipping_method_zones`.`shipping_method_id`
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 519
table.insert(_stmts, {
  app = "spree", stmt_id = 519,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_countries`
  ]],
  params = {
  }
})

-- stmt 520
table.insert(_stmts, {
  app = "spree", stmt_id = 520,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`number` = %s
  	AND `spree_orders`.`token` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "token", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 521
table.insert(_stmts, {
  app = "spree", stmt_id = 521,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  	AND `spree_orders`.`number` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 522
table.insert(_stmts, {
  app = "spree", stmt_id = 522,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 523
table.insert(_stmts, {
  app = "spree", stmt_id = 523,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 524
table.insert(_stmts, {
  app = "spree", stmt_id = 524,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	ORDER BY `spree_orders`.`completed_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 525
table.insert(_stmts, {
  app = "spree", stmt_id = 525,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 526
table.insert(_stmts, {
  app = "spree", stmt_id = 526,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` IN (%s)
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 527
table.insert(_stmts, {
  app = "spree", stmt_id = 527,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ORDER BY `spree_orders`.`completed_at` DESC
  ]],
  params = {
  }
})

-- stmt 528
table.insert(_stmts, {
  app = "spree", stmt_id = 528,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	ORDER BY `spree_orders`.`completed_at` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 529
table.insert(_stmts, {
  app = "spree", stmt_id = 529,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 530
table.insert(_stmts, {
  app = "spree", stmt_id = 530,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ORDER BY `spree_orders`.`completed_at` ASC
  ]],
  params = {
  }
})

-- stmt 531
table.insert(_stmts, {
  app = "spree", stmt_id = 531,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 532
table.insert(_stmts, {
  app = "spree", stmt_id = 532,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 533
table.insert(_stmts, {
  app = "spree", stmt_id = 533,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 534
table.insert(_stmts, {
  app = "spree", stmt_id = 534,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` IN (%s)
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 535
table.insert(_stmts, {
  app = "spree", stmt_id = 535,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` IN (%s)
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY amount ASC, created_at DESC, id DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 536
table.insert(_stmts, {
  app = "spree", stmt_id = 536,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`reimbursement_id` = %s
  	AND `spree_return_items`.`exchange_variant_id` IS NOT NULL
  ]],
  params = {
    {table = "spree_return_items", col = "reimbursement_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 537
table.insert(_stmts, {
  app = "spree", stmt_id = 537,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ORDER BY `spree_states`.`name` ASC
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 538
table.insert(_stmts, {
  app = "spree", stmt_id = 538,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_promotions`
  ]],
  params = {
  }
})

-- stmt 539
table.insert(_stmts, {
  app = "spree", stmt_id = 539,
  sql = [[
  SELECT `spree_promotion_rules`.`id` AS _spree_promotion_rules_id
  FROM `spree_promotion_rules`
  WHERE `spree_promotion_rules`.`promotion_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rules", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 540
table.insert(_stmts, {
  app = "spree", stmt_id = 540,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` = %s
  ]],
  params = {
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 541
table.insert(_stmts, {
  app = "spree", stmt_id = 541,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 542
table.insert(_stmts, {
  app = "spree", stmt_id = 542,
  sql = [[
  SELECT `spree_promotion_categories`.`id` AS _spree_promotion_categories_id
  FROM `spree_promotion_categories`
  ORDER BY `spree_promotion_categories`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 543
table.insert(_stmts, {
  app = "spree", stmt_id = 543,
  sql = [[
  SELECT DISTINCT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`
  FROM `spree_promotions`
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 544
table.insert(_stmts, {
  app = "spree", stmt_id = 544,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` IN (%s)
  ]],
  params = {
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 545
table.insert(_stmts, {
  app = "spree", stmt_id = 545,
  sql = [[
  SELECT DISTINCT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`
  FROM `spree_promotions`
  WHERE `spree_promotions`.`path` LIKE %s
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_promotions", col = "path", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 546
table.insert(_stmts, {
  app = "spree", stmt_id = 546,
  sql = [[
  SELECT DISTINCT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`
  FROM `spree_promotions`
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 547
table.insert(_stmts, {
  app = "spree", stmt_id = 547,
  sql = [[
  SELECT DISTINCT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`
  FROM `spree_promotions`
  WHERE `spree_promotions`.`code` LIKE %s
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 548
table.insert(_stmts, {
  app = "spree", stmt_id = 548,
  sql = [[
  SELECT DISTINCT `id`, `description`, `expires_at`, `starts_at`, `name`
  	, `type`, `usage_limit`, `match_policy`, `code`, `advertise`
  	, `path`, `created_at`, `updated_at`, `promotion_category_id`
  FROM `spree_promotions`
  WHERE `spree_promotions`.`name` LIKE %s
  ORDER BY `spree_promotions`.`id` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_promotions", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 549
table.insert(_stmts, {
  app = "spree", stmt_id = 549,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE sku LIKE %s
  ORDER BY `spree_variants`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 2, guessed = nil},
  }
})

-- stmt 550
table.insert(_stmts, {
  app = "spree", stmt_id = 550,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  WHERE `spree_shipping_categories`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 551
table.insert(_stmts, {
  app = "spree", stmt_id = 551,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  WHERE `spree_products`.discontinue_on IS NULL
  	OR `spree_products`.discontinue_on >= %s
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 552
table.insert(_stmts, {
  app = "spree", stmt_id = 552,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.discontinue_on IS NULL
  	OR `spree_products`.discontinue_on >= %s
  ORDER BY `spree_products`.`name` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 553
table.insert(_stmts, {
  app = "spree", stmt_id = 553,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  ORDER BY name DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 554
table.insert(_stmts, {
  app = "spree", stmt_id = 554,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`id` = %s
  ]],
  params = {
    {table = "spree_countries", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 555
table.insert(_stmts, {
  app = "spree", stmt_id = 555,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  ORDER BY name ASC
  ]],
  params = {
  }
})

-- stmt 556
table.insert(_stmts, {
  app = "spree", stmt_id = 556,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`id` = %s
  ORDER BY name ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 557
table.insert(_stmts, {
  app = "spree", stmt_id = 557,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ORDER BY name DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 558
table.insert(_stmts, {
  app = "spree", stmt_id = 558,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  ORDER BY name ASC
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 559
table.insert(_stmts, {
  app = "spree", stmt_id = 559,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`name` LIKE %s
  ORDER BY name DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 560
table.insert(_stmts, {
  app = "spree", stmt_id = 560,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`name` LIKE %s
  ORDER BY name ASC
  ]],
  params = {
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 561
table.insert(_stmts, {
  app = "spree", stmt_id = 561,
  sql = [[
  SELECT DISTINCT `id`, `position`, `name`, `presentation`, `option_type_id`
  	, `created_at`, `updated_at`
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  ORDER BY `spree_option_values`.`position` ASC
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 562
table.insert(_stmts, {
  app = "spree", stmt_id = 562,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`id` = %s
  ORDER BY `spree_option_values`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 563
table.insert(_stmts, {
  app = "spree", stmt_id = 563,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 564
table.insert(_stmts, {
  app = "spree", stmt_id = 564,
  sql = [[
  SELECT DISTINCT `id`, `position`, `name`, `presentation`, `option_type_id`
  	, `created_at`, `updated_at`
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`name` LIKE %s
  ORDER BY `spree_option_values`.`position` ASC
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 565
table.insert(_stmts, {
  app = "spree", stmt_id = 565,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`id` IN (%s)
  ORDER BY `spree_option_values`.`position` ASC
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 566
table.insert(_stmts, {
  app = "spree", stmt_id = 566,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 567
table.insert(_stmts, {
  app = "spree", stmt_id = 567,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  ]],
  params = {
  }
})

-- stmt 568
table.insert(_stmts, {
  app = "spree", stmt_id = 568,
  sql = [[
  SELECT DISTINCT `id`, `position`, `name`, `presentation`, `option_type_id`
  	, `created_at`, `updated_at`
  FROM `spree_option_values`
  ]],
  params = {
  }
})

-- stmt 569
table.insert(_stmts, {
  app = "spree", stmt_id = 569,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  ORDER BY `spree_return_authorizations`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 570
table.insert(_stmts, {
  app = "spree", stmt_id = 570,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  	AND `spree_return_authorizations`.`memo` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_authorizations", col = "memo", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 571
table.insert(_stmts, {
  app = "spree", stmt_id = 571,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_return_authorizations`
  	WHERE `spree_return_authorizations`.`order_id` = %s
  		AND `spree_return_authorizations`.`memo` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_authorizations", col = "memo", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 572
table.insert(_stmts, {
  app = "spree", stmt_id = 572,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 573
table.insert(_stmts, {
  app = "spree", stmt_id = 573,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_return_authorizations`
  	WHERE `spree_return_authorizations`.`order_id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 574
table.insert(_stmts, {
  app = "spree", stmt_id = 574,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  	AND `spree_return_authorizations`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_authorizations", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 575
table.insert(_stmts, {
  app = "spree", stmt_id = 575,
  sql = [[
  SELECT `spree_return_authorization_reasons`.`id` AS _spree_return_authorization_reasons_id
  FROM `spree_return_authorization_reasons`
  WHERE `spree_return_authorization_reasons`.`id` = %s
  ORDER BY LOWER(spree_return_authorization_reasons.name)
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_authorization_reasons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 576
table.insert(_stmts, {
  app = "spree", stmt_id = 576,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 577
table.insert(_stmts, {
  app = "spree", stmt_id = 577,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_return_authorizations`
  	WHERE `spree_return_authorizations`.`order_id` = %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 578
table.insert(_stmts, {
  app = "spree", stmt_id = 578,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_return_authorizations`
  WHERE `spree_return_authorizations`.`order_id` = %s
  ]],
  params = {
    {table = "spree_return_authorizations", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 579
table.insert(_stmts, {
  app = "spree", stmt_id = 579,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`return_authorization_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "return_authorization_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 580
table.insert(_stmts, {
  app = "spree", stmt_id = 580,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  ORDER BY name ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 581
table.insert(_stmts, {
  app = "spree", stmt_id = 581,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_countries`
  	ORDER BY name ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 582
table.insert(_stmts, {
  app = "spree", stmt_id = 582,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`name` LIKE %s
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_countries", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 583
table.insert(_stmts, {
  app = "spree", stmt_id = 583,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_countries`
  	WHERE `spree_countries`.`name` LIKE %s
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_countries", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 584
table.insert(_stmts, {
  app = "spree", stmt_id = 584,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 585
table.insert(_stmts, {
  app = "spree", stmt_id = 585,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`parent_id` = %s
  	ORDER BY `spree_taxons`.`lft` ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 586
table.insert(_stmts, {
  app = "spree", stmt_id = 586,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 587
table.insert(_stmts, {
  app = "spree", stmt_id = 587,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`parent_id` = %s
  	ORDER BY `spree_taxons`.`lft` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 588
table.insert(_stmts, {
  app = "spree", stmt_id = 588,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` LIKE %s
  ORDER BY `spree_taxons`.`taxonomy_id` ASC, `spree_taxons`.`lft` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 589
table.insert(_stmts, {
  app = "spree", stmt_id = 589,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`name` LIKE %s
  	ORDER BY `spree_taxons`.`taxonomy_id` ASC, `spree_taxons`.`lft` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 590
table.insert(_stmts, {
  app = "spree", stmt_id = 590,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  ORDER BY `spree_taxons`.`taxonomy_id` ASC, `spree_taxons`.`lft` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 591
table.insert(_stmts, {
  app = "spree", stmt_id = 591,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	ORDER BY `spree_taxons`.`taxonomy_id` ASC, `spree_taxons`.`lft` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 592
table.insert(_stmts, {
  app = "spree", stmt_id = 592,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`name` LIKE %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 593
table.insert(_stmts, {
  app = "spree", stmt_id = 593,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxons`
  	WHERE `spree_taxons`.`parent_id` = %s
  		AND `spree_taxons`.`name` LIKE %s
  	ORDER BY `spree_taxons`.`lft` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 594
table.insert(_stmts, {
  app = "spree", stmt_id = 594,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxonomies", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 595
table.insert(_stmts, {
  app = "spree", stmt_id = 595,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` = %s
  ORDER BY `spree_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 596
table.insert(_stmts, {
  app = "spree", stmt_id = 596,
  sql = [[
  SELECT `friendly_id_slugs`.`id` AS _friendly_id_slugs_id
  FROM `friendly_id_slugs`
  WHERE `friendly_id_slugs`.`deleted_at` IS NULL
  	AND `friendly_id_slugs`.`sluggable_id` = %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 597
table.insert(_stmts, {
  app = "spree", stmt_id = 597,
  sql = [[
  SELECT `spree_prototype_taxons`.`id` AS _spree_prototype_taxons_id
  FROM `spree_prototype_taxons`
  WHERE `spree_prototype_taxons`.`taxon_id` = %s
  ]],
  params = {
    {table = "spree_prototype_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 598
table.insert(_stmts, {
  app = "spree", stmt_id = 598,
  sql = [[
  SELECT `spree_promotion_rule_taxons`.`id` AS _spree_promotion_rule_taxons_id
  FROM `spree_promotion_rule_taxons`
  WHERE `spree_promotion_rule_taxons`.`taxon_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rule_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 599
table.insert(_stmts, {
  app = "spree", stmt_id = 599,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND `spree_variants`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 600
table.insert(_stmts, {
  app = "spree", stmt_id = 600,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  	AND `spree_variants`.`sku` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 601
table.insert(_stmts, {
  app = "spree", stmt_id = 601,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_variants`.`id` AS count_column
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_variants`.`sku` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 602
table.insert(_stmts, {
  app = "spree", stmt_id = 602,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 603
table.insert(_stmts, {
  app = "spree", stmt_id = 603,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_variants`.`id` AS count_column
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 604
table.insert(_stmts, {
  app = "spree", stmt_id = 604,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 605
table.insert(_stmts, {
  app = "spree", stmt_id = 605,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_variants`.`id` AS count_column
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 606
table.insert(_stmts, {
  app = "spree", stmt_id = 606,
  sql = [[
  SELECT COUNT(DISTINCT `spree_variants`.`id`)
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 607
table.insert(_stmts, {
  app = "spree", stmt_id = 607,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND `spree_variants`.`id` = %s
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 608
table.insert(_stmts, {
  app = "spree", stmt_id = 608,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 609
table.insert(_stmts, {
  app = "spree", stmt_id = 609,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ORDER BY `spree_variants`.`position` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 610
table.insert(_stmts, {
  app = "spree", stmt_id = 610,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  		, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  		, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  		, spree_variants.`updated_at`, spree_variants.`created_at`
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = %s
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  	ORDER BY `spree_variants`.`position` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 611
table.insert(_stmts, {
  app = "spree", stmt_id = 611,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`product_id` = %s
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ORDER BY `spree_variants`.`position` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 612
table.insert(_stmts, {
  app = "spree", stmt_id = 612,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  		, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  		, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  		, spree_variants.`updated_at`, spree_variants.`created_at`
  	FROM `spree_variants`
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_variants`.`product_id` = %s
  		AND (`spree_variants`.`is_master` = %s
  			OR `spree_variants`.id IN (
  				SELECT MIN(`spree_variants`.id)
  				FROM `spree_variants`
  				GROUP BY `spree_variants`.product_id
  				HAVING COUNT(*) = 1
  			))
  		AND spree_prices.currency = %s
  		AND spree_prices.amount IS NOT NULL
  	ORDER BY `spree_variants`.`position` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 613
table.insert(_stmts, {
  app = "spree", stmt_id = 613,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 614
table.insert(_stmts, {
  app = "spree", stmt_id = 614,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_payments`
  	WHERE `spree_payments`.`order_id` = %s
  	ORDER BY `spree_payments`.`created_at` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 615
table.insert(_stmts, {
  app = "spree", stmt_id = 615,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  ORDER BY `spree_payment_methods`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 616
table.insert(_stmts, {
  app = "spree", stmt_id = 616,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`id` IN (%s)
  	AND `spree_payment_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 617
table.insert(_stmts, {
  app = "spree", stmt_id = 617,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`number` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 618
table.insert(_stmts, {
  app = "spree", stmt_id = 618,
  sql = [[
  SELECT SUM(`spree_payment_capture_events`.`amount`)
  FROM `spree_payment_capture_events`
  WHERE `spree_payment_capture_events`.`payment_id` = %s
  ]],
  params = {
    {table = "spree_payment_capture_events", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 619
table.insert(_stmts, {
  app = "spree", stmt_id = 619,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 620
table.insert(_stmts, {
  app = "spree", stmt_id = 620,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_payments`
  	WHERE `spree_payments`.`order_id` = %s
  	ORDER BY `spree_payments`.`created_at` ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 621
table.insert(_stmts, {
  app = "spree", stmt_id = 621,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 622
table.insert(_stmts, {
  app = "spree", stmt_id = 622,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 623
table.insert(_stmts, {
  app = "spree", stmt_id = 623,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`number` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 624
table.insert(_stmts, {
  app = "spree", stmt_id = 624,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  	AND `spree_addresses`.`firstname` IS NULL
  	AND `spree_addresses`.`lastname` = %s
  	AND `spree_addresses`.`address1` = %s
  	AND `spree_addresses`.`address2` IS NULL
  	AND `spree_addresses`.`city` = %s
  	AND `spree_addresses`.`zipcode` = %s
  	AND `spree_addresses`.`phone` = %s
  	AND `spree_addresses`.`state_name` IS NULL
  	AND `spree_addresses`.`alternative_phone` IS NULL
  	AND `spree_addresses`.`company` IS NULL
  	AND `spree_addresses`.`state_id` IS NULL
  	AND `spree_addresses`.`country_id` = %s
  	AND `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  ORDER BY updated_at DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "lastname", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "address1", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "city", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "zipcode", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "phone", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 625
table.insert(_stmts, {
  app = "spree", stmt_id = 625,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  	AND `spree_addresses`.`firstname` = %s
  	AND `spree_addresses`.`lastname` = %s
  	AND `spree_addresses`.`address1` = %s
  	AND `spree_addresses`.`address2` IS NULL
  	AND `spree_addresses`.`city` = %s
  	AND `spree_addresses`.`zipcode` = %s
  	AND `spree_addresses`.`phone` = %s
  	AND `spree_addresses`.`state_name` IS NULL
  	AND `spree_addresses`.`alternative_phone` IS NULL
  	AND `spree_addresses`.`company` IS NULL
  	AND `spree_addresses`.`state_id` IS NULL
  	AND `spree_addresses`.`country_id` = %s
  	AND `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  ORDER BY updated_at DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "firstname", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "lastname", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "address1", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "city", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "zipcode", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "phone", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 626
table.insert(_stmts, {
  app = "spree", stmt_id = 626,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_line_items`.`id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_line_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 627
table.insert(_stmts, {
  app = "spree", stmt_id = 627,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 628
table.insert(_stmts, {
  app = "spree", stmt_id = 628,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 629
table.insert(_stmts, {
  app = "spree", stmt_id = 629,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  	INNER JOIN `spree_shipping_rates` ON `spree_shipping_methods`.`id` = `spree_shipping_rates`.`shipping_method_id`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_rates`.`shipment_id` = %s
  ORDER BY `spree_shipping_rates`.`cost` ASC
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 630
table.insert(_stmts, {
  app = "spree", stmt_id = 630,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  	INNER JOIN `spree_shipping_method_categories` ON `spree_shipping_categories`.`id` = `spree_shipping_method_categories`.`shipping_category_id`
  WHERE `spree_shipping_method_categories`.`shipping_method_id` = %s
  ]],
  params = {
    {table = "spree_shipping_method_categories", col = "shipping_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 631
table.insert(_stmts, {
  app = "spree", stmt_id = 631,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 632
table.insert(_stmts, {
  app = "spree", stmt_id = 632,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  	ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 633
table.insert(_stmts, {
  app = "spree", stmt_id = 633,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 634
table.insert(_stmts, {
  app = "spree", stmt_id = 634,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`user_id` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 635
table.insert(_stmts, {
  app = "spree", stmt_id = 635,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 636
table.insert(_stmts, {
  app = "spree", stmt_id = 636,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 637
table.insert(_stmts, {
  app = "spree", stmt_id = 637,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  ]],
  params = {
  }
})

-- stmt 638
table.insert(_stmts, {
  app = "spree", stmt_id = 638,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 639
table.insert(_stmts, {
  app = "spree", stmt_id = 639,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 640
table.insert(_stmts, {
  app = "spree", stmt_id = 640,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`email` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 641
table.insert(_stmts, {
  app = "spree", stmt_id = 641,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`email` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 642
table.insert(_stmts, {
  app = "spree", stmt_id = 642,
  sql = [[
  SELECT DISTINCT spree_stock_locations.`id`, spree_stock_locations.`name`, spree_stock_locations.`created_at`, spree_stock_locations.`updated_at`, spree_stock_locations.`default`
  	, spree_stock_locations.`address1`, spree_stock_locations.`address2`, spree_stock_locations.`city`, spree_stock_locations.`state_id`, spree_stock_locations.`state_name`
  	, spree_stock_locations.`country_id`, spree_stock_locations.`zipcode`, spree_stock_locations.`phone`, spree_stock_locations.`active`, spree_stock_locations.`backorderable_default`
  	, spree_stock_locations.`propagate_all_variants`, spree_stock_locations.`admin_name`
  FROM `spree_stock_locations`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = `spree_stock_locations`.`id`
  WHERE `spree_stock_locations`.`active` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 643
table.insert(_stmts, {
  app = "spree", stmt_id = 643,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NULL
  ORDER BY `spree_orders`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 644
table.insert(_stmts, {
  app = "spree", stmt_id = 644,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products`.`id` = `spree_products_taxons`.`product_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products_taxons`.`taxon_id` = %s
  ORDER BY `spree_products_taxons`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 645
table.insert(_stmts, {
  app = "spree", stmt_id = 645,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`product_id` = %s
  	AND `spree_products_taxons`.`taxon_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 646
table.insert(_stmts, {
  app = "spree", stmt_id = 646,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`id` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_products_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 647
table.insert(_stmts, {
  app = "spree", stmt_id = 647,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  	AND `spree_products_taxons`.`position` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 648
table.insert(_stmts, {
  app = "spree", stmt_id = 648,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  	AND `spree_products_taxons`.`product_id` = %s
  ORDER BY `spree_products_taxons`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 649
table.insert(_stmts, {
  app = "spree", stmt_id = 649,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 650
table.insert(_stmts, {
  app = "spree", stmt_id = 650,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products`.`id` = `spree_products_taxons`.`product_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products_taxons`.`taxon_id` = %s
  ORDER BY `spree_products_taxons`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 651
table.insert(_stmts, {
  app = "spree", stmt_id = 651,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `friendly_id_slugs`
  	ON `friendly_id_slugs`.`deleted_at` IS NULL
  		AND `friendly_id_slugs`.`sluggable_id` = `spree_products`.`id`
  		AND `friendly_id_slugs`.`sluggable_type` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`slug` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 652
table.insert(_stmts, {
  app = "spree", stmt_id = 652,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`id` = %s
  ORDER BY `spree_assets`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 653
table.insert(_stmts, {
  app = "spree", stmt_id = 653,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_assets`
  ]],
  params = {
  }
})

-- stmt 654
table.insert(_stmts, {
  app = "spree", stmt_id = 654,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`position` = %s
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 655
table.insert(_stmts, {
  app = "spree", stmt_id = 655,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 656
table.insert(_stmts, {
  app = "spree", stmt_id = 656,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`name` LIKE %s
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_locations", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 657
table.insert(_stmts, {
  app = "spree", stmt_id = 657,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_locations`
  	WHERE `spree_stock_locations`.`name` LIKE %s
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_locations", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 658
table.insert(_stmts, {
  app = "spree", stmt_id = 658,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  ORDER BY name ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 659
table.insert(_stmts, {
  app = "spree", stmt_id = 659,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_locations`
  	ORDER BY name ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 660
table.insert(_stmts, {
  app = "spree", stmt_id = 660,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_locations`
  ]],
  params = {
  }
})

-- stmt 661
table.insert(_stmts, {
  app = "spree", stmt_id = 661,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 662
table.insert(_stmts, {
  app = "spree", stmt_id = 662,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_locations`
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 663
table.insert(_stmts, {
  app = "spree", stmt_id = 663,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  ORDER BY `spree_stock_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 664
table.insert(_stmts, {
  app = "spree", stmt_id = 664,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 665
table.insert(_stmts, {
  app = "spree", stmt_id = 665,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 666
table.insert(_stmts, {
  app = "spree", stmt_id = 666,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_items`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 667
table.insert(_stmts, {
  app = "spree", stmt_id = 667,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 668
table.insert(_stmts, {
  app = "spree", stmt_id = 668,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_items`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 669
table.insert(_stmts, {
  app = "spree", stmt_id = 669,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 670
table.insert(_stmts, {
  app = "spree", stmt_id = 670,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`count_on_hand` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 671
table.insert(_stmts, {
  app = "spree", stmt_id = 671,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_items`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  		AND `spree_stock_items`.`count_on_hand` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 672
table.insert(_stmts, {
  app = "spree", stmt_id = 672,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`variant_id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 673
table.insert(_stmts, {
  app = "spree", stmt_id = 673,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_items`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  		AND `spree_stock_items`.`variant_id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 674
table.insert(_stmts, {
  app = "spree", stmt_id = 674,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 675
table.insert(_stmts, {
  app = "spree", stmt_id = 675,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id, `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	LEFT JOIN `spree_promotion_actions`
  	ON `spree_promotion_actions`.`deleted_at` IS NULL
  		AND `spree_promotion_actions`.`promotion_id` = `spree_promotions`.`id`
  WHERE lower(spree_promotions.code) = %s
  	AND `spree_promotion_actions`.`id` IS NOT NULL
  	AND `spree_promotions`.`id` = %s
  ORDER BY `spree_promotions`.`id` ASC
  ]],
  params = {
    {table = "spree_promotions", col = "code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 676
table.insert(_stmts, {
  app = "spree", stmt_id = 676,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_movements`.`quantity` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "quantity", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 677
table.insert(_stmts, {
  app = "spree", stmt_id = 677,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_movements`
  		INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  		AND `spree_stock_movements`.`quantity` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "quantity", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 678
table.insert(_stmts, {
  app = "spree", stmt_id = 678,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_movements`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 679
table.insert(_stmts, {
  app = "spree", stmt_id = 679,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 680
table.insert(_stmts, {
  app = "spree", stmt_id = 680,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_movements`
  		INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 681
table.insert(_stmts, {
  app = "spree", stmt_id = 681,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 682
table.insert(_stmts, {
  app = "spree", stmt_id = 682,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 683
table.insert(_stmts, {
  app = "spree", stmt_id = 683,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_movements`
  		INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  	WHERE `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 684
table.insert(_stmts, {
  app = "spree", stmt_id = 684,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
  }
})

-- stmt 685
table.insert(_stmts, {
  app = "spree", stmt_id = 685,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` IN (%s)
  ORDER BY `spree_option_values`.`position` ASC
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 686
table.insert(_stmts, {
  app = "spree", stmt_id = 686,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`name` LIKE %s
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_option_types", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 687
table.insert(_stmts, {
  app = "spree", stmt_id = 687,
  sql = [[
  SELECT `spree_product_option_types`.`id` AS _spree_product_option_types_id
  FROM `spree_product_option_types`
  WHERE `spree_product_option_types`.`option_type_id` = %s
  ]],
  params = {
    {table = "spree_product_option_types", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 688
table.insert(_stmts, {
  app = "spree", stmt_id = 688,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_zones", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 689
table.insert(_stmts, {
  app = "spree", stmt_id = 689,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 690
table.insert(_stmts, {
  app = "spree", stmt_id = 690,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ORDER BY name ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 691
table.insert(_stmts, {
  app = "spree", stmt_id = 691,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_zones`
  	ORDER BY name ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 692
table.insert(_stmts, {
  app = "spree", stmt_id = 692,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 693
table.insert(_stmts, {
  app = "spree", stmt_id = 693,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_zones`
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 694
table.insert(_stmts, {
  app = "spree", stmt_id = 694,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`name` LIKE %s
  ORDER BY name ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_zones", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 695
table.insert(_stmts, {
  app = "spree", stmt_id = 695,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_zones`
  	WHERE `spree_zones`.`name` LIKE %s
  	ORDER BY name ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_zones", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 696
table.insert(_stmts, {
  app = "spree", stmt_id = 696,
  sql = [[
  SELECT DISTINCT `id`, `name`, `description`, `available_on`, `discontinue_on`
  	, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`
  	, `shipping_category_id`, `created_at`, `updated_at`, `promotionable`, `meta_title`
  FROM `spree_products`
  WHERE (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 697
table.insert(_stmts, {
  app = "spree", stmt_id = 697,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  	WHERE (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 698
table.insert(_stmts, {
  app = "spree", stmt_id = 698,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	INNER JOIN `spree_product_option_types` ON `spree_option_types`.`id` = `spree_product_option_types`.`option_type_id`
  WHERE `spree_product_option_types`.`product_id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 699
table.insert(_stmts, {
  app = "spree", stmt_id = 699,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  WHERE `spree_shipping_categories`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_categories", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 700
table.insert(_stmts, {
  app = "spree", stmt_id = 700,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 701
table.insert(_stmts, {
  app = "spree", stmt_id = 701,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`name` = %s
  ORDER BY `spree_properties`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 702
table.insert(_stmts, {
  app = "spree", stmt_id = 702,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_product_properties`.`position` IS NOT NULL
  ORDER BY `spree_product_properties`.`position` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 703
table.insert(_stmts, {
  app = "spree", stmt_id = 703,
  sql = [[
  SELECT DISTINCT `id`, `name`, `description`, `available_on`, `discontinue_on`
  	, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`
  	, `shipping_category_id`, `created_at`, `updated_at`, `promotionable`, `meta_title`
  FROM `spree_products`
  WHERE `spree_products`.discontinue_on IS NULL
  	OR `spree_products`.discontinue_on >= %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 704
table.insert(_stmts, {
  app = "spree", stmt_id = 704,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  	WHERE `spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 705
table.insert(_stmts, {
  app = "spree", stmt_id = 705,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 706
table.insert(_stmts, {
  app = "spree", stmt_id = 706,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 707
table.insert(_stmts, {
  app = "spree", stmt_id = 707,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_product_properties`.`property_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_product_properties", col = "property_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 708
table.insert(_stmts, {
  app = "spree", stmt_id = 708,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 709
table.insert(_stmts, {
  app = "spree", stmt_id = 709,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`slug` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 710
table.insert(_stmts, {
  app = "spree", stmt_id = 710,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` = %s
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 711
table.insert(_stmts, {
  app = "spree", stmt_id = 711,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`created_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 712
table.insert(_stmts, {
  app = "spree", stmt_id = 712,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  		, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  		, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	ORDER BY `spree_products`.`created_at` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 713
table.insert(_stmts, {
  app = "spree", stmt_id = 713,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`id` IN (%s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 714
table.insert(_stmts, {
  app = "spree", stmt_id = 714,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_products`.`id` IN (%s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 715
table.insert(_stmts, {
  app = "spree", stmt_id = 715,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `friendly_id_slugs`
  	ON `friendly_id_slugs`.`deleted_at` IS NULL
  		AND `friendly_id_slugs`.`sluggable_id` = `spree_products`.`id`
  		AND `friendly_id_slugs`.`sluggable_type` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`slug` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 716
table.insert(_stmts, {
  app = "spree", stmt_id = 716,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`id` = NULL
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 717
table.insert(_stmts, {
  app = "spree", stmt_id = 717,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_products`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 718
table.insert(_stmts, {
  app = "spree", stmt_id = 718,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 719
table.insert(_stmts, {
  app = "spree", stmt_id = 719,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 720
table.insert(_stmts, {
  app = "spree", stmt_id = 720,
  sql = [[
  SELECT COUNT(DISTINCT `spree_products`.`id`)
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 721
table.insert(_stmts, {
  app = "spree", stmt_id = 721,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  ORDER BY `spree_product_properties`.`position` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 722
table.insert(_stmts, {
  app = "spree", stmt_id = 722,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 723
table.insert(_stmts, {
  app = "spree", stmt_id = 723,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_product_properties`.`value` LIKE %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_product_properties", col = "value", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 724
table.insert(_stmts, {
  app = "spree", stmt_id = 724,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_product_properties`
  	WHERE `spree_product_properties`.`product_id` = %s
  		AND `spree_product_properties`.`value` LIKE %s
  	ORDER BY `spree_product_properties`.`position` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_product_properties", col = "value", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 725
table.insert(_stmts, {
  app = "spree", stmt_id = 725,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 726
table.insert(_stmts, {
  app = "spree", stmt_id = 726,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_product_properties`
  	WHERE `spree_product_properties`.`product_id` = %s
  	ORDER BY `spree_product_properties`.`position` ASC
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 727
table.insert(_stmts, {
  app = "spree", stmt_id = 727,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 728
table.insert(_stmts, {
  app = "spree", stmt_id = 728,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 729
table.insert(_stmts, {
  app = "spree", stmt_id = 729,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_product_properties`
  	WHERE `spree_product_properties`.`product_id` = %s
  	ORDER BY `spree_product_properties`.`position` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 730
table.insert(_stmts, {
  app = "spree", stmt_id = 730,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  	LEFT JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_properties`.`name` LIKE %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 731
table.insert(_stmts, {
  app = "spree", stmt_id = 731,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_product_properties`
  		LEFT JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  	WHERE `spree_product_properties`.`product_id` = %s
  		AND `spree_properties`.`name` LIKE %s
  	ORDER BY `spree_product_properties`.`position` ASC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 732
table.insert(_stmts, {
  app = "spree", stmt_id = 732,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_product_properties`.`id` = NULL
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 733
table.insert(_stmts, {
  app = "spree", stmt_id = 733,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id, `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  	LEFT JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_properties`.`name` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 734
table.insert(_stmts, {
  app = "spree", stmt_id = 734,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_product_properties`.`id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_product_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 735
table.insert(_stmts, {
  app = "spree", stmt_id = 735,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 736
table.insert(_stmts, {
  app = "spree", stmt_id = 736,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`number` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 737
table.insert(_stmts, {
  app = "spree", stmt_id = 737,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  	INNER JOIN `spree_orders` ON `spree_orders`.`id` = `spree_shipments`.`order_id`
  WHERE `spree_orders`.`user_id` = %s
  ORDER BY coalesce(spree_shipments.shipped_at, spree_shipments.created_at) DESC, `spree_shipments`.`id` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 738
table.insert(_stmts, {
  app = "spree", stmt_id = 738,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`id` = %s
  ]],
  params = {
    {table = "spree_addresses", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 739
table.insert(_stmts, {
  app = "spree", stmt_id = 739,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`id` = %s
  ]],
  params = {
    {table = "spree_states", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 740
table.insert(_stmts, {
  app = "spree", stmt_id = 740,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`id` = %s
  ]],
  params = {
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 741
table.insert(_stmts, {
  app = "spree", stmt_id = 741,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_shipments`
  		INNER JOIN `spree_orders` ON `spree_orders`.`id` = `spree_shipments`.`order_id`
  	WHERE `spree_orders`.`user_id` = %s
  	ORDER BY coalesce(spree_shipments.shipped_at, spree_shipments.created_at) DESC, `spree_shipments`.`id` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 742
table.insert(_stmts, {
  app = "spree", stmt_id = 742,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 743
table.insert(_stmts, {
  app = "spree", stmt_id = 743,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`id` = %s
  	AND `spree_users`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 744
table.insert(_stmts, {
  app = "spree", stmt_id = 744,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 745
table.insert(_stmts, {
  app = "spree", stmt_id = 745,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_credit_cards`
  	WHERE `spree_credit_cards`.`deleted_at` IS NULL
  		AND `spree_credit_cards`.`user_id` = %s
  		AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 746
table.insert(_stmts, {
  app = "spree", stmt_id = 746,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 747
table.insert(_stmts, {
  app = "spree", stmt_id = 747,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_credit_cards`
  	WHERE `spree_credit_cards`.`deleted_at` IS NULL
  		AND `spree_credit_cards`.`user_id` = %s
  		AND `spree_credit_cards`.`user_id` = %s
  		AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 748
table.insert(_stmts, {
  app = "spree", stmt_id = 748,
  sql = [[
  SELECT SUM(`spree_payments`.`amount`)
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`state` NOT IN (%s)
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 749
table.insert(_stmts, {
  app = "spree", stmt_id = 749,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 750
table.insert(_stmts, {
  app = "spree", stmt_id = 750,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_state_changes`
  WHERE `spree_state_changes`.`stateful_id` = %s
  	AND `spree_state_changes`.`stateful_type` = %s
  ]],
  params = {
    {table = "spree_state_changes", col = "stateful_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "stateful_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 751
table.insert(_stmts, {
  app = "spree", stmt_id = 751,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`id` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 752
table.insert(_stmts, {
  app = "spree", stmt_id = 752,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 753
table.insert(_stmts, {
  app = "spree", stmt_id = 753,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_users`
  	WHERE `spree_users`.`id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 754
table.insert(_stmts, {
  app = "spree", stmt_id = 754,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_users`
  ]],
  params = {
  }
})

-- stmt 755
table.insert(_stmts, {
  app = "spree", stmt_id = 755,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_users`
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 756
table.insert(_stmts, {
  app = "spree", stmt_id = 756,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 757
table.insert(_stmts, {
  app = "spree", stmt_id = 757,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_users`
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 758
table.insert(_stmts, {
  app = "spree", stmt_id = 758,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  	LEFT JOIN `spree_addresses` ON `spree_addresses`.`id` = `spree_users`.`ship_address_id`
  WHERE spree_addresses.firstname LIKE %s
  	OR spree_addresses.lastname LIKE %s
  ]],
  params = {
    {table = "spree_addresses", col = "firstname", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_addresses", col = "lastname", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 759
table.insert(_stmts, {
  app = "spree", stmt_id = 759,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  	LEFT JOIN `spree_addresses` ON `spree_addresses`.`id` = `spree_users`.`bill_address_id`
  WHERE spree_addresses.firstname LIKE %s
  	OR spree_addresses.lastname LIKE %s
  ]],
  params = {
    {table = "spree_addresses", col = "firstname", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_addresses", col = "lastname", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 760
table.insert(_stmts, {
  app = "spree", stmt_id = 760,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE email LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 761
table.insert(_stmts, {
  app = "spree", stmt_id = 761,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_users`
  	WHERE email LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 762
table.insert(_stmts, {
  app = "spree", stmt_id = 762,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE email LIKE %s
  	OR `spree_users`.`id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 763
table.insert(_stmts, {
  app = "spree", stmt_id = 763,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_users`
  	WHERE email LIKE %s
  		OR `spree_users`.`id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 764
table.insert(_stmts, {
  app = "spree", stmt_id = 764,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE `spree_promotions`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 765
table.insert(_stmts, {
  app = "spree", stmt_id = 765,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  ORDER BY `spree_reimbursements`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 766
table.insert(_stmts, {
  app = "spree", stmt_id = 766,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_reimbursements`
  	ORDER BY `spree_reimbursements`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 767
table.insert(_stmts, {
  app = "spree", stmt_id = 767,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 768
table.insert(_stmts, {
  app = "spree", stmt_id = 768,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 769
table.insert(_stmts, {
  app = "spree", stmt_id = 769,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_properties`
  	WHERE `spree_properties`.`id` = %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 770
table.insert(_stmts, {
  app = "spree", stmt_id = 770,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`name` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 771
table.insert(_stmts, {
  app = "spree", stmt_id = 771,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_properties`
  	WHERE `spree_properties`.`name` LIKE %s
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 772
table.insert(_stmts, {
  app = "spree", stmt_id = 772,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`id` IN (%s)
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 773
table.insert(_stmts, {
  app = "spree", stmt_id = 773,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_properties`
  	WHERE `spree_properties`.`id` IN (%s)
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 774
table.insert(_stmts, {
  app = "spree", stmt_id = 774,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 775
table.insert(_stmts, {
  app = "spree", stmt_id = 775,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_properties`
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 776
table.insert(_stmts, {
  app = "spree", stmt_id = 776,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 777
table.insert(_stmts, {
  app = "spree", stmt_id = 777,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_properties`
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 778
table.insert(_stmts, {
  app = "spree", stmt_id = 778,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_properties`
  ]],
  params = {
  }
})

-- stmt 779
table.insert(_stmts, {
  app = "spree", stmt_id = 779,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  	AND `spree_return_items`.`acceptance_status` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "acceptance_status", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 780
table.insert(_stmts, {
  app = "spree", stmt_id = 780,
  sql = [[
  SELECT SUM(`spree_return_items`.`pre_tax_amount`)
  FROM `spree_return_items`
  WHERE `spree_return_items`.`customer_return_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 781
table.insert(_stmts, {
  app = "spree", stmt_id = 781,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_customer_returns`
  	ORDER BY `spree_customer_returns`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 782
table.insert(_stmts, {
  app = "spree", stmt_id = 782,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`name` LIKE %s
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_taxonomies", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 783
table.insert(_stmts, {
  app = "spree", stmt_id = 783,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxonomies`
  	WHERE `spree_taxonomies`.`name` LIKE %s
  	ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_taxonomies", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 784
table.insert(_stmts, {
  app = "spree", stmt_id = 784,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 785
table.insert(_stmts, {
  app = "spree", stmt_id = 785,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxonomies`
  	ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 786
table.insert(_stmts, {
  app = "spree", stmt_id = 786,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  LIMIT %s, 2
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 787
table.insert(_stmts, {
  app = "spree", stmt_id = 787,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_taxonomies`
  	ORDER BY spree_taxonomies.position, spree_taxonomies.created_at, name
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 788
table.insert(_stmts, {
  app = "spree", stmt_id = 788,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxonomies`
  ]],
  params = {
  }
})

-- stmt 789
table.insert(_stmts, {
  app = "spree", stmt_id = 789,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_option_value_variants`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 790
table.insert(_stmts, {
  app = "spree", stmt_id = 790,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_store_credit_categories`
  ]],
  params = {
  }
})

-- stmt 791
table.insert(_stmts, {
  app = "spree", stmt_id = 791,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`eligible` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 792
table.insert(_stmts, {
  app = "spree", stmt_id = 792,
  sql = [[
  SELECT `spree_calculators`.`id` AS _spree_calculators_id
  FROM `spree_calculators`
  WHERE `spree_calculators`.`deleted_at` IS NULL
  ORDER BY `spree_calculators`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 793
table.insert(_stmts, {
  app = "spree", stmt_id = 793,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE `spree_promotions`.`advertise` = %s
  ]],
  params = {
    {table = "spree_promotions", col = "advertise", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 794
table.insert(_stmts, {
  app = "spree", stmt_id = 794,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE `spree_promotions`.`code` IS NOT NULL
  ]],
  params = {
  }
})

-- stmt 795
table.insert(_stmts, {
  app = "spree", stmt_id = 795,
  sql = [[
  SELECT DISTINCT spree_promotions.`id`, spree_promotions.`description`, spree_promotions.`expires_at`, spree_promotions.`starts_at`, spree_promotions.`name`
  	, spree_promotions.`type`, spree_promotions.`usage_limit`, spree_promotions.`match_policy`, spree_promotions.`code`, spree_promotions.`advertise`
  	, spree_promotions.`path`, spree_promotions.`created_at`, spree_promotions.`updated_at`, spree_promotions.`promotion_category_id`
  FROM `spree_promotions`
  	INNER JOIN spree_order_promotions ON spree_order_promotions.promotion_id = spree_promotions.id
  ]],
  params = {
  }
})

-- stmt 796
table.insert(_stmts, {
  app = "spree", stmt_id = 796,
  sql = [[
  SELECT `spree_promotion_rules`.`id` AS _spree_promotion_rules_id
  FROM `spree_promotion_rules`
  WHERE `spree_promotion_rules`.`promotion_id` = %s
  	AND `spree_promotion_rules`.`type` = %s
  ]],
  params = {
    {table = "spree_promotion_rules", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_rules", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 797
table.insert(_stmts, {
  app = "spree", stmt_id = 797,
  sql = [[
  SELECT `spree_promotion_rules`.`id` AS _spree_promotion_rules_id
  FROM `spree_promotion_rules`
  WHERE `spree_promotion_rules`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_rules", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 798
table.insert(_stmts, {
  app = "spree", stmt_id = 798,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_product_promotion_rules` ON `spree_products`.`id` = `spree_product_promotion_rules`.`product_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_product_promotion_rules`.`promotion_rule_id` = %s
  ]],
  params = {
    {table = "spree_product_promotion_rules", col = "promotion_rule_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 799
table.insert(_stmts, {
  app = "spree", stmt_id = 799,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 800
table.insert(_stmts, {
  app = "spree", stmt_id = 800,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 801
table.insert(_stmts, {
  app = "spree", stmt_id = 801,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_orders` ON `spree_orders`.`id` = `spree_adjustments`.`order_id`
  WHERE `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_orders`.`completed_at` IS NULL
  ]],
  params = {
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 802
table.insert(_stmts, {
  app = "spree", stmt_id = 802,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_promotion_rules`
  ]],
  params = {
  }
})

-- stmt 803
table.insert(_stmts, {
  app = "spree", stmt_id = 803,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 804
table.insert(_stmts, {
  app = "spree", stmt_id = 804,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_line_items`.`id` != %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_line_items", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 805
table.insert(_stmts, {
  app = "spree", stmt_id = 805,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_line_items", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 806
table.insert(_stmts, {
  app = "spree", stmt_id = 806,
  sql = [[
  SELECT `spree_shipping_rates`.`id` AS _spree_shipping_rates_id
  FROM `spree_shipping_rates`
  WHERE `spree_shipping_rates`.`shipment_id` = %s
  ORDER BY `spree_shipping_rates`.`cost` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 807
table.insert(_stmts, {
  app = "spree", stmt_id = 807,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  ORDER BY `spree_inventory_units`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 808
table.insert(_stmts, {
  app = "spree", stmt_id = 808,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`variant_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 809
table.insert(_stmts, {
  app = "spree", stmt_id = 809,
  sql = [[
  SELECT SUM(`spree_stock_items`.`count_on_hand`)
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 810
table.insert(_stmts, {
  app = "spree", stmt_id = 810,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 811
table.insert(_stmts, {
  app = "spree", stmt_id = 811,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  	AND `spree_inventory_units`.`state` IN (%s)
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 812
table.insert(_stmts, {
  app = "spree", stmt_id = 812,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  	AND `spree_inventory_units`.`state` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 813
table.insert(_stmts, {
  app = "spree", stmt_id = 813,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_items`.`variant_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 814
table.insert(_stmts, {
  app = "spree", stmt_id = 814,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 815
table.insert(_stmts, {
  app = "spree", stmt_id = 815,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_shipments`
  ]],
  params = {
  }
})

-- stmt 816
table.insert(_stmts, {
  app = "spree", stmt_id = 816,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  	INNER JOIN `spree_shipments` ON `spree_adjustments`.`adjustable_id` = `spree_shipments`.`id`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 817
table.insert(_stmts, {
  app = "spree", stmt_id = 817,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_shipments` ON `spree_adjustments`.`adjustable_id` = `spree_shipments`.`id`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_adjustments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 818
table.insert(_stmts, {
  app = "spree", stmt_id = 818,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_shipments` ON `spree_adjustments`.`adjustable_id` = `spree_shipments`.`id`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_adjustments`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 819
table.insert(_stmts, {
  app = "spree", stmt_id = 819,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_shipments`.`id` NOT IN (%s)
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipments", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 820
table.insert(_stmts, {
  app = "spree", stmt_id = 820,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 821
table.insert(_stmts, {
  app = "spree", stmt_id = 821,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`line_item_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "line_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 822
table.insert(_stmts, {
  app = "spree", stmt_id = 822,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  ORDER BY `spree_assets`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 823
table.insert(_stmts, {
  app = "spree", stmt_id = 823,
  sql = [[
  SELECT SUM(`spree_tax_rates`.`amount`)
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`zone_id` = %s
  	AND `spree_tax_rates`.`included_in_price` = %s
  	AND `spree_tax_rates`.`tax_category_id` = %s
  ]],
  params = {
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "included_in_price", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "tax_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 824
table.insert(_stmts, {
  app = "spree", stmt_id = 824,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zoneable_id` = %s
  	AND `spree_zone_members`.`zoneable_type` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 825
table.insert(_stmts, {
  app = "spree", stmt_id = 825,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` = %s
  ORDER BY `spree_promotion_actions`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 826
table.insert(_stmts, {
  app = "spree", stmt_id = 826,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants` ON `spree_products`.`id` = `spree_variants`.`product_id`
  	INNER JOIN `spree_line_items` ON `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_variants`.`deleted_at` IS NULL
  	AND `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 827
table.insert(_stmts, {
  app = "spree", stmt_id = 827,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants` ON `spree_products`.`id` = `spree_variants`.`product_id`
  	INNER JOIN `spree_line_items` ON `spree_variants`.`id` = `spree_line_items`.`variant_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_variants`.`deleted_at` IS NULL
  	AND `spree_line_items`.`order_id` = %s
  ORDER BY `spree_line_items`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 828
table.insert(_stmts, {
  app = "spree", stmt_id = 828,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_promotion_rule_taxons` ON `spree_taxons`.`id` = `spree_promotion_rule_taxons`.`taxon_id`
  WHERE `spree_promotion_rule_taxons`.`promotion_rule_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rule_taxons", col = "promotion_rule_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 829
table.insert(_stmts, {
  app = "spree", stmt_id = 829,
  sql = [[
  SELECT DISTINCT spree_taxons.`id`, spree_taxons.`parent_id`, spree_taxons.`position`, spree_taxons.`name`, spree_taxons.`permalink`
  	, spree_taxons.`taxonomy_id`, spree_taxons.`lft`, spree_taxons.`rgt`, spree_taxons.`description`, spree_taxons.`created_at`
  	, spree_taxons.`updated_at`, spree_taxons.`meta_title`, spree_taxons.`meta_description`, spree_taxons.`meta_keywords`, spree_taxons.`depth`
  	, spree_taxons.`hide_from_nav`
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`taxon_id` = `spree_taxons`.`id`
  	INNER JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`id` = `spree_products_taxons`.`product_id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_line_items` ON `spree_line_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_taxons`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 830
table.insert(_stmts, {
  app = "spree", stmt_id = 830,
  sql = [[
  SELECT DISTINCT spree_taxons.`id`, spree_taxons.`parent_id`, spree_taxons.`position`, spree_taxons.`name`, spree_taxons.`permalink`
  	, spree_taxons.`taxonomy_id`, spree_taxons.`lft`, spree_taxons.`rgt`, spree_taxons.`description`, spree_taxons.`created_at`
  	, spree_taxons.`updated_at`, spree_taxons.`meta_title`, spree_taxons.`meta_description`, spree_taxons.`meta_keywords`, spree_taxons.`depth`
  	, spree_taxons.`hide_from_nav`
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`taxon_id` = `spree_taxons`.`id`
  	INNER JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`id` = `spree_products_taxons`.`product_id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_line_items` ON `spree_line_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_taxons`.`id` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 831
table.insert(_stmts, {
  app = "spree", stmt_id = 831,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_promotion_rule_taxons` ON `spree_taxons`.`id` = `spree_promotion_rule_taxons`.`taxon_id`
  WHERE `spree_promotion_rule_taxons`.`promotion_rule_id` = %s
  ]],
  params = {
    {table = "spree_promotion_rule_taxons", col = "promotion_rule_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 832
table.insert(_stmts, {
  app = "spree", stmt_id = 832,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_taxons`.`id` = %s
  ]],
  params = {
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 833
table.insert(_stmts, {
  app = "spree", stmt_id = 833,
  sql = [[
  SELECT DISTINCT spree_return_items.`id`, spree_return_items.`return_authorization_id`, spree_return_items.`inventory_unit_id`, spree_return_items.`exchange_variant_id`, spree_return_items.`created_at`
  	, spree_return_items.`updated_at`, spree_return_items.`pre_tax_amount`, spree_return_items.`included_tax_total`, spree_return_items.`additional_tax_total`, spree_return_items.`reception_status`
  	, spree_return_items.`acceptance_status`, spree_return_items.`customer_return_id`, spree_return_items.`reimbursement_id`, spree_return_items.`acceptance_status_errors`, spree_return_items.`preferred_reimbursement_type_id`
  	, spree_return_items.`override_reimbursement_type_id`, spree_return_items.`resellable`
  FROM `spree_return_items`
  	INNER JOIN `spree_inventory_units` ON `spree_inventory_units`.`original_return_item_id` = `spree_return_items`.`id`
  WHERE `spree_return_items`.`reception_status` = %s
  	AND (spree_inventory_units.created_at < %s
  		AND spree_inventory_units.state = %s)
  ]],
  params = {
    {table = "spree_return_items", col = "reception_status", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "created_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 834
table.insert(_stmts, {
  app = "spree", stmt_id = 834,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  	AND (spree_stock_items.count_on_hand > %s
  		OR spree_variants.track_inventory = %s
  		OR `spree_stock_items`.`backorderable` = %s)
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "track_inventory", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "backorderable", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 835
table.insert(_stmts, {
  app = "spree", stmt_id = 835,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`original_return_item_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "original_return_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 836
table.insert(_stmts, {
  app = "spree", stmt_id = 836,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_inventory_units", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 837
table.insert(_stmts, {
  app = "spree", stmt_id = 837,
  sql = [[
  SELECT DISTINCT spree_stock_locations.`id`, spree_stock_locations.`name`, spree_stock_locations.`created_at`, spree_stock_locations.`updated_at`, spree_stock_locations.`default`
  	, spree_stock_locations.`address1`, spree_stock_locations.`address2`, spree_stock_locations.`city`, spree_stock_locations.`state_id`, spree_stock_locations.`state_name`
  	, spree_stock_locations.`country_id`, spree_stock_locations.`zipcode`, spree_stock_locations.`phone`, spree_stock_locations.`active`, spree_stock_locations.`backorderable_default`
  	, spree_stock_locations.`propagate_all_variants`, spree_stock_locations.`admin_name`
  FROM `spree_stock_locations`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`stock_location_id` = `spree_stock_locations`.`id`
  WHERE `spree_stock_locations`.`active` = %s
  	AND `spree_stock_items`.`variant_id` IN (%s)
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 838
table.insert(_stmts, {
  app = "spree", stmt_id = 838,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  ORDER BY `spree_shipments`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 839
table.insert(_stmts, {
  app = "spree", stmt_id = 839,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`original_return_item_id` = %s
  ORDER BY `spree_inventory_units`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "original_return_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 840
table.insert(_stmts, {
  app = "spree", stmt_id = 840,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payments`
  ]],
  params = {
  }
})

-- stmt 841
table.insert(_stmts, {
  app = "spree", stmt_id = 841,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`default` = %s
  ORDER BY `spree_credit_cards`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 842
table.insert(_stmts, {
  app = "spree", stmt_id = 842,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_prices`.`currency` = %s
  	LIMIT %s, 12
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 843
table.insert(_stmts, {
  app = "spree", stmt_id = 843,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		INNER JOIN `spree_prices` `default_prices_spree_variants`
  		ON `default_prices_spree_variants`.`deleted_at` IS NULL
  			AND `default_prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  			AND `default_prices_spree_variants`.`currency` = %s
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_prices`.`amount` <= %s
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_prices`.`currency` = %s
  	LIMIT %s, 12
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 844
table.insert(_stmts, {
  app = "spree", stmt_id = 844,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`name` NOT LIKE %s
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_prices`.`currency` = %s
  	LIMIT %s, 12
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "NOT LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 845
table.insert(_stmts, {
  app = "spree", stmt_id = 845,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_prices`.`currency` = %s
  	LIMIT %s, 2
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 846
table.insert(_stmts, {
  app = "spree", stmt_id = 846,
  sql = [[
  SELECT COUNT(count_column)
  FROM (
  	SELECT DISTINCT `spree_products`.`id` AS count_column
  	FROM `spree_products`
  		INNER JOIN `spree_variants`
  		ON `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = `spree_products`.`id`
  			AND `spree_variants`.`is_master` = %s
  		INNER JOIN `spree_prices`
  		ON `spree_prices`.`deleted_at` IS NULL
  			AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		INNER JOIN `spree_prices` `default_prices_spree_variants`
  		ON `default_prices_spree_variants`.`deleted_at` IS NULL
  			AND `default_prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  			AND `default_prices_spree_variants`.`currency` = %s
  	WHERE `spree_products`.`deleted_at` IS NULL
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_products`.deleted_at IS NULL
  			OR `spree_products`.deleted_at >= %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND (`spree_prices`.`amount` <= %s
  			OR `spree_prices`.`amount` BETWEEN %s AND %s)
  		AND (`spree_products`.discontinue_on IS NULL
  			OR `spree_products`.discontinue_on >= %s)
  		AND `spree_products`.available_on <= %s
  		AND spree_prices.amount IS NOT NULL
  		AND `spree_prices`.`currency` = %s
  	LIMIT %s, 12
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_begin", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "amount", clause = "where", pos = "between_end", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 847
table.insert(_stmts, {
  app = "spree", stmt_id = 847,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND spree_prices.amount IS NOT NULL
  	AND `spree_prices`.`currency` = %s
  LIMIT %s, 12
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 848
table.insert(_stmts, {
  app = "spree", stmt_id = 848,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`id` = %s
  ]],
  params = {
    {table = "spree_tax_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 849
table.insert(_stmts, {
  app = "spree", stmt_id = 849,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` IS NULL
  	AND `spree_assets`.`viewable_type` IS NULL
  	AND `spree_assets`.`position` >= %s
  	AND `spree_assets`.id != %s
  ORDER BY `spree_assets`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "position", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 850
table.insert(_stmts, {
  app = "spree", stmt_id = 850,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND `spree_taxons`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  	AND spree_prices.amount IS NOT NULL
  	AND `spree_prices`.`currency` = %s
  ORDER BY `spree_products`.`id` ASC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 851
table.insert(_stmts, {
  app = "spree", stmt_id = 851,
  sql = [[
  SELECT `active_storage_attachments`.`id` AS _active_storage_attachments_id
  FROM `active_storage_attachments`
  WHERE `active_storage_attachments`.`record_type` = %s
  	AND `active_storage_attachments`.`name` = %s
  	AND `active_storage_attachments`.`record_id` IN (%s)
  ]],
  params = {
    {table = "active_storage_attachments", col = "record_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "record_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 852
table.insert(_stmts, {
  app = "spree", stmt_id = 852,
  sql = [[
  SELECT `active_storage_blobs`.`id` AS _active_storage_blobs_id
  FROM `active_storage_blobs`
  WHERE `active_storage_blobs`.`id` IN (%s)
  ]],
  params = {
    {table = "active_storage_blobs", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 853
table.insert(_stmts, {
  app = "spree", stmt_id = 853,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  	INNER JOIN `spree_zone_members` ON `spree_countries`.`id` = `spree_zone_members`.`zoneable_id`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND `spree_zone_members`.`zoneable_type` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 854
table.insert(_stmts, {
  app = "spree", stmt_id = 854,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  	INNER JOIN `spree_zone_members` ON `spree_states`.`id` = `spree_zone_members`.`zoneable_id`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND `spree_zone_members`.`zoneable_type` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 855
table.insert(_stmts, {
  app = "spree", stmt_id = 855,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  	INNER JOIN `spree_zone_members` ON `spree_states`.`id` = `spree_zone_members`.`zoneable_id`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND `spree_zone_members`.`zoneable_type` = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 856
table.insert(_stmts, {
  app = "spree", stmt_id = 856,
  sql = [[
  SELECT DISTINCT spree_zones.`id`, spree_zones.`name`, spree_zones.`description`, spree_zones.`default_tax`, spree_zones.`zone_members_count`
  	, spree_zones.`created_at`, spree_zones.`updated_at`, spree_zones.`kind`
  FROM `spree_zones`
  	INNER JOIN `spree_zone_members` ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  WHERE (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id IN (%s))
  	OR (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id IN (%s))
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 857
table.insert(_stmts, {
  app = "spree", stmt_id = 857,
  sql = [[
  SELECT DISTINCT spree_zones.`id`, spree_zones.`name`, spree_zones.`description`, spree_zones.`default_tax`, spree_zones.`zone_members_count`
  	, spree_zones.`created_at`, spree_zones.`updated_at`, spree_zones.`kind`
  FROM `spree_zones`
  	INNER JOIN `spree_zone_members`
  	ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  		AND `spree_zone_members`.`zoneable_type` = %s
  	INNER JOIN `spree_countries` ON `spree_countries`.`id` = `spree_zone_members`.`zoneable_id`
  	INNER JOIN `spree_zone_members` `zone_members_spree_countries_join`
  	ON `zone_members_spree_countries_join`.`zoneable_id` = `spree_countries`.`id`
  		AND `zone_members_spree_countries_join`.`zoneable_type` = %s
  	INNER JOIN `spree_zones` `zones_spree_countries` ON `zones_spree_countries`.`id` = `zone_members_spree_countries_join`.`zone_id`
  WHERE zone_members_spree_countries_join.zone_id = %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 858
table.insert(_stmts, {
  app = "spree", stmt_id = 858,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id, `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zones`
  	LEFT JOIN `spree_zone_members` ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  WHERE (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = NULL)
  	OR (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id = NULL)
  ORDER BY spree_zones.zone_members_count, spree_zones.created_at
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 859
table.insert(_stmts, {
  app = "spree", stmt_id = 859,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`default_tax` = %s
  ]],
  params = {
    {table = "spree_zones", col = "default_tax", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 860
table.insert(_stmts, {
  app = "spree", stmt_id = 860,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 861
table.insert(_stmts, {
  app = "spree", stmt_id = 861,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE zoneable_id IS NULL
  	OR zoneable_type != %s
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 862
table.insert(_stmts, {
  app = "spree", stmt_id = 862,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`store_id` = %s
  	AND `spree_orders`.`completed_at` IS NULL
  ORDER BY created_at DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 863
table.insert(_stmts, {
  app = "spree", stmt_id = 863,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  	AND `spree_assets`.`position` >= %s
  	AND `spree_assets`.id != %s
  ORDER BY `spree_assets`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "position", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 864
table.insert(_stmts, {
  app = "spree", stmt_id = 864,
  sql = [[
  SELECT `active_storage_blobs`.`id` AS _active_storage_blobs_id
  FROM `active_storage_blobs`
  	INNER JOIN `active_storage_attachments` ON `active_storage_blobs`.`id` = `active_storage_attachments`.`blob_id`
  WHERE `active_storage_attachments`.`record_id` = %s
  	AND `active_storage_attachments`.`record_type` = %s
  	AND `active_storage_attachments`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "active_storage_attachments", col = "record_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "record_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "active_storage_attachments", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 865
table.insert(_stmts, {
  app = "spree", stmt_id = 865,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_option_values`
  ]],
  params = {
  }
})

-- stmt 866
table.insert(_stmts, {
  app = "spree", stmt_id = 866,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 867
table.insert(_stmts, {
  app = "spree", stmt_id = 867,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`user_id` = %s
  	AND `spree_credit_cards`.`gateway_customer_profile_id` IS NOT NULL
  ORDER BY `spree_credit_cards`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 868
table.insert(_stmts, {
  app = "spree", stmt_id = 868,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_addresses`
  ]],
  params = {
  }
})

-- stmt 869
table.insert(_stmts, {
  app = "spree", stmt_id = 869,
  sql = [[
  SELECT `spree_state_changes`.`id` AS _spree_state_changes_id
  FROM `spree_state_changes`
  WHERE `spree_state_changes`.`stateful_id` = %s
  	AND `spree_state_changes`.`stateful_type` = %s
  ORDER BY `spree_state_changes`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_state_changes", col = "stateful_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "stateful_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 870
table.insert(_stmts, {
  app = "spree", stmt_id = 870,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 871
table.insert(_stmts, {
  app = "spree", stmt_id = 871,
  sql = [[
  SELECT DISTINCT spree_shipping_categories.`id`, spree_shipping_categories.`name`, spree_shipping_categories.`created_at`, spree_shipping_categories.`updated_at`
  FROM `spree_shipping_categories`
  	INNER JOIN `spree_products`
  	ON `spree_products`.`deleted_at` IS NULL
  		AND `spree_products`.`shipping_category_id` = `spree_shipping_categories`.`id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  ]],
  params = {
  }
})

-- stmt 872
table.insert(_stmts, {
  app = "spree", stmt_id = 872,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 873
table.insert(_stmts, {
  app = "spree", stmt_id = 873,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`state` IN (%s)
  ]],
  params = {
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 874
table.insert(_stmts, {
  app = "spree", stmt_id = 874,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`state` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 875
table.insert(_stmts, {
  app = "spree", stmt_id = 875,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  	INNER JOIN `spree_return_items` ON `spree_return_authorizations`.`id` = `spree_return_items`.`return_authorization_id`
  WHERE `spree_return_items`.`inventory_unit_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "inventory_unit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 876
table.insert(_stmts, {
  app = "spree", stmt_id = 876,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`shipment_id` = %s
  	AND `spree_inventory_units`.`pending` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_inventory_units", col = "pending", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 877
table.insert(_stmts, {
  app = "spree", stmt_id = 877,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  	INNER JOIN `spree_shipping_rates` ON `spree_shipping_methods`.`id` = `spree_shipping_rates`.`shipping_method_id`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_rates`.`shipment_id` = %s
  ORDER BY `spree_shipping_rates`.`cost` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_rates", col = "shipment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 878
table.insert(_stmts, {
  app = "spree", stmt_id = 878,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 879
table.insert(_stmts, {
  app = "spree", stmt_id = 879,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`tax_category_id` = %s
  	AND `spree_tax_rates`.`zone_id` = %s
  ORDER BY `spree_tax_rates`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "tax_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 880
table.insert(_stmts, {
  app = "spree", stmt_id = 880,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`authorization_code` = %s
  	AND `spree_store_credit_events`.`action` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_events", col = "authorization_code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "action", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 881
table.insert(_stmts, {
  app = "spree", stmt_id = 881,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`authorization_code` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_events", col = "authorization_code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 882
table.insert(_stmts, {
  app = "spree", stmt_id = 882,
  sql = [[
  SELECT `spree_store_credits`.`id` AS _spree_store_credits_id
  FROM `spree_store_credits`
  WHERE `spree_store_credits`.`id` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_store_credits", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 883
table.insert(_stmts, {
  app = "spree", stmt_id = 883,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  	AND `spree_store_credit_events`.`action` = %s
  	AND `spree_store_credit_events`.`authorization_code` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "action", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "authorization_code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 884
table.insert(_stmts, {
  app = "spree", stmt_id = 884,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  WHERE `spree_stock_movements`.`stock_item_id` = %s
  	AND `spree_stock_movements`.`quantity` = %s
  	AND `spree_stock_movements`.`originator_type` = %s
  	AND `spree_stock_movements`.`originator_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_movements", col = "stock_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "quantity", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "originator_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "originator_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 885
table.insert(_stmts, {
  app = "spree", stmt_id = 885,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`inventory_unit_id` IS NULL
  	AND `spree_return_items`.`reception_status` IN (%s)
  ORDER BY `spree_return_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "reception_status", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 886
table.insert(_stmts, {
  app = "spree", stmt_id = 886,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_option_values`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_option_value_variants`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 887
table.insert(_stmts, {
  app = "spree", stmt_id = 887,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 888
table.insert(_stmts, {
  app = "spree", stmt_id = 888,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (spree_stock_items.count_on_hand > %s
  		OR spree_variants.track_inventory = %s)
  ]],
  params = {
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "track_inventory", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 889
table.insert(_stmts, {
  app = "spree", stmt_id = 889,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ]],
  params = {
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 890
table.insert(_stmts, {
  app = "spree", stmt_id = 890,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.deleted_at IS NULL
  ]],
  params = {
  }
})

-- stmt 891
table.insert(_stmts, {
  app = "spree", stmt_id = 891,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`discontinue_on` IS NULL
  		OR `spree_variants`.`discontinue_on` >= %s)
  ]],
  params = {
    {table = "spree_variants", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 892
table.insert(_stmts, {
  app = "spree", stmt_id = 892,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`is_master` = %s
  		OR `spree_variants`.id IN (
  			SELECT MIN(`spree_variants`.id)
  			FROM `spree_variants`
  			GROUP BY `spree_variants`.product_id
  			HAVING COUNT(*) = 1
  		))
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 893
table.insert(_stmts, {
  app = "spree", stmt_id = 893,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_type` IN (%s)
  ]],
  params = {
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 894
table.insert(_stmts, {
  app = "spree", stmt_id = 894,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 895
table.insert(_stmts, {
  app = "spree", stmt_id = 895,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_type` != %s
  	OR `spree_adjustments`.`source_type` IS NULL
  ]],
  params = {
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 896
table.insert(_stmts, {
  app = "spree", stmt_id = 896,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_orders` ON `spree_orders`.`id` = `spree_adjustments`.`order_id`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
  }
})

-- stmt 897
table.insert(_stmts, {
  app = "spree", stmt_id = 897,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_orders` ON `spree_orders`.`id` = `spree_adjustments`.`order_id`
  WHERE `spree_orders`.`completed_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 898
table.insert(_stmts, {
  app = "spree", stmt_id = 898,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 899
table.insert(_stmts, {
  app = "spree", stmt_id = 899,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products_taxons`
  ]],
  params = {
  }
})

-- stmt 900
table.insert(_stmts, {
  app = "spree", stmt_id = 900,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products`.`id` = `spree_products_taxons`.`product_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products_taxons`.`taxon_id` = %s
  ORDER BY `spree_products_taxons`.`position` ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 901
table.insert(_stmts, {
  app = "spree", stmt_id = 901,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`product_id` = %s
  	AND `spree_products_taxons`.`taxon_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 902
table.insert(_stmts, {
  app = "spree", stmt_id = 902,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`product_id` = %s
  ORDER BY `spree_products_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 903
table.insert(_stmts, {
  app = "spree", stmt_id = 903,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  	AND `spree_products_taxons`.`product_id` = %s
  ORDER BY `spree_products_taxons`.`position` ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 904
table.insert(_stmts, {
  app = "spree", stmt_id = 904,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 905
table.insert(_stmts, {
  app = "spree", stmt_id = 905,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 906
table.insert(_stmts, {
  app = "spree", stmt_id = 906,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 907
table.insert(_stmts, {
  app = "spree", stmt_id = 907,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 908
table.insert(_stmts, {
  app = "spree", stmt_id = 908,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND `spree_promotions`.`id` = %s
  	AND `spree_promotions`.`path` IS NULL
  ]],
  params = {
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 909
table.insert(_stmts, {
  app = "spree", stmt_id = 909,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` IN (%s)
  	AND `spree_stock_items`.`backorderable` = %s
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "backorderable", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 910
table.insert(_stmts, {
  app = "spree", stmt_id = 910,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` IN (%s)
  	AND (spree_stock_items.count_on_hand > %s
  		OR spree_variants.track_inventory = %s)
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "count_on_hand", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "track_inventory", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 911
table.insert(_stmts, {
  app = "spree", stmt_id = 911,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`payment_method_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "payment_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 912
table.insert(_stmts, {
  app = "spree", stmt_id = 912,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_reimbursement_credits`
  ]],
  params = {
  }
})

-- stmt 913
table.insert(_stmts, {
  app = "spree", stmt_id = 913,
  sql = [[
  SELECT `spree_store_credit_categories`.`id` AS _spree_store_credit_categories_id
  FROM `spree_store_credit_categories`
  ORDER BY `spree_store_credit_categories`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 914
table.insert(_stmts, {
  app = "spree", stmt_id = 914,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`email` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 915
table.insert(_stmts, {
  app = "spree", stmt_id = 915,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  	INNER JOIN `spree_stock_locations` ON `spree_stock_locations`.`id` = `spree_stock_items`.`stock_location_id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_locations`.`active` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 916
table.insert(_stmts, {
  app = "spree", stmt_id = 916,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 917
table.insert(_stmts, {
  app = "spree", stmt_id = 917,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 918
table.insert(_stmts, {
  app = "spree", stmt_id = 918,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  ORDER BY `spree_store_credit_events`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 919
table.insert(_stmts, {
  app = "spree", stmt_id = 919,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  WHERE `spree_refunds`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_refunds", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 920
table.insert(_stmts, {
  app = "spree", stmt_id = 920,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  ORDER BY `spree_store_credit_events`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 921
table.insert(_stmts, {
  app = "spree", stmt_id = 921,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`action` = %s
  ]],
  params = {
    {table = "spree_store_credit_events", col = "action", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 922
table.insert(_stmts, {
  app = "spree", stmt_id = 922,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payment_capture_events`
  WHERE `spree_payment_capture_events`.`payment_id` = %s
  ]],
  params = {
    {table = "spree_payment_capture_events", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 923
table.insert(_stmts, {
  app = "spree", stmt_id = 923,
  sql = [[
  SELECT `spree_payment_capture_events`.`id` AS _spree_payment_capture_events_id
  FROM `spree_payment_capture_events`
  WHERE `spree_payment_capture_events`.`payment_id` = %s
  ORDER BY `spree_payment_capture_events`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_capture_events", col = "payment_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 924
table.insert(_stmts, {
  app = "spree", stmt_id = 924,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE avs_response IN (%s)
  	OR (cvv_response_code IS NOT NULL
  		AND cvv_response_code != %s)
  	OR state = %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "avs_response", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "cvv_response_code", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 925
table.insert(_stmts, {
  app = "spree", stmt_id = 925,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`state` NOT IN (%s)
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "state", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 926
table.insert(_stmts, {
  app = "spree", stmt_id = 926,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 927
table.insert(_stmts, {
  app = "spree", stmt_id = 927,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 928
table.insert(_stmts, {
  app = "spree", stmt_id = 928,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_adjustments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 929
table.insert(_stmts, {
  app = "spree", stmt_id = 929,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  ]],
  params = {
  }
})

-- stmt 930
table.insert(_stmts, {
  app = "spree", stmt_id = 930,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 931
table.insert(_stmts, {
  app = "spree", stmt_id = 931,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  LIMIT 5
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 932
table.insert(_stmts, {
  app = "spree", stmt_id = 932,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`line_item_id` = %s
  ORDER BY `spree_inventory_units`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_inventory_units", col = "line_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 933
table.insert(_stmts, {
  app = "spree", stmt_id = 933,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_refunds`
  ]],
  params = {
  }
})

-- stmt 934
table.insert(_stmts, {
  app = "spree", stmt_id = 934,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  ORDER BY `spree_refunds`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 935
table.insert(_stmts, {
  app = "spree", stmt_id = 935,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`email` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_orders", col = "email", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 936
table.insert(_stmts, {
  app = "spree", stmt_id = 936,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  	INNER JOIN `spree_variants` ON `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 937
table.insert(_stmts, {
  app = "spree", stmt_id = 937,
  sql = [[
  SELECT `spree_prototypes`.`id` AS _spree_prototypes_id
  FROM `spree_prototypes`
  WHERE `spree_prototypes`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_prototypes", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 938
table.insert(_stmts, {
  app = "spree", stmt_id = 938,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  	INNER JOIN `spree_property_prototypes` ON `spree_properties`.`id` = `spree_property_prototypes`.`property_id`
  WHERE `spree_property_prototypes`.`prototype_id` = %s
  ]],
  params = {
    {table = "spree_property_prototypes", col = "prototype_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 939
table.insert(_stmts, {
  app = "spree", stmt_id = 939,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	INNER JOIN `spree_option_type_prototypes` ON `spree_option_types`.`id` = `spree_option_type_prototypes`.`option_type_id`
  WHERE `spree_option_type_prototypes`.`prototype_id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_option_type_prototypes", col = "prototype_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 940
table.insert(_stmts, {
  app = "spree", stmt_id = 940,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_prototype_taxons` ON `spree_taxons`.`id` = `spree_prototype_taxons`.`taxon_id`
  WHERE `spree_prototype_taxons`.`prototype_id` = %s
  ]],
  params = {
    {table = "spree_prototype_taxons", col = "prototype_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 941
table.insert(_stmts, {
  app = "spree", stmt_id = 941,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_properties`
  	INNER JOIN `spree_product_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_product_properties`.`product_id` = %s
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 942
table.insert(_stmts, {
  app = "spree", stmt_id = 942,
  sql = [[
  SELECT `spree_product_option_types`.`id` AS _spree_product_option_types_id
  FROM `spree_product_option_types`
  WHERE `spree_product_option_types`.`product_id` = %s
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 943
table.insert(_stmts, {
  app = "spree", stmt_id = 943,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	INNER JOIN `spree_product_option_types` ON `spree_option_types`.`id` = `spree_product_option_types`.`option_type_id`
  WHERE `spree_product_option_types`.`product_id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 944
table.insert(_stmts, {
  app = "spree", stmt_id = 944,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_product_properties`.`product_id` = %s
  	AND `spree_properties`.`name` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 945
table.insert(_stmts, {
  app = "spree", stmt_id = 945,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  	INNER JOIN `spree_product_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_product_properties`.`product_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  ]],
  params = {
    {table = "spree_product_properties", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 946
table.insert(_stmts, {
  app = "spree", stmt_id = 946,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_promotion_rules` ON `spree_promotions`.`id` = `spree_promotion_rules`.`promotion_id`
  	INNER JOIN `spree_product_promotion_rules` ON `spree_promotion_rules`.`id` = `spree_product_promotion_rules`.`promotion_rule_id`
  WHERE `spree_product_promotion_rules`.`product_id` = %s
  	AND `spree_promotions`.`advertise` = %s
  	AND (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  ]],
  params = {
    {table = "spree_product_promotion_rules", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "advertise", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 947
table.insert(_stmts, {
  app = "spree", stmt_id = 947,
  sql = [[
  SELECT `spree_option_value_variants`.`id` AS _spree_option_value_variants_id
  FROM `spree_option_value_variants`
  WHERE `spree_option_value_variants`.`variant_id` = %s
  	AND `spree_option_value_variants`.`option_value_id` = %s
  ]],
  params = {
    {table = "spree_option_value_variants", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_value_variants", col = "option_value_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 948
table.insert(_stmts, {
  app = "spree", stmt_id = 948,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  	AND (`spree_variants`.`discontinue_on` IS NULL
  		OR `spree_variants`.`discontinue_on` >= %s)
  	AND `spree_variants`.deleted_at IS NULL
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 949
table.insert(_stmts, {
  app = "spree", stmt_id = 949,
  sql = [[
  SELECT `friendly_id_slugs`.`id` AS _friendly_id_slugs_id
  FROM `friendly_id_slugs`
  WHERE `friendly_id_slugs`.`sluggable_id` = %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`deleted_at` IS NOT NULL
  ORDER BY `friendly_id_slugs`.`id` DESC
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 950
table.insert(_stmts, {
  app = "spree", stmt_id = 950,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`deleted_at` IS NOT NULL
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 951
table.insert(_stmts, {
  app = "spree", stmt_id = 951,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`deleted_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 952
table.insert(_stmts, {
  app = "spree", stmt_id = 952,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`variant_id` = %s
  	AND `spree_prices`.`deleted_at` IS NOT NULL
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 953
table.insert(_stmts, {
  app = "spree", stmt_id = 953,
  sql = [[
  SELECT `friendly_id_slugs`.`id` AS _friendly_id_slugs_id
  FROM `friendly_id_slugs`
  WHERE `friendly_id_slugs`.`deleted_at` IS NULL
  	AND `friendly_id_slugs`.`sluggable_id` = %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  	AND `friendly_id_slugs`.`slug` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "slug", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 954
table.insert(_stmts, {
  app = "spree", stmt_id = 954,
  sql = [[
  SELECT `friendly_id_slugs`.`id` AS _friendly_id_slugs_id
  FROM `friendly_id_slugs`
  WHERE `friendly_id_slugs`.`sluggable_id` = %s
  	AND `friendly_id_slugs`.`sluggable_type` = %s
  ORDER BY `friendly_id_slugs`.`id` DESC
  ]],
  params = {
    {table = "friendly_id_slugs", col = "sluggable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "friendly_id_slugs", col = "sluggable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 955
table.insert(_stmts, {
  app = "spree", stmt_id = 955,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`product_id` = %s
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 956
table.insert(_stmts, {
  app = "spree", stmt_id = 956,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`taxonomy_id` = %s
  ORDER BY `spree_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "taxonomy_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 957
table.insert(_stmts, {
  app = "spree", stmt_id = 957,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  	INNER JOIN `spree_taxonomies` ON `spree_taxonomies`.`id` = `spree_taxons`.`taxonomy_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  	AND `spree_taxonomies`.`name` = %s
  ORDER BY `spree_taxons`.`depth` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxonomies", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 958
table.insert(_stmts, {
  app = "spree", stmt_id = 958,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  	INNER JOIN `spree_taxonomies` ON `spree_taxonomies`.`id` = `spree_taxons`.`taxonomy_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  	AND `spree_taxonomies`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxonomies", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 959
table.insert(_stmts, {
  app = "spree", stmt_id = 959,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 960
table.insert(_stmts, {
  app = "spree", stmt_id = 960,
  sql = [[
  SELECT `spree_assets`.`id` AS _spree_assets_id
  FROM `spree_assets`
  WHERE `spree_assets`.`viewable_id` = %s
  	AND `spree_assets`.`viewable_type` = %s
  ORDER BY `spree_assets`.`position` ASC
  ]],
  params = {
    {table = "spree_assets", col = "viewable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_assets", col = "viewable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 961
table.insert(_stmts, {
  app = "spree", stmt_id = 961,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`type` = %s
  	AND `spree_promotion_actions`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_actions", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_actions", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 962
table.insert(_stmts, {
  app = "spree", stmt_id = 962,
  sql = [[
  SELECT `spree_promotion_action_line_items`.`id` AS _spree_promotion_action_line_items_id
  FROM `spree_promotion_action_line_items`
  WHERE `spree_promotion_action_line_items`.`promotion_action_id` = %s
  ]],
  params = {
    {table = "spree_promotion_action_line_items", col = "promotion_action_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 963
table.insert(_stmts, {
  app = "spree", stmt_id = 963,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_line_items`.`variant_id` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_line_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 964
table.insert(_stmts, {
  app = "spree", stmt_id = 964,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  ORDER BY `spree_zone_members`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 965
table.insert(_stmts, {
  app = "spree", stmt_id = 965,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`display_on` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_methods", col = "display_on", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 966
table.insert(_stmts, {
  app = "spree", stmt_id = 966,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  	INNER JOIN `spree_order_promotions` ON `spree_promotions`.`id` = `spree_order_promotions`.`promotion_id`
  WHERE `spree_order_promotions`.`order_id` = %s
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 967
table.insert(_stmts, {
  app = "spree", stmt_id = 967,
  sql = [[
  SELECT `spree_line_items`.`id` AS _spree_line_items_id
  FROM `spree_line_items`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_line_items`.`currency` != %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_line_items", col = "currency", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 968
table.insert(_stmts, {
  app = "spree", stmt_id = 968,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`amount` IN (%s)
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 969
table.insert(_stmts, {
  app = "spree", stmt_id = 969,
  sql = [[
  SELECT `spree_order_promotions`.`id` AS _spree_order_promotions_id
  FROM `spree_order_promotions`
  WHERE `spree_order_promotions`.`order_id` = %s
  	AND `spree_order_promotions`.`promotion_id` IN (%s)
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_order_promotions", col = "promotion_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 970
table.insert(_stmts, {
  app = "spree", stmt_id = 970,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
  }
})

-- stmt 971
table.insert(_stmts, {
  app = "spree", stmt_id = 971,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 972
table.insert(_stmts, {
  app = "spree", stmt_id = 972,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  	AND `spree_adjustments`.amount != %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`adjustable_type` != %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 973
table.insert(_stmts, {
  app = "spree", stmt_id = 973,
  sql = [[
  SELECT `spree_state_changes`.`id` AS _spree_state_changes_id
  FROM `spree_state_changes`
  WHERE `spree_state_changes`.`stateful_id` = %s
  	AND `spree_state_changes`.`stateful_type` = %s
  	AND `spree_state_changes`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_state_changes", col = "stateful_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "stateful_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_state_changes", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 974
table.insert(_stmts, {
  app = "spree", stmt_id = 974,
  sql = [[
  SELECT `spree_refunds`.`id` AS _spree_refunds_id
  FROM `spree_refunds`
  WHERE `spree_refunds`.`payment_id` IN (%s)
  ]],
  params = {
    {table = "spree_refunds", col = "payment_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 975
table.insert(_stmts, {
  app = "spree", stmt_id = 975,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_order_promotions`
  WHERE `spree_order_promotions`.`order_id` = %s
  ]],
  params = {
    {table = "spree_order_promotions", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 976
table.insert(_stmts, {
  app = "spree", stmt_id = 976,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`id` = %s
  LIMIT 2
  FOR UPDATE
  ]],
  params = {
    {table = "spree_orders", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 977
table.insert(_stmts, {
  app = "spree", stmt_id = 977,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	INNER JOIN `spree_product_option_types` ON `spree_option_types`.`id` = `spree_product_option_types`.`option_type_id`
  WHERE `spree_product_option_types`.`product_id` = %s
  ORDER BY `spree_option_types`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_product_option_types", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 978
table.insert(_stmts, {
  app = "spree", stmt_id = 978,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` IN (
  		SELECT DISTINCT `spree_variants`.`id`
  		FROM `spree_variants`
  			INNER JOIN `spree_prices`
  			ON `spree_prices`.`deleted_at` IS NULL
  				AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  		WHERE `spree_variants`.`deleted_at` IS NULL
  			AND `spree_variants`.`product_id` = %s
  			AND `spree_variants`.`is_master` = %s
  			AND (`spree_variants`.`discontinue_on` IS NULL
  				OR `spree_variants`.`discontinue_on` >= %s)
  			AND `spree_variants`.deleted_at IS NULL
  			AND spree_prices.currency = %s
  			AND spree_prices.amount IS NOT NULL
  	)
  ORDER BY spree_option_values.position ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 979
table.insert(_stmts, {
  app = "spree", stmt_id = 979,
  sql = [[
  SELECT SUM(`spree_return_items`.`pre_tax_amount`)
  FROM `spree_return_items`
  WHERE `spree_return_items`.`return_authorization_id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "return_authorization_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 980
table.insert(_stmts, {
  app = "spree", stmt_id = 980,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_reimbursements`
  ]],
  params = {
  }
})

-- stmt 981
table.insert(_stmts, {
  app = "spree", stmt_id = 981,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  ORDER BY `spree_reimbursements`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 982
table.insert(_stmts, {
  app = "spree", stmt_id = 982,
  sql = [[
  SELECT `spree_return_authorizations`.`id` AS _spree_return_authorizations_id
  FROM `spree_return_authorizations`
  	INNER JOIN `spree_return_items` ON `spree_return_authorizations`.`id` = `spree_return_items`.`return_authorization_id`
  WHERE `spree_return_items`.`customer_return_id` = %s
  ORDER BY `spree_return_authorizations`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_items", col = "customer_return_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 983
table.insert(_stmts, {
  app = "spree", stmt_id = 983,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` >= %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "position", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 984
table.insert(_stmts, {
  app = "spree", stmt_id = 984,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` <= %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "position", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 985
table.insert(_stmts, {
  app = "spree", stmt_id = 985,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` > %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "position", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 986
table.insert(_stmts, {
  app = "spree", stmt_id = 986,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`position` < %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "position", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 987
table.insert(_stmts, {
  app = "spree", stmt_id = 987,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 988
table.insert(_stmts, {
  app = "spree", stmt_id = 988,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_adjustments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 989
table.insert(_stmts, {
  app = "spree", stmt_id = 989,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 990
table.insert(_stmts, {
  app = "spree", stmt_id = 990,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ORDER BY `spree_adjustments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 991
table.insert(_stmts, {
  app = "spree", stmt_id = 991,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  ORDER BY `spree_adjustments`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 992
table.insert(_stmts, {
  app = "spree", stmt_id = 992,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`eligible` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 993
table.insert(_stmts, {
  app = "spree", stmt_id = 993,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id, `spree_option_types`.`id` AS _spree_option_types_id, `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_option_types`
  	LEFT JOIN `spree_option_values` ON `spree_option_values`.`option_type_id` = `spree_option_types`.`id`
  	LEFT JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`option_value_id` = `spree_option_values`.`id`
  	LEFT JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`id` = `spree_option_value_variants`.`variant_id`
  WHERE `spree_variants`.`id` IN (%s)
  ORDER BY spree_option_types.position ASC, spree_option_values.position ASC
  ]],
  params = {
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 994
table.insert(_stmts, {
  app = "spree", stmt_id = 994,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  	INNER JOIN `spree_line_items` ON `spree_adjustments`.`adjustable_id` = `spree_line_items`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 995
table.insert(_stmts, {
  app = "spree", stmt_id = 995,
  sql = [[
  SELECT `spree_promotions`.`id` AS _spree_promotions_id
  FROM `spree_promotions`
  WHERE (spree_promotions.starts_at IS NULL
  		OR spree_promotions.starts_at < %s)
  	AND (spree_promotions.expires_at IS NULL
  		OR spree_promotions.expires_at > %s)
  	AND `spree_promotions`.`path` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotions", col = "starts_at", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "expires_at", clause = "where", pos = "relation", operator = ">", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotions", col = "path", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 996
table.insert(_stmts, {
  app = "spree", stmt_id = 996,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`tax_category_id` = %s
  	AND `spree_tax_rates`.`zone_id` IN (%s)
  ORDER BY `spree_tax_rates`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "tax_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 997
table.insert(_stmts, {
  app = "spree", stmt_id = 997,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 998
table.insert(_stmts, {
  app = "spree", stmt_id = 998,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_shipments`.`id` != %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_shipments", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 999
table.insert(_stmts, {
  app = "spree", stmt_id = 999,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_shipments` ON `spree_adjustments`.`adjustable_id` = `spree_shipments`.`id`
  WHERE `spree_shipments`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1000
table.insert(_stmts, {
  app = "spree", stmt_id = 1000,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  LIMIT 11
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1001
table.insert(_stmts, {
  app = "spree", stmt_id = 1001,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` = %s
  	AND `spree_taxons`.`parent_id` = %s
  ORDER BY `spree_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1002
table.insert(_stmts, {
  app = "spree", stmt_id = 1002,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` = %s
  	AND `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  	AND `spree_taxons`.`id` != %s
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1003
table.insert(_stmts, {
  app = "spree", stmt_id = 1003,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`currency` IS NULL
  	AND `spree_orders`.`token` = %s
  	AND `spree_orders`.`store_id` IS NULL
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "token", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1004
table.insert(_stmts, {
  app = "spree", stmt_id = 1004,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` IN (%s)
  ORDER BY `spree_adjustments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1005
table.insert(_stmts, {
  app = "spree", stmt_id = 1005,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1006
table.insert(_stmts, {
  app = "spree", stmt_id = 1006,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items` ON `spree_stock_movements`.`stock_item_id` = `spree_stock_items`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`stock_location_id` = %s
  	AND `spree_stock_movements`.`stock_item_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "stock_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1007
table.insert(_stmts, {
  app = "spree", stmt_id = 1007,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`active` = %s
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1008
table.insert(_stmts, {
  app = "spree", stmt_id = 1008,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1009
table.insert(_stmts, {
  app = "spree", stmt_id = 1009,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`adjustable_id` IN (
  		SELECT `spree_line_items`.`id`
  		FROM `spree_line_items`
  		WHERE `spree_line_items`.`order_id` IS NULL
  		ORDER BY `spree_line_items`.`created_at` ASC
  	)
  	AND `spree_adjustments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1010
table.insert(_stmts, {
  app = "spree", stmt_id = 1010,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  ORDER BY `spree_payments`.`created_at` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1011
table.insert(_stmts, {
  app = "spree", stmt_id = 1011,
  sql = [[
  SELECT SUM(`spree_inventory_units`.`quantity`)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`line_item_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "line_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1012
table.insert(_stmts, {
  app = "spree", stmt_id = 1012,
  sql = [[
  SELECT SUM(`spree_stock_items`.`count_on_hand`)
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1013
table.insert(_stmts, {
  app = "spree", stmt_id = 1013,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  WHERE `spree_stock_movements`.`stock_item_id` = %s
  ORDER BY `spree_stock_movements`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_movements", col = "stock_item_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1014
table.insert(_stmts, {
  app = "spree", stmt_id = 1014,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`is_master` = %s
  	AND (`spree_variants`.`discontinue_on` IS NULL
  		OR `spree_variants`.`discontinue_on` >= %s)
  	AND `spree_variants`.deleted_at IS NULL
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1015
table.insert(_stmts, {
  app = "spree", stmt_id = 1015,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`name` LIKE %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "name", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 1016
table.insert(_stmts, {
  app = "spree", stmt_id = 1016,
  sql = [[
  SELECT `spree_dummy_models`.`id` AS _spree_dummy_models_id
  FROM `spree_dummy_models`
  WHERE `spree_dummy_models`.`name` = %s
  ]],
  params = {
    {table = "spree_dummy_models", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1017
table.insert(_stmts, {
  app = "spree", stmt_id = 1017,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1018
table.insert(_stmts, {
  app = "spree", stmt_id = 1018,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id, `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	LEFT JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products_taxons`.`taxon_id` IN (%s)
  ORDER BY spree_products_taxons.position ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1019
table.insert(_stmts, {
  app = "spree", stmt_id = 1019,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id
  FROM `spree_products_taxons`
  WHERE `spree_products_taxons`.`taxon_id` = %s
  	AND `spree_products_taxons`.`product_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1020
table.insert(_stmts, {
  app = "spree", stmt_id = 1020,
  sql = [[
  SELECT `spree_products_taxons`.`id` AS _spree_products_taxons_id, `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	LEFT JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products_taxons`.`taxon_id` = %s
  ORDER BY spree_products_taxons.position ASC
  ]],
  params = {
    {table = "spree_products_taxons", col = "taxon_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1021
table.insert(_stmts, {
  app = "spree", stmt_id = 1021,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1022
table.insert(_stmts, {
  app = "spree", stmt_id = 1022,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	INNER JOIN `spree_product_properties` ON `spree_product_properties`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_properties`.`id` = %s
  ]],
  params = {
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1023
table.insert(_stmts, {
  app = "spree", stmt_id = 1023,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	INNER JOIN `spree_product_properties` ON `spree_product_properties`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_properties`.`name` = %s
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1024
table.insert(_stmts, {
  app = "spree", stmt_id = 1024,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	INNER JOIN `spree_product_properties` ON `spree_product_properties`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND spree_product_properties.value = %s
  	AND `spree_properties`.`name` = %s
  ]],
  params = {
    {table = "spree_product_properties", col = "value", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1025
table.insert(_stmts, {
  app = "spree", stmt_id = 1025,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_products`
  	INNER JOIN `spree_product_properties` ON `spree_product_properties`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND spree_product_properties.value = %s
  	AND `spree_properties`.`id` = %s
  ]],
  params = {
    {table = "spree_product_properties", col = "value", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1026
table.insert(_stmts, {
  app = "spree", stmt_id = 1026,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`currency` = %s
  	AND `spree_orders`.`token` = %s
  	AND `spree_orders`.`store_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "token", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1027
table.insert(_stmts, {
  app = "spree", stmt_id = 1027,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NULL
  	AND `spree_orders`.`currency` = %s
  	AND `spree_orders`.`token` IS NULL
  	AND `spree_orders`.`store_id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "store_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1028
table.insert(_stmts, {
  app = "spree", stmt_id = 1028,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`user_id` = %s
  	AND `spree_orders`.`completed_at` IS NULL
  	AND id != %s
  ]],
  params = {
    {table = "spree_orders", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1029
table.insert(_stmts, {
  app = "spree", stmt_id = 1029,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_line_items` ON `spree_adjustments`.`adjustable_id` = `spree_line_items`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1030
table.insert(_stmts, {
  app = "spree", stmt_id = 1030,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_shipping_rates`
  ]],
  params = {
  }
})

-- stmt 1031
table.insert(_stmts, {
  app = "spree", stmt_id = 1031,
  sql = [[
  SELECT `spree_shipments`.`id` AS _spree_shipments_id
  FROM `spree_shipments`
  WHERE `spree_shipments`.`order_id` = %s
  ]],
  params = {
    {table = "spree_shipments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1032
table.insert(_stmts, {
  app = "spree", stmt_id = 1032,
  sql = [[
  SELECT `spree_log_entries`.`id` AS _spree_log_entries_id
  FROM `spree_log_entries`
  WHERE `spree_log_entries`.`source_id` = %s
  	AND `spree_log_entries`.`source_type` = %s
  ]],
  params = {
    {table = "spree_log_entries", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_log_entries", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1033
table.insert(_stmts, {
  app = "spree", stmt_id = 1033,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`state` = %s
  	AND `spree_payments`.`source_type` = %s
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1034
table.insert(_stmts, {
  app = "spree", stmt_id = 1034,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`type` = %s
  	AND `spree_payment_methods`.`id` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1035
table.insert(_stmts, {
  app = "spree", stmt_id = 1035,
  sql = [[
  SELECT DISTINCT `spree_products`.`id`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1036
table.insert(_stmts, {
  app = "spree", stmt_id = 1036,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1037
table.insert(_stmts, {
  app = "spree", stmt_id = 1037,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_prices` `default_prices_spree_variants`
  	ON `default_prices_spree_variants`.`deleted_at` IS NULL
  		AND `default_prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  		AND `default_prices_spree_variants`.`currency` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_prices`.amount DESC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1038
table.insert(_stmts, {
  app = "spree", stmt_id = 1038,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  	, spree_prices.amount
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_prices` `default_prices_spree_variants`
  	ON `default_prices_spree_variants`.`deleted_at` IS NULL
  		AND `default_prices_spree_variants`.`variant_id` = `spree_variants`.`id`
  		AND `default_prices_spree_variants`.`currency` = %s
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_prices`.amount ASC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1039
table.insert(_stmts, {
  app = "spree", stmt_id = 1039,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`available_on` DESC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1040
table.insert(_stmts, {
  app = "spree", stmt_id = 1040,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ORDER BY `spree_products`.`available_on` DESC
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1041
table.insert(_stmts, {
  app = "spree", stmt_id = 1041,
  sql = [[
  SELECT COUNT(DISTINCT `spree_option_values`.`option_type_id`)
  FROM `spree_option_values`
  WHERE `spree_option_values`.`id` = %s
  ]],
  params = {
    {table = "spree_option_values", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1042
table.insert(_stmts, {
  app = "spree", stmt_id = 1042,
  sql = [[
  SELECT DISTINCT `spree_products`.`id`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_option_values`.`id` = %s
  GROUP BY spree_products.id, spree_variants.id
  HAVING COUNT(spree_option_values.option_type_id) = 1
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1043
table.insert(_stmts, {
  app = "spree", stmt_id = 1043,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` IN (%s)
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1044
table.insert(_stmts, {
  app = "spree", stmt_id = 1044,
  sql = [[
  SELECT COUNT(DISTINCT `spree_option_values`.`option_type_id`)
  FROM `spree_option_values`
  WHERE `spree_option_values`.`id` IN (%s)
  ]],
  params = {
    {table = "spree_option_values", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1045
table.insert(_stmts, {
  app = "spree", stmt_id = 1045,
  sql = [[
  SELECT DISTINCT `spree_products`.`id`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_option_value_variants` ON `spree_option_value_variants`.`variant_id` = `spree_variants`.`id`
  	INNER JOIN `spree_option_values` ON `spree_option_values`.`id` = `spree_option_value_variants`.`option_value_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_option_values`.`id` IN (%s)
  GROUP BY spree_products.id, spree_variants.id
  HAVING COUNT(spree_option_values.option_type_id) = 2
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1046
table.insert(_stmts, {
  app = "spree", stmt_id = 1046,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`id` = %s
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1047
table.insert(_stmts, {
  app = "spree", stmt_id = 1047,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1048
table.insert(_stmts, {
  app = "spree", stmt_id = 1048,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1049
table.insert(_stmts, {
  app = "spree", stmt_id = 1049,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1050
table.insert(_stmts, {
  app = "spree", stmt_id = 1050,
  sql = [[
  SELECT DISTINCT spree_products.`id`, spree_products.`name`, spree_products.`description`, spree_products.`available_on`, spree_products.`discontinue_on`
  	, spree_products.`deleted_at`, spree_products.`slug`, spree_products.`meta_description`, spree_products.`meta_keywords`, spree_products.`tax_category_id`
  	, spree_products.`shipping_category_id`, spree_products.`created_at`, spree_products.`updated_at`, spree_products.`promotionable`, spree_products.`meta_title`
  FROM `spree_products`
  	INNER JOIN `spree_products_taxons` ON `spree_products_taxons`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  	INNER JOIN `spree_variants`
  	ON `spree_variants`.`deleted_at` IS NULL
  		AND `spree_variants`.`product_id` = `spree_products`.`id`
  		AND `spree_variants`.`is_master` = %s
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_taxons`.`id` IN (%s)
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  	AND (`spree_products`.discontinue_on IS NULL
  		OR `spree_products`.discontinue_on >= %s)
  	AND `spree_products`.available_on <= %s
  ]],
  params = {
    {table = "spree_variants", col = "is_master", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_products", col = "available_on", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1051
table.insert(_stmts, {
  app = "spree", stmt_id = 1051,
  sql = [[
  SELECT DISTINCT `id`, `name`, `description`, `available_on`, `discontinue_on`
  	, `deleted_at`, `slug`, `meta_description`, `meta_keywords`, `tax_category_id`
  	, `shipping_category_id`, `created_at`, `updated_at`, `promotionable`, `meta_title`
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND (`spree_products`.deleted_at IS NULL
  		OR `spree_products`.deleted_at >= %s)
  ]],
  params = {
    {table = "spree_products", col = "deleted_at", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1052
table.insert(_stmts, {
  app = "spree", stmt_id = 1052,
  sql = [[
  SELECT `spree_shipping_method_categories`.`id` AS _spree_shipping_method_categories_id
  FROM `spree_shipping_method_categories`
  WHERE `spree_shipping_method_categories`.`shipping_category_id` IN (%s)
  ]],
  params = {
    {table = "spree_shipping_method_categories", col = "shipping_category_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1053
table.insert(_stmts, {
  app = "spree", stmt_id = 1053,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`eligible` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` IN (%s)
  ]],
  params = {
    {table = "spree_adjustments", col = "eligible", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1054
table.insert(_stmts, {
  app = "spree", stmt_id = 1054,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` IN (%s)
  ]],
  params = {
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1055
table.insert(_stmts, {
  app = "spree", stmt_id = 1055,
  sql = [[
  SELECT `spree_prices`.`id` AS _spree_prices_id
  FROM `spree_prices`
  WHERE `spree_prices`.`deleted_at` IS NULL
  	AND `spree_prices`.`variant_id` = %s
  	AND `spree_prices`.`currency` = %s
  ORDER BY `spree_prices`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_prices", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1056
table.insert(_stmts, {
  app = "spree", stmt_id = 1056,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  	INNER JOIN `spree_stock_items`
  	ON `spree_stock_items`.`deleted_at` IS NULL
  		AND `spree_stock_items`.`id` = `spree_stock_movements`.`stock_item_id`
  WHERE `spree_stock_movements`.`originator_id` = %s
  	AND `spree_stock_movements`.`originator_type` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  ORDER BY `spree_stock_movements`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_movements", col = "originator_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "originator_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1057
table.insert(_stmts, {
  app = "spree", stmt_id = 1057,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1058
table.insert(_stmts, {
  app = "spree", stmt_id = 1058,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`active` = %s
  	AND `spree_payment_methods`.`display_on` IN (%s)
  ]],
  params = {
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "display_on", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1059
table.insert(_stmts, {
  app = "spree", stmt_id = 1059,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`active` = %s
  	AND `spree_payment_methods`.`display_on` IN (%s)
  ORDER BY `spree_payment_methods`.`position` ASC
  ]],
  params = {
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "display_on", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1060
table.insert(_stmts, {
  app = "spree", stmt_id = 1060,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_stock_items`.`variant_id` = %s
  	AND `spree_stock_items`.`stock_location_id` = %s
  ORDER BY `spree_stock_items`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_items", col = "variant_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_items", col = "stock_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1061
table.insert(_stmts, {
  app = "spree", stmt_id = 1061,
  sql = [[
  SELECT `spree_reimbursements`.`id` AS _spree_reimbursements_id
  FROM `spree_reimbursements`
  WHERE `spree_reimbursements`.`id` = %s
  ]],
  params = {
    {table = "spree_reimbursements", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1062
table.insert(_stmts, {
  app = "spree", stmt_id = 1062,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`position` >= %s
  	AND `spree_variants`.id != %s
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "position", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1063
table.insert(_stmts, {
  app = "spree", stmt_id = 1063,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_variants`
  WHERE `spree_variants`.`product_id` = %s
  	AND `spree_variants`.`position` = %s
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1064
table.insert(_stmts, {
  app = "spree", stmt_id = 1064,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  WHERE `spree_addresses`.`user_id` = %s
  	AND `spree_addresses`.`deleted_at` IS NULL
  ORDER BY updated_at DESC
  ]],
  params = {
    {table = "spree_addresses", col = "user_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1065
table.insert(_stmts, {
  app = "spree", stmt_id = 1065,
  sql = [[
  SELECT `spree_store_credit_events`.`id` AS _spree_store_credit_events_id
  FROM `spree_store_credit_events`
  WHERE `spree_store_credit_events`.`deleted_at` IS NULL
  	AND `spree_store_credit_events`.`store_credit_id` = %s
  	AND `spree_store_credit_events`.`amount` = %s
  	AND `spree_store_credit_events`.`action` = %s
  ]],
  params = {
    {table = "spree_store_credit_events", col = "store_credit_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "amount", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_store_credit_events", col = "action", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1066
table.insert(_stmts, {
  app = "spree", stmt_id = 1066,
  sql = [[
  SELECT DISTINCT spree_option_types.position, spree_option_values.position AS alias_0, `spree_option_types`.`id`
  FROM `spree_option_types`
  	LEFT JOIN `spree_option_values` ON `spree_option_values`.`option_type_id` = `spree_option_types`.`id`
  ORDER BY spree_option_types.position ASC, spree_option_values.position ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1067
table.insert(_stmts, {
  app = "spree", stmt_id = 1067,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id, `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	LEFT JOIN `spree_option_values` ON `spree_option_values`.`option_type_id` = `spree_option_types`.`id`
  WHERE `spree_option_types`.`id` = %s
  ORDER BY spree_option_types.position ASC, spree_option_values.position ASC
  ]],
  params = {
    {table = "spree_option_types", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1068
table.insert(_stmts, {
  app = "spree", stmt_id = 1068,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_option_value_variants` ON `spree_variants`.`id` = `spree_option_value_variants`.`variant_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_option_value_variants`.`option_value_id` = %s
  	AND `spree_variants`.`id` = %s
  ORDER BY `spree_variants`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_value_variants", col = "option_value_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1069
table.insert(_stmts, {
  app = "spree", stmt_id = 1069,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id, `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  	LEFT JOIN `spree_option_values` ON `spree_option_values`.`option_type_id` = `spree_option_types`.`id`
  ORDER BY spree_option_types.position ASC, spree_option_values.position ASC
  ]],
  params = {
  }
})

-- stmt 1070
table.insert(_stmts, {
  app = "spree", stmt_id = 1070,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  	INNER JOIN `spree_option_value_variants` ON `spree_variants`.`id` = `spree_option_value_variants`.`variant_id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_option_value_variants`.`option_value_id` = %s
  	AND `spree_variants`.`id` IN (%s)
  ORDER BY `spree_variants`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_value_variants", col = "option_value_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1071
table.insert(_stmts, {
  app = "spree", stmt_id = 1071,
  sql = [[
  SELECT DISTINCT spree_variants.`id`, spree_variants.`sku`, spree_variants.`weight`, spree_variants.`height`, spree_variants.`width`
  	, spree_variants.`depth`, spree_variants.`deleted_at`, spree_variants.`discontinue_on`, spree_variants.`is_master`, spree_variants.`product_id`
  	, spree_variants.`cost_price`, spree_variants.`cost_currency`, spree_variants.`position`, spree_variants.`track_inventory`, spree_variants.`tax_category_id`
  	, spree_variants.`updated_at`, spree_variants.`created_at`
  FROM `spree_variants`
  	INNER JOIN `spree_prices`
  	ON `spree_prices`.`deleted_at` IS NULL
  		AND `spree_prices`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND (`spree_variants`.`discontinue_on` IS NULL
  		OR `spree_variants`.`discontinue_on` >= %s)
  	AND `spree_variants`.deleted_at IS NULL
  	AND spree_prices.currency = %s
  	AND spree_prices.amount IS NOT NULL
  	AND `spree_variants`.`sku` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_variants", col = "discontinue_on", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_prices", col = "currency", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_variants", col = "sku", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1072
table.insert(_stmts, {
  app = "spree", stmt_id = 1072,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`is_default` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "is_default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1073
table.insert(_stmts, {
  app = "spree", stmt_id = 1073,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`id` = NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1074
table.insert(_stmts, {
  app = "spree", stmt_id = 1074,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  	INNER JOIN `spree_line_items` ON `spree_adjustments`.`adjustable_id` = `spree_line_items`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ORDER BY `spree_line_items`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1075
table.insert(_stmts, {
  app = "spree", stmt_id = 1075,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`admin_name` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1076
table.insert(_stmts, {
  app = "spree", stmt_id = 1076,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`name` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1077
table.insert(_stmts, {
  app = "spree", stmt_id = 1077,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1078
table.insert(_stmts, {
  app = "spree", stmt_id = 1078,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`name` = %s
  ORDER BY `spree_countries`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1079
table.insert(_stmts, {
  app = "spree", stmt_id = 1079,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`iso` = %s
  ORDER BY `spree_countries`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "iso", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1080
table.insert(_stmts, {
  app = "spree", stmt_id = 1080,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`name` = %s
  	AND `spree_states`.`country_id` = %s
  ORDER BY `spree_states`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1081
table.insert(_stmts, {
  app = "spree", stmt_id = 1081,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`admin_name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_locations", col = "admin_name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1082
table.insert(_stmts, {
  app = "spree", stmt_id = 1082,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_locations", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1083
table.insert(_stmts, {
  app = "spree", stmt_id = 1083,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1084
table.insert(_stmts, {
  app = "spree", stmt_id = 1084,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1085
table.insert(_stmts, {
  app = "spree", stmt_id = 1085,
  sql = [[
  SELECT `spree_stock_items`.`id` AS _spree_stock_items_id
  FROM `spree_stock_items`
  	INNER JOIN `spree_variants` ON `spree_stock_items`.`variant_id` = `spree_variants`.`id`
  WHERE `spree_stock_items`.`deleted_at` IS NULL
  	AND `spree_variants`.`deleted_at` IS NULL
  	AND `spree_variants`.`product_id` = %s
  ORDER BY `spree_variants`.`position` ASC
  ]],
  params = {
    {table = "spree_variants", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1086
table.insert(_stmts, {
  app = "spree", stmt_id = 1086,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`is_default` = %s
  	AND `spree_tax_categories`.`id` != %s
  ORDER BY `spree_tax_categories`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "is_default", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_categories", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1087
table.insert(_stmts, {
  app = "spree", stmt_id = 1087,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  WHERE url LIKE %s
  ]],
  params = {
    {table = "spree_stores", col = "url", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 1088
table.insert(_stmts, {
  app = "spree", stmt_id = 1088,
  sql = [[
  SELECT `spree_stores`.`id` AS _spree_stores_id
  FROM `spree_stores`
  ORDER BY `spree_stores`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1089
table.insert(_stmts, {
  app = "spree", stmt_id = 1089,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.amount >= %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1090
table.insert(_stmts, {
  app = "spree", stmt_id = 1090,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.amount < %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "relation", operator = "<", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1091
table.insert(_stmts, {
  app = "spree", stmt_id = 1091,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.amount >= %s
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "amount", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1092
table.insert(_stmts, {
  app = "spree", stmt_id = 1092,
  sql = [[
  SELECT SUM(`spree_adjustments`.`amount`)
  FROM `spree_adjustments`
  	INNER JOIN `spree_line_items` ON `spree_adjustments`.`adjustable_id` = `spree_line_items`.`id`
  WHERE `spree_line_items`.`order_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  ]],
  params = {
    {table = "spree_line_items", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1093
table.insert(_stmts, {
  app = "spree", stmt_id = 1093,
  sql = [[
  SELECT DISTINCT `spree_zones`.`id`
  FROM `spree_zones`
  	INNER JOIN `spree_zone_members` ON `spree_zone_members`.`zone_id` = `spree_zones`.`id`
  WHERE (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id IN (%s))
  	OR (spree_zone_members.zoneable_type = %s
  		AND spree_zone_members.zoneable_id IN (%s))
  ]],
  params = {
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1094
table.insert(_stmts, {
  app = "spree", stmt_id = 1094,
  sql = [[
  SELECT SUM(`spree_tax_rates`.`amount`)
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`zone_id` IN (%s)
  	AND `spree_tax_rates`.`included_in_price` = %s
  	AND `spree_tax_rates`.`tax_category_id` = %s
  ]],
  params = {
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "included_in_price", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "tax_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1095
table.insert(_stmts, {
  app = "spree", stmt_id = 1095,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`response_code` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "response_code", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1096
table.insert(_stmts, {
  app = "spree", stmt_id = 1096,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1097
table.insert(_stmts, {
  app = "spree", stmt_id = 1097,
  sql = [[
  SELECT `spree_product_properties`.`id` AS _spree_product_properties_id
  FROM `spree_product_properties`
  WHERE `spree_product_properties`.`property_id` = %s
  ORDER BY `spree_product_properties`.`position` ASC
  ]],
  params = {
    {table = "spree_product_properties", col = "property_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1098
table.insert(_stmts, {
  app = "spree", stmt_id = 1098,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  	INNER JOIN `spree_product_properties` ON `spree_product_properties`.`product_id` = `spree_products`.`id`
  	INNER JOIN `spree_properties` ON `spree_properties`.`id` = `spree_product_properties`.`property_id`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_properties`.`name` = %s
  	AND `spree_product_properties`.`value` = %s
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_product_properties", col = "value", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1099
table.insert(_stmts, {
  app = "spree", stmt_id = 1099,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE name = %s
  	OR abbr = %s
  ]],
  params = {
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "abbr", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1100
table.insert(_stmts, {
  app = "spree", stmt_id = 1100,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`name` = %s
  	AND `spree_countries`.`iso3` = %s
  	AND `spree_countries`.`iso` = %s
  	AND `spree_countries`.`iso_name` = %s
  	AND `spree_countries`.`numcode` = %s
  	AND `spree_countries`.`states_required` = %s
  ORDER BY `spree_countries`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_countries", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "iso3", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "iso", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "iso_name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "numcode", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_countries", col = "states_required", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1101
table.insert(_stmts, {
  app = "spree", stmt_id = 1101,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  WHERE `spree_roles`.`name` = %s
  ORDER BY `spree_roles`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_roles", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1102
table.insert(_stmts, {
  app = "spree", stmt_id = 1102,
  sql = [[
  SELECT `spree_countries`.`id` AS _spree_countries_id
  FROM `spree_countries`
  WHERE `spree_countries`.`states_required` = %s
  ]],
  params = {
    {table = "spree_countries", col = "states_required", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1103
table.insert(_stmts, {
  app = "spree", stmt_id = 1103,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  	AND `spree_states`.`name` = %s
  	AND `spree_states`.`abbr` = %s
  	AND `spree_states`.`country_id` = %s
  ORDER BY `spree_states`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "abbr", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1104
table.insert(_stmts, {
  app = "spree", stmt_id = 1104,
  sql = [[
  SELECT `spree_store_credit_categories`.`id` AS _spree_store_credit_categories_id
  FROM `spree_store_credit_categories`
  WHERE `spree_store_credit_categories`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_store_credit_categories", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1105
table.insert(_stmts, {
  app = "spree", stmt_id = 1105,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`name` = %s
  	AND `spree_zones`.`description` = %s
  	AND `spree_zones`.`kind` = %s
  ORDER BY `spree_zones`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_zones", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zones", col = "description", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zones", col = "kind", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1106
table.insert(_stmts, {
  app = "spree", stmt_id = 1106,
  sql = [[
  SELECT `spree_zone_members`.`id` AS _spree_zone_members_id
  FROM `spree_zone_members`
  WHERE `spree_zone_members`.`zone_id` = %s
  	AND `spree_zone_members`.`zoneable_type` = %s
  	AND `spree_zone_members`.`zoneable_id` = %s
  ORDER BY `spree_zone_members`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_zone_members", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_zone_members", col = "zoneable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1107
table.insert(_stmts, {
  app = "spree", stmt_id = 1107,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1108
table.insert(_stmts, {
  app = "spree", stmt_id = 1108,
  sql = [[
  SELECT `spree_states`.`id` AS _spree_states_id
  FROM `spree_states`
  WHERE `spree_states`.`country_id` = %s
  	AND `spree_states`.`abbr` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_states", col = "country_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_states", col = "abbr", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1109
table.insert(_stmts, {
  app = "spree", stmt_id = 1109,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`type` IN (%s)
  	AND `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`name` = %s
  	AND `spree_payment_methods`.`description` = %s
  	AND `spree_payment_methods`.`active` = %s
  ORDER BY `spree_payment_methods`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "type", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "description", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1110
table.insert(_stmts, {
  app = "spree", stmt_id = 1110,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`type` = %s
  	AND `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`name` = %s
  	AND `spree_payment_methods`.`description` = %s
  	AND `spree_payment_methods`.`active` = %s
  ORDER BY `spree_payment_methods`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "description", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1111
table.insert(_stmts, {
  app = "spree", stmt_id = 1111,
  sql = [[
  SELECT `spree_shipping_methods`.`id` AS _spree_shipping_methods_id
  FROM `spree_shipping_methods`
  WHERE `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`deleted_at` IS NULL
  	AND `spree_shipping_methods`.`name` = %s
  ORDER BY `spree_shipping_methods`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_shipping_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1112
table.insert(_stmts, {
  app = "spree", stmt_id = 1112,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`name` = %s
  ORDER BY `spree_tax_categories`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1113
table.insert(_stmts, {
  app = "spree", stmt_id = 1113,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  	AND `spree_tax_categories`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_categories", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1114
table.insert(_stmts, {
  app = "spree", stmt_id = 1114,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`name` = %s
  	AND `spree_tax_rates`.`zone_id` = %s
  	AND `spree_tax_rates`.`amount` = %s
  	AND `spree_tax_rates`.`tax_category_id` = %s
  ORDER BY `spree_tax_rates`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "zone_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "amount", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_tax_rates", col = "tax_category_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1115
table.insert(_stmts, {
  app = "spree", stmt_id = 1115,
  sql = [[
  SELECT `spree_taxonomies`.`id` AS _spree_taxonomies_id
  FROM `spree_taxonomies`
  WHERE `spree_taxonomies`.`name` = %s
  ORDER BY spree_taxonomies.position, spree_taxonomies.created_at
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxonomies", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1116
table.insert(_stmts, {
  app = "spree", stmt_id = 1116,
  sql = [[
  SELECT `spree_option_types`.`id` AS _spree_option_types_id
  FROM `spree_option_types`
  WHERE `spree_option_types`.`name` = %s
  	AND `spree_option_types`.`presentation` = %s
  	AND `spree_option_types`.`position` = %s
  ORDER BY `spree_option_types`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_types", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_types", col = "presentation", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_types", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1117
table.insert(_stmts, {
  app = "spree", stmt_id = 1117,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`name` = %s
  	AND `spree_option_values`.`presentation` = %s
  	AND `spree_option_values`.`position` = %s
  ORDER BY `spree_option_values`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "presentation", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "position", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1118
table.insert(_stmts, {
  app = "spree", stmt_id = 1118,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`name` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1119
table.insert(_stmts, {
  app = "spree", stmt_id = 1119,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`name` = %s
  	AND `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  	AND `spree_taxons`.`id` != %s
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1120
table.insert(_stmts, {
  app = "spree", stmt_id = 1120,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`name` = %s
  	AND `spree_taxons`.`permalink` = %s
  ORDER BY `spree_taxons`.`lft` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "permalink", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1121
table.insert(_stmts, {
  app = "spree", stmt_id = 1121,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_taxons`
  WHERE `spree_taxons`.`parent_id` = %s
  	AND `spree_taxons`.`name` = %s
  	AND `spree_taxons`.`permalink` = %s
  	AND `spree_taxons`.`lft` <= %s
  	AND `spree_taxons`.`rgt` >= %s
  	AND `spree_taxons`.`id` != %s
  ]],
  params = {
    {table = "spree_taxons", col = "parent_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "permalink", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "lft", clause = "where", pos = "relation", operator = "<=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "rgt", clause = "where", pos = "relation", operator = ">=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_taxons", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1122
table.insert(_stmts, {
  app = "spree", stmt_id = 1122,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1123
table.insert(_stmts, {
  app = "spree", stmt_id = 1123,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`name` = %s
  ORDER BY `spree_products`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1124
table.insert(_stmts, {
  app = "spree", stmt_id = 1124,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  WHERE `spree_taxons`.`name` IN (%s)
  ]],
  params = {
    {table = "spree_taxons", col = "name", clause = "where", pos = "in_list", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1125
table.insert(_stmts, {
  app = "spree", stmt_id = 1125,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1126
table.insert(_stmts, {
  app = "spree", stmt_id = 1126,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  	AND `spree_products`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_products", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1127
table.insert(_stmts, {
  app = "spree", stmt_id = 1127,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1128
table.insert(_stmts, {
  app = "spree", stmt_id = 1128,
  sql = [[
  SELECT `spree_promotion_rules`.`id` AS _spree_promotion_rules_id
  FROM `spree_promotion_rules`
  WHERE `spree_promotion_rules`.`promotion_id` = %s
  	AND `spree_promotion_rules`.`type` = %s
  	AND `spree_promotion_rules`.`preferences` = %s
  ORDER BY `spree_promotion_rules`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_rules", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_rules", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_rules", col = "preferences", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1129
table.insert(_stmts, {
  app = "spree", stmt_id = 1129,
  sql = [[
  SELECT `spree_promotion_actions`.`id` AS _spree_promotion_actions_id
  FROM `spree_promotion_actions`
  WHERE `spree_promotion_actions`.`type` = %s
  	AND `spree_promotion_actions`.`deleted_at` IS NULL
  	AND `spree_promotion_actions`.`promotion_id` = %s
  ORDER BY `spree_promotion_actions`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_promotion_actions", col = "type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_promotion_actions", col = "promotion_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1130
table.insert(_stmts, {
  app = "spree", stmt_id = 1130,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  ORDER BY `spree_taxons`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1131
table.insert(_stmts, {
  app = "spree", stmt_id = 1131,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  	INNER JOIN `spree_products_taxons` ON `spree_taxons`.`id` = `spree_products_taxons`.`taxon_id`
  WHERE `spree_products_taxons`.`product_id` = %s
  ]],
  params = {
    {table = "spree_products_taxons", col = "product_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1132
table.insert(_stmts, {
  app = "spree", stmt_id = 1132,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`name` = %s
  	AND `spree_properties`.`presentation` = %s
  ORDER BY `spree_properties`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_properties", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_properties", col = "presentation", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1133
table.insert(_stmts, {
  app = "spree", stmt_id = 1133,
  sql = [[
  SELECT `spree_prototypes`.`id` AS _spree_prototypes_id
  FROM `spree_prototypes`
  WHERE `spree_prototypes`.`name` = %s
  ORDER BY `spree_prototypes`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_prototypes", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1134
table.insert(_stmts, {
  app = "spree", stmt_id = 1134,
  sql = [[
  SELECT `spree_properties`.`id` AS _spree_properties_id
  FROM `spree_properties`
  WHERE `spree_properties`.`presentation` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_properties", col = "presentation", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1135
table.insert(_stmts, {
  app = "spree", stmt_id = 1135,
  sql = [[
  SELECT `spree_option_values`.`id` AS _spree_option_values_id
  FROM `spree_option_values`
  WHERE `spree_option_values`.`option_type_id` = %s
  	AND `spree_option_values`.`name` = %s
  ORDER BY `spree_option_values`.`position` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_option_values", col = "option_type_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_option_values", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1136
table.insert(_stmts, {
  app = "spree", stmt_id = 1136,
  sql = [[
  SELECT `spree_variants`.`id` AS _spree_variants_id
  FROM `spree_variants`
  WHERE `spree_variants`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1137
table.insert(_stmts, {
  app = "spree", stmt_id = 1137,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`number` = %s
  	AND `spree_orders`.`email` = %s
  ORDER BY `spree_orders`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_orders", col = "email", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1138
table.insert(_stmts, {
  app = "spree", stmt_id = 1138,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  ORDER BY `spree_addresses`.`id` ASC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1139
table.insert(_stmts, {
  app = "spree", stmt_id = 1139,
  sql = [[
  SELECT `spree_addresses`.`id` AS _spree_addresses_id
  FROM `spree_addresses`
  ORDER BY `spree_addresses`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1140
table.insert(_stmts, {
  app = "spree", stmt_id = 1140,
  sql = [[
  SELECT `spree_tax_rates`.`id` AS _spree_tax_rates_id
  FROM `spree_tax_rates`
  WHERE `spree_tax_rates`.`deleted_at` IS NULL
  	AND `spree_tax_rates`.`name` = %s
  LIMIT 2
  ]],
  params = {
    {table = "spree_tax_rates", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1141
table.insert(_stmts, {
  app = "spree", stmt_id = 1141,
  sql = [[
  SELECT `spree_adjustments`.`id` AS _spree_adjustments_id
  FROM `spree_adjustments`
  WHERE `spree_adjustments`.`adjustable_id` = %s
  	AND `spree_adjustments`.`adjustable_type` = %s
  	AND `spree_adjustments`.`source_type` = %s
  	AND `spree_adjustments`.`source_id` = %s
  	AND `spree_adjustments`.`order_id` = %s
  	AND `spree_adjustments`.`label` = %s
  	AND `spree_adjustments`.`state` = %s
  	AND `spree_adjustments`.`mandatory` = %s
  ORDER BY `spree_adjustments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_adjustments", col = "adjustable_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "adjustable_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "label", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_adjustments", col = "mandatory", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1142
table.insert(_stmts, {
  app = "spree", stmt_id = 1142,
  sql = [[
  SELECT `spree_payment_methods`.`id` AS _spree_payment_methods_id
  FROM `spree_payment_methods`
  WHERE `spree_payment_methods`.`deleted_at` IS NULL
  	AND `spree_payment_methods`.`name` = %s
  	AND `spree_payment_methods`.`active` = %s
  ORDER BY `spree_payment_methods`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payment_methods", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payment_methods", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1143
table.insert(_stmts, {
  app = "spree", stmt_id = 1143,
  sql = [[
  SELECT `spree_credit_cards`.`id` AS _spree_credit_cards_id
  FROM `spree_credit_cards`
  WHERE `spree_credit_cards`.`deleted_at` IS NULL
  	AND `spree_credit_cards`.`cc_type` = %s
  	AND `spree_credit_cards`.`month` = %s
  	AND `spree_credit_cards`.`year` = %s
  	AND `spree_credit_cards`.`last_digits` = %s
  	AND `spree_credit_cards`.`name` = %s
  	AND `spree_credit_cards`.`gateway_customer_profile_id` = %s
  ORDER BY `spree_credit_cards`.`id` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_credit_cards", col = "cc_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "month", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "year", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "last_digits", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_credit_cards", col = "gateway_customer_profile_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1144
table.insert(_stmts, {
  app = "spree", stmt_id = 1144,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`amount` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`source_id` = %s
  	AND `spree_payments`.`payment_method_id` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "amount", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "payment_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1145
table.insert(_stmts, {
  app = "spree", stmt_id = 1145,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`order_id` = %s
  	AND `spree_payments`.`amount` = %s
  	AND `spree_payments`.`source_type` = %s
  	AND `spree_payments`.`source_id` = %s
  	AND `spree_payments`.`payment_method_id` = %s
  	AND `spree_payments`.`state` = %s
  	AND `spree_payments`.`id` != %s
  ORDER BY `spree_payments`.`created_at` ASC
  ]],
  params = {
    {table = "spree_payments", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "amount", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "source_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "payment_method_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "state", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_payments", col = "id", clause = "where", pos = "relation", operator = "!=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1146
table.insert(_stmts, {
  app = "spree", stmt_id = 1146,
  sql = [[
  SELECT `spree_return_authorization_reasons`.`id` AS _spree_return_authorization_reasons_id
  FROM `spree_return_authorization_reasons`
  WHERE `spree_return_authorization_reasons`.`name` = %s
  ORDER BY LOWER(spree_return_authorization_reasons.name)
  LIMIT 2
  ]],
  params = {
    {table = "spree_return_authorization_reasons", col = "name", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1147
table.insert(_stmts, {
  app = "spree", stmt_id = 1147,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_transfers`
  	WHERE `spree_stock_transfers`.`destination_location_id` = %s
  	ORDER BY `spree_stock_transfers`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_transfers", col = "destination_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1148
table.insert(_stmts, {
  app = "spree", stmt_id = 1148,
  sql = [[
  SELECT `spree_stock_transfers`.`id` AS _spree_stock_transfers_id
  FROM `spree_stock_transfers`
  WHERE `spree_stock_transfers`.`destination_location_id` = %s
  ORDER BY `spree_stock_transfers`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_transfers", col = "destination_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1149
table.insert(_stmts, {
  app = "spree", stmt_id = 1149,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  WHERE `spree_stock_movements`.`originator_type` = %s
  	AND `spree_stock_movements`.`originator_id` = %s
  ]],
  params = {
    {table = "spree_stock_movements", col = "originator_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "originator_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1150
table.insert(_stmts, {
  app = "spree", stmt_id = 1150,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_transfers`
  	ORDER BY `spree_stock_transfers`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1151
table.insert(_stmts, {
  app = "spree", stmt_id = 1151,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_stock_transfers`
  	WHERE `spree_stock_transfers`.`source_location_id` = %s
  	ORDER BY `spree_stock_transfers`.`created_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_stock_transfers", col = "source_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1152
table.insert(_stmts, {
  app = "spree", stmt_id = 1152,
  sql = [[
  SELECT `spree_stock_transfers`.`id` AS _spree_stock_transfers_id
  FROM `spree_stock_transfers`
  WHERE `spree_stock_transfers`.`source_location_id` = %s
  ORDER BY `spree_stock_transfers`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_stock_transfers", col = "source_location_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1153
table.insert(_stmts, {
  app = "spree", stmt_id = 1153,
  sql = [[
  SELECT `spree_shipping_categories`.`id` AS _spree_shipping_categories_id
  FROM `spree_shipping_categories`
  ORDER BY `spree_shipping_categories`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 1154
table.insert(_stmts, {
  app = "spree", stmt_id = 1154,
  sql = [[
  SELECT `spree_payments`.`id` AS _spree_payments_id
  FROM `spree_payments`
  WHERE `spree_payments`.`number` = %s
  ORDER BY `spree_payments`.`created_at` ASC
  LIMIT 2
  ]],
  params = {
    {table = "spree_payments", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1155
table.insert(_stmts, {
  app = "spree", stmt_id = 1155,
  sql = [[
  SELECT `spree_prototypes`.`id` AS _spree_prototypes_id
  FROM `spree_prototypes`
  ]],
  params = {
  }
})

-- stmt 1156
table.insert(_stmts, {
  app = "spree", stmt_id = 1156,
  sql = [[
  SELECT `spree_taxons`.`id` AS _spree_taxons_id
  FROM `spree_taxons`
  ]],
  params = {
  }
})

-- stmt 1157
table.insert(_stmts, {
  app = "spree", stmt_id = 1157,
  sql = [[
  SELECT `spree_tax_categories`.`id` AS _spree_tax_categories_id
  FROM `spree_tax_categories`
  WHERE `spree_tax_categories`.`deleted_at` IS NULL
  ]],
  params = {
  }
})

-- stmt 1158
table.insert(_stmts, {
  app = "spree", stmt_id = 1158,
  sql = [[
  SELECT `spree_inventory_units`.`id` AS _spree_inventory_units_id
  FROM `spree_inventory_units`
  WHERE `spree_inventory_units`.`order_id` = %s
  ORDER BY id ASC
  ]],
  params = {
    {table = "spree_inventory_units", col = "order_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1159
table.insert(_stmts, {
  app = "spree", stmt_id = 1159,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_return_items`
  ]],
  params = {
  }
})

-- stmt 1160
table.insert(_stmts, {
  app = "spree", stmt_id = 1160,
  sql = [[
  SELECT `spree_return_items`.`id` AS _spree_return_items_id
  FROM `spree_return_items`
  WHERE `spree_return_items`.`return_authorization_id` = %s
  	AND `spree_return_items`.`id` = %s
  ]],
  params = {
    {table = "spree_return_items", col = "return_authorization_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_return_items", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1161
table.insert(_stmts, {
  app = "spree", stmt_id = 1161,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  WHERE `spree_zones`.`name` IS NULL
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1162
table.insert(_stmts, {
  app = "spree", stmt_id = 1162,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1163
table.insert(_stmts, {
  app = "spree", stmt_id = 1163,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1164
table.insert(_stmts, {
  app = "spree", stmt_id = 1164,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`state` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1165
table.insert(_stmts, {
  app = "spree", stmt_id = 1165,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`state` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1166
table.insert(_stmts, {
  app = "spree", stmt_id = 1166,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`number` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1167
table.insert(_stmts, {
  app = "spree", stmt_id = 1167,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`number` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1168
table.insert(_stmts, {
  app = "spree", stmt_id = 1168,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`completed_at` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1169
table.insert(_stmts, {
  app = "spree", stmt_id = 1169,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1170
table.insert(_stmts, {
  app = "spree", stmt_id = 1170,
  sql = [[
  SELECT `spree_roles`.`id` AS _spree_roles_id
  FROM `spree_roles`
  WHERE `spree_roles`.`id` = %s
  ]],
  params = {
    {table = "spree_roles", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1171
table.insert(_stmts, {
  app = "spree", stmt_id = 1171,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  WHERE `spree_users`.`email` LIKE %s
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "email", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1172
table.insert(_stmts, {
  app = "spree", stmt_id = 1172,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  ORDER BY `spree_users`.`email` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1173
table.insert(_stmts, {
  app = "spree", stmt_id = 1173,
  sql = [[
  SELECT `spree_users`.`id` AS _spree_users_id
  FROM `spree_users`
  ORDER BY `spree_users`.`email` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1174
table.insert(_stmts, {
  app = "spree", stmt_id = 1174,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY spree_orders.completed_at IS NULL, `spree_orders`.`completed_at` DESC, `spree_orders`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1175
table.insert(_stmts, {
  app = "spree", stmt_id = 1175,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`total` ASC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1176
table.insert(_stmts, {
  app = "spree", stmt_id = 1176,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  	LEFT JOIN `spree_users` ON `spree_users`.`id` = `spree_orders`.`user_id`
  WHERE `spree_users`.`id` = %s
  ORDER BY `spree_orders`.`total` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_users", col = "id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 1, wildcard = 0, guessed = nil},
  }
})

-- stmt 1177
table.insert(_stmts, {
  app = "spree", stmt_id = 1177,
  sql = [[
  SELECT `spree_zones`.`id` AS _spree_zones_id
  FROM `spree_zones`
  ORDER BY `spree_zones`.`name` ASC
  ]],
  params = {
  }
})

-- stmt 1178
table.insert(_stmts, {
  app = "spree", stmt_id = 1178,
  sql = [[
  SELECT `spree_products`.`id` AS _spree_products_id
  FROM `spree_products`
  WHERE `spree_products`.`deleted_at` IS NULL
  ORDER BY `spree_products`.`id` DESC
  LIMIT 2
  ]],
  params = {
  }
})

-- stmt 1179
table.insert(_stmts, {
  app = "spree", stmt_id = 1179,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_customer_returns`
  WHERE `spree_customer_returns`.`number` LIKE %s
  ]],
  params = {
    {table = "spree_customer_returns", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
  }
})

-- stmt 1180
table.insert(_stmts, {
  app = "spree", stmt_id = 1180,
  sql = [[
  SELECT `spree_customer_returns`.`id` AS _spree_customer_returns_id
  FROM `spree_customer_returns`
  WHERE `spree_customer_returns`.`number` LIKE %s
  ORDER BY `spree_customer_returns`.`created_at` DESC
  LIMIT %s, 25
  ]],
  params = {
    {table = "spree_customer_returns", col = "number", clause = "where", pos = "relation", operator = "LIKE", depth = 0, wildcard = 3, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1181
table.insert(_stmts, {
  app = "spree", stmt_id = 1181,
  sql = [[
  SELECT `spree_stock_movements`.`id` AS _spree_stock_movements_id
  FROM `spree_stock_movements`
  WHERE `spree_stock_movements`.`originator_id` = %s
  	AND `spree_stock_movements`.`originator_type` = %s
  ORDER BY `spree_stock_movements`.`id` DESC
  LIMIT 2
  ]],
  params = {
    {table = "spree_stock_movements", col = "originator_id", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "spree_stock_movements", col = "originator_type", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1182
table.insert(_stmts, {
  app = "spree", stmt_id = 1182,
  sql = [[
  SELECT `spree_stock_locations`.`id` AS _spree_stock_locations_id
  FROM `spree_stock_locations`
  WHERE `spree_stock_locations`.`active` = %s
  ORDER BY `spree_stock_locations`.`default` DESC, `spree_stock_locations`.`name` ASC
  ]],
  params = {
    {table = "spree_stock_locations", col = "active", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1183
table.insert(_stmts, {
  app = "spree", stmt_id = 1183,
  sql = [[
  SELECT COUNT(*)
  FROM `spree_orders`
  WHERE `spree_orders`.`completed_at` IS NOT NULL
  ]],
  params = {
  }
})

-- stmt 1184
table.insert(_stmts, {
  app = "spree", stmt_id = 1184,
  sql = [[
  SELECT COUNT(*)
  FROM (
  	SELECT 1 AS one
  	FROM `spree_orders`
  	WHERE `spree_orders`.`number` = %s
  		AND `spree_orders`.`completed_at` IS NOT NULL
  	ORDER BY `spree_orders`.`completed_at` DESC
  	LIMIT %s, 25
  ) subquery_for_count
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1185
table.insert(_stmts, {
  app = "spree", stmt_id = 1185,
  sql = [[
  SELECT DISTINCT `id`, `number`, `item_total`, `total`, `state`
  	, `adjustment_total`, `user_id`, `completed_at`, `bill_address_id`, `ship_address_id`
  	, `payment_total`, `shipment_state`, `payment_state`, `email`, `special_instructions`
  	, `created_at`, `updated_at`, `currency`, `last_ip_address`, `created_by_id`
  	, `shipment_total`, `additional_tax_total`, `promo_total`, `channel`, `included_tax_total`
  	, `item_count`, `approver_id`, `approved_at`, `confirmation_delivered`, `considered_risky`
  	, `token`, `canceled_at`, `canceler_id`, `store_id`, `state_lock_version`
  	, `taxable_adjustment_total`, `non_taxable_adjustment_total`
  FROM `spree_orders`
  WHERE `spree_orders`.`number` = %s
  	AND `spree_orders`.`completed_at` IS NOT NULL
  ORDER BY `spree_orders`.`completed_at` DESC
  LIMIT %s, 2
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
    {table = "", col = "", clause = "limit", pos = "limit", operator = "", depth = 0, wildcard = 0, guessed = nil},
  }
})

-- stmt 1186
table.insert(_stmts, {
  app = "spree", stmt_id = 1186,
  sql = [[
  SELECT `spree_orders`.`id` AS _spree_orders_id
  FROM `spree_orders`
  WHERE `spree_orders`.`number` = %s
  ]],
  params = {
    {table = "spree_orders", col = "number", clause = "where", pos = "relation", operator = "=", depth = 0, wildcard = 0, guessed = nil},
  }
})

return _stmts
