local Schema = require("schema")
local Util = require("util")
local Gen = require("datagen")

local function _loop_with_log(_con, _table, _callback)
    Util.log("[Prepare] table " .. _table)
    Util.begin(_con)

    for _i = 1, Gen.TOTAL_ROWS do
        if _i % 2000 == 0 and _i % 10000 ~= 0 then
            Util.log(".")
        end

        if _i % 10000 == 0 then
            Util.log(_i)
            Util.commit(_con)
            Util.begin(_con)
        end

        _callback(_i)
    end

    Util.commit(_con)
    Util.log(" done\n")
end

local function _gen_row_data(_table_name, _table_desc, _line_num)
    local _row = {}

    for _col_name, _col_desc in pairs(_table_desc) do
        local _value = Gen.get_val_at(_line_num, _col_desc)

        if _value == nil then
            io.stderr:write("unhandled column: " .. _table_name .. "." .. _col_name)
            _value = "NULL"
        end

        table.insert(_row, _value)
    end

    return table.concat(_row, ", ")
end

local function _populate_table(_con, _table_name, _table_desc)
    local _insert_sql = string.format("INSERT INTO %s (%s) VALUES ",
            _table_name,
            Util.get_columns(_table_desc))

    local _gen = function(_line_num)
        local _sql = _insert_sql .. "(" .. _gen_row_data(_table_name, _table_desc, _line_num) .. ")"
        _con:query(_sql)
    end

    _loop_with_log(_con, _table_name, _gen)
end

local function _populate_tables(_con)
    for _table_name, _table_desc in pairs(Schema.tables) do
        _populate_table(_con, _table_name, _table_desc)
    end
end

return {
    populate_tables = _populate_tables
}