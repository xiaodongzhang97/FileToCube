local DataGen = require("datagen")
local Util = require("util")
local Schema = require("schema")

local LIMIT_OFFSETS = { 0, 2000, 4000, 6000, 8000 }

local function _fake_col_desc_of_type(_type_category, _type_name)
    return { data_type = { _type_category, _type_name } }
end

local function _get_arg_at(_row_num, _param_desc, _get_col_f, _for_sample)
    _for_sample = _for_sample or false

    local _table = _param_desc.table
    local _col = _param_desc.col
    local _clause = _param_desc.clause
    local _position = _param_desc.pos
    local _wildcard_type = _param_desc.wildcard
    local _relation_operator = _param_desc.operator

    -- LIMIT offset
    if _clause == "limit" then
        if _for_sample then
            return 2
        else
            return LIMIT_OFFSETS[Util.rand_int(1, #LIMIT_OFFSETS)]
        end
    end

    local _val
    if _table == "" then
        -- anonymous param
        _val = _row_num

    else
        -- common param
        local _col_desc = _get_col_f(_table, _col)
        if _col_desc == nil then
            -- shouldn't happen
            _val = "NULL"
            io.stderr:write("[Gen] unknown column: " .. _table .. "." .. _col .. "\n")
        else
            _val = DataGen.get_val_at(_row_num, _col_desc)
        end
    end

    if _val == "NULL" then
        return _val
    end

    -- handle wildcard
    if _wildcard_type ~= 0 then
        _val = string.sub(_val, 2, -2)
        if _wildcard_type == 1 then
            _val = "\'" .. _val .. "%\'"
        elseif _wildcard_type == 2 then
            _val = "\'%" .. _val .. "\'"
        elseif _wildcard_type == 3 then
            _val = "\'%" .. _val .. "%\'"
        end
        return _val
    end

    -- handle regexp
    if _param_desc == "regexp" then
        return string.sub(_val, 1, -2) .. ".*\'"
    end

    -- handle number inequality
    if type(_val) == "number" then
        if _position == "between_begin" or _relation_operator == ">" then
            _val = _val - 10
        elseif _position == "between_end" or _relation_operator == "<"
                or _relation_operator == "<>" or _relation_operator == "!=" then
            _val = _val + 10
        end
        return _val
    end

    -- handle datatime inequality
    if Util.is_time_str(_val) then
        local _fake_col_desc = _fake_col_desc_of_type("datetime_like")
        _val = DataGen.get_seed_at(_row_num, _fake_col_desc)
        if _position == "between_begin" or _relation_operator == ">" then
            _val = _val - 10
        elseif _position == "between_end" or _relation_operator == "<"
                or _relation_operator == "<>" or _relation_operator == "!=" then
            _val = _val + 10
        end
        return DataGen.convert_type(_val, _fake_col_desc.data_type)
    end

    -- handle string inequality
    if type(_val) == "string" and string.sub(_val, 1, 1) == "'" then
        if _relation_operator == "<>" or _relation_operator == "!=" or _relation_operator == "not like" then
            _val = tonumber(string.sub(_val, 2, -2))
            if _val == 1 then
                _val = 0 -- for boolean
            elseif _val == 7 then
                _val = 6 -- for enum
            else
                _val = _val + 1
            end
            return "'" .. _val .. "'"
        end
    end

    return _val
end

local function _determine_row_num(_init_row_num, _depth)
    local _val = _init_row_num
    for _ = 1, _depth do
        _val = DataGen.get_ref_at(_val)
    end
    return _val
end

local function _get_col(_table, _col)
    return Schema.tables[_table][_col]
end

local function _gen_args(_params, _primary_row_num)
    local _for_sample = _primary_row_num ~= nil
    if not _for_sample then
        _primary_row_num = Util.rand_int(1, DataGen.TOTAL_ROWS)
    end

    local _ret = {}
    for _, _p in ipairs(_params) do
        local _depth = _p.depth or 0 -- for compatible
        local _row_num = _determine_row_num(_primary_row_num, _depth)
        table.insert(_ret, _get_arg_at(_row_num, _p, _get_col, _for_sample))
    end

    return _ret
end

return {
    gen_args = _gen_args
}
