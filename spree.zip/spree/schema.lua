local _tables = {
  ["spree_tax_rates"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 2,
      data_type = {"decimal", "decimal", 8, 5},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zone_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_category_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included_in_price"] = {
      ordinal = 5,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["show_rate_in_label"] = {
      ordinal = 9,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_oauth_access_grants"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["resource_owner_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["application_id"] = {
      ordinal = 3,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {{"spree_oauth_applications", "id"}}
    },
    ["token"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["expires_in"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["redirect_uri"] = {
      ordinal = 6,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["revoked_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["scopes"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_payments"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 2,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_method_id"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["response_code"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["avs_response"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cvv_response_code"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cvv_response_message"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_taxons"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["parent_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["permalink"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxonomy_id"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["lft"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["rgt"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 9,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_title"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_description"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_keywords"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["depth"] = {
      ordinal = 15,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["hide_from_nav"] = {
      ordinal = 16,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_option_type_prototypes"] = {
    ["prototype_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["option_type_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_roles"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_assets"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["viewable_type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["viewable_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_width"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_height"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_file_size"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_content_type"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_file_name"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 75, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["attachment_updated_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["alt"] = {
      ordinal = 12,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 13,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 14,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_option_value_variants"] = {
    ["variant_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["option_value_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipping_rates"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipment_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipping_method_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["selected"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cost"] = {
      ordinal = 5,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_rate_id"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_rule_users"] = {
    ["user_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_rule_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_zone_members"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zoneable_type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zoneable_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zone_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_role_users"] = {
    ["role_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_payment_capture_events"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 2,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_taxonomies"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_store_credit_events"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["store_credit_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["action"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 4,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["authorization_code"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_total_amount"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_id"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_type"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_stock_transfers"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reference"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_location_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["destination_location_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_prototype_taxons"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxon_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["prototype_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_store_credits"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["category_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_by_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 5,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount_used"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["memo"] = {
      ordinal = 7,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["currency"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount_authorized"] = {
      ordinal = 10,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_id"] = {
      ordinal = 11,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_type"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 14,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 15,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_zones"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default_tax"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zone_members_count"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["kind"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipments"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tracking"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cost"] = {
      ordinal = 4,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipped_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address_id"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stock_location_id"] = {
      ordinal = 11,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["adjustment_total"] = {
      ordinal = 12,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["additional_tax_total"] = {
      ordinal = 13,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promo_total"] = {
      ordinal = 14,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included_tax_total"] = {
      ordinal = 15,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["pre_tax_amount"] = {
      ordinal = 16,
      data_type = {"decimal", "decimal", 12, 4},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxable_adjustment_total"] = {
      ordinal = 17,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["non_taxable_adjustment_total"] = {
      ordinal = 18,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_categories"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["code"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_users"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["encrypted_password"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 128, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["password_salt"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 128, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["email"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["remember_token"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["persistence_token"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reset_password_token"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["perishable_token"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["sign_in_count"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["failed_attempts"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["last_request_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["current_sign_in_at"] = {
      ordinal = 12,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["last_sign_in_at"] = {
      ordinal = 13,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["current_sign_in_ip"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["last_sign_in_ip"] = {
      ordinal = 15,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["login"] = {
      ordinal = 16,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["ship_address_id"] = {
      ordinal = 17,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["bill_address_id"] = {
      ordinal = 18,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["authentication_token"] = {
      ordinal = 19,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["unlock_token"] = {
      ordinal = 20,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["locked_at"] = {
      ordinal = 21,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["remember_created_at"] = {
      ordinal = 22,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reset_password_sent_at"] = {
      ordinal = 23,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 24,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 25,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["spree_api_key"] = {
      ordinal = 26,
      data_type = {"string_like", "varchar", 48, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipping_method_categories"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipping_method_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipping_category_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_products"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 3,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["available_on"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["discontinue_on"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["slug"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_description"] = {
      ordinal = 8,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_keywords"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_category_id"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipping_category_id"] = {
      ordinal = 11,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 12,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 13,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotionable"] = {
      ordinal = 14,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_title"] = {
      ordinal = 15,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["ar_internal_metadata"] = {
    ["key"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["value"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_action_line_items"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_action_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["quantity"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_oauth_applications"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["uid"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["secret"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["redirect_uri"] = {
      ordinal = 5,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["scopes"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["confidential"] = {
      ordinal = 7,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["schema_migrations"] = {
    ["version"] = {
      ordinal = 1,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_store_credit_types"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["priority"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_properties"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["presentation"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_reimbursements"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reimbursement_status"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["customer_return_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["total"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_stock_items"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stock_location_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["count_on_hand"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["backorderable"] = {
      ordinal = 7,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["action_text_rich_texts"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["body"] = {
      ordinal = 3,
      data_type = {"string_like", "longtext", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["record_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["record_id"] = {
      ordinal = 5,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_reimbursement_credits"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 2,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reimbursement_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["creditable_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["creditable_type"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_actions"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_property_prototypes"] = {
    ["prototype_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["property_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_countries"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["iso_name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["iso"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["iso3"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["numcode"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["states_required"] = {
      ordinal = 7,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zipcode_required"] = {
      ordinal = 9,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotions"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["expires_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["starts_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["usage_limit"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["match_policy"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["code"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["advertise"] = {
      ordinal = 10,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["path"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 12,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 13,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_category_id"] = {
      ordinal = 14,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_reimbursement_types"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 3,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["mutable"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_credit_cards"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["month"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["year"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cc_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["last_digits"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address_id"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["gateway_customer_profile_id"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["gateway_payment_profile_id"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 12,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_method_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default"] = {
      ordinal = 14,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 15,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_option_types"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 100, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["presentation"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 100, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_gateways"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 4,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 5,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["environment"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["server"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["test_mode"] = {
      ordinal = 8,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["preferences"] = {
      ordinal = 11,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_dummy_models"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_store_credit_categories"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_line_items"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["quantity"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["price"] = {
      ordinal = 5,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["currency"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cost_price"] = {
      ordinal = 9,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_category_id"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["adjustment_total"] = {
      ordinal = 11,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["additional_tax_total"] = {
      ordinal = 12,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promo_total"] = {
      ordinal = 13,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included_tax_total"] = {
      ordinal = 14,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["pre_tax_amount"] = {
      ordinal = 15,
      data_type = {"decimal", "decimal", 12, 4},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxable_adjustment_total"] = {
      ordinal = 16,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["non_taxable_adjustment_total"] = {
      ordinal = 17,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["action_mailbox_inbound_emails"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["status"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["message_id"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["message_checksum"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_stores"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["url"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_description"] = {
      ordinal = 4,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["meta_keywords"] = {
      ordinal = 5,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["seo_title"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["mail_from_address"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default_currency"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["code"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default"] = {
      ordinal = 10,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 12,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["facebook"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["twitter"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["instagram"] = {
      ordinal = 15,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default_locale"] = {
      ordinal = 16,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["customer_support_email"] = {
      ordinal = 17,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_calculators"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["calculable_type"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["calculable_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["preferences"] = {
      ordinal = 7,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_state_changes"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["previous_state"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stateful_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stateful_type"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["next_state"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 9,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_rule_taxons"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxon_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_rule_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_product_promotion_rules"] = {
    ["product_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_rule_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_customer_returns"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stock_location_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_preferences"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["value"] = {
      ordinal = 2,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["key"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["friendly_id_slugs"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["slug"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["sluggable_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["sluggable_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 50, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["scope"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_product_option_types"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["product_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["option_type_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_trackers"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["analytics_id"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 3,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["engine"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_promotion_rules"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["product_group_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["code"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["preferences"] = {
      ordinal = 9,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_states"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["abbr"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["country_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_inventory_units"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipment_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["pending"] = {
      ordinal = 8,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["line_item_id"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["quantity"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["original_return_item_id"] = {
      ordinal = 11,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_oauth_access_tokens"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["resource_owner_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["application_id"] = {
      ordinal = 3,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {{"spree_oauth_applications", "id"}}
    },
    ["token"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["refresh_token"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["expires_in"] = {
      ordinal = 6,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["revoked_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["scopes"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["previous_refresh_token"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_order_promotions"] = {
    ["order_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promotion_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_payment_methods"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 4,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 5,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["display_on"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["auto_capture"] = {
      ordinal = 10,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["preferences"] = {
      ordinal = 11,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 12,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["store_id"] = {
      ordinal = 13,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_variants"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["sku"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["weight"] = {
      ordinal = 3,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["height"] = {
      ordinal = 4,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["width"] = {
      ordinal = 5,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["depth"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 8, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["discontinue_on"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["is_master"] = {
      ordinal = 9,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["product_id"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cost_price"] = {
      ordinal = 11,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["cost_currency"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["track_inventory"] = {
      ordinal = 14,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_category_id"] = {
      ordinal = 15,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 16,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 17,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_prices"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["variant_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 3,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["currency"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_tax_categories"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["description"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["is_default"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_code"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["active_storage_blobs"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["key"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["filename"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["content_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["metadata"] = {
      ordinal = 5,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["byte_size"] = {
      ordinal = 6,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["checksum"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_return_authorization_reasons"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 3,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["mutable"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_addresses"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["firstname"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["lastname"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address1"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address2"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["city"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zipcode"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["phone"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state_name"] = {
      ordinal = 9,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["alternative_phone"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["company"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state_id"] = {
      ordinal = 12,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["country_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 14,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 15,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 16,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 17,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_stock_movements"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stock_item_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["quantity"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["action"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_type"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["originator_id"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_adjustments"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["adjustable_type"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["adjustable_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["label"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["mandatory"] = {
      ordinal = 8,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["eligible"] = {
      ordinal = 9,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 10,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 11,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included"] = {
      ordinal = 14,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_return_authorizations"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["order_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["memo"] = {
      ordinal = 5,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["stock_location_id"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["return_authorization_reason_id"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_refund_reasons"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 3,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["mutable"] = {
      ordinal = 4,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_log_entries"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_type"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["source_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["details"] = {
      ordinal = 4,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_return_items"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["return_authorization_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["inventory_unit_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["exchange_variant_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["pre_tax_amount"] = {
      ordinal = 7,
      data_type = {"decimal", "decimal", 12, 4},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included_tax_total"] = {
      ordinal = 8,
      data_type = {"decimal", "decimal", 12, 4},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["additional_tax_total"] = {
      ordinal = 9,
      data_type = {"decimal", "decimal", 12, 4},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reception_status"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["acceptance_status"] = {
      ordinal = 11,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["customer_return_id"] = {
      ordinal = 12,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reimbursement_id"] = {
      ordinal = 13,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["acceptance_status_errors"] = {
      ordinal = 14,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["preferred_reimbursement_type_id"] = {
      ordinal = 15,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["override_reimbursement_type_id"] = {
      ordinal = 16,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["resellable"] = {
      ordinal = 17,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_product_properties"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["value"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["product_id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["property_id"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipping_categories"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_stock_locations"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["default"] = {
      ordinal = 5,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address1"] = {
      ordinal = 6,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["address2"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["city"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state_id"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state_name"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["country_id"] = {
      ordinal = 11,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zipcode"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["phone"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["active"] = {
      ordinal = 14,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["backorderable_default"] = {
      ordinal = 15,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["propagate_all_variants"] = {
      ordinal = 16,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["admin_name"] = {
      ordinal = 17,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_products_taxons"] = {
    ["product_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxon_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 4,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_refunds"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["amount"] = {
      ordinal = 3,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["transaction_id"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["refund_reason_id"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["reimbursement_id"] = {
      ordinal = 8,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_option_values"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["position"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["presentation"] = {
      ordinal = 4,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["option_type_id"] = {
      ordinal = 5,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 7,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_orders"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["number"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 32, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["item_total"] = {
      ordinal = 3,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["total"] = {
      ordinal = 4,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state"] = {
      ordinal = 5,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["adjustment_total"] = {
      ordinal = 6,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["user_id"] = {
      ordinal = 7,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["completed_at"] = {
      ordinal = 8,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["bill_address_id"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["ship_address_id"] = {
      ordinal = 10,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_total"] = {
      ordinal = 11,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipment_state"] = {
      ordinal = 12,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["payment_state"] = {
      ordinal = 13,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["email"] = {
      ordinal = 14,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["special_instructions"] = {
      ordinal = 15,
      data_type = {"string_like", "text", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 16,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 17,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["currency"] = {
      ordinal = 18,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["last_ip_address"] = {
      ordinal = 19,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_by_id"] = {
      ordinal = 20,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["shipment_total"] = {
      ordinal = 21,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["additional_tax_total"] = {
      ordinal = 22,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["promo_total"] = {
      ordinal = 23,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["channel"] = {
      ordinal = 24,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["included_tax_total"] = {
      ordinal = 25,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["item_count"] = {
      ordinal = 26,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["approver_id"] = {
      ordinal = 27,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["approved_at"] = {
      ordinal = 28,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["confirmation_delivered"] = {
      ordinal = 29,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["considered_risky"] = {
      ordinal = 30,
      data_type = {"integral", "tinyint", 1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["token"] = {
      ordinal = 31,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["canceled_at"] = {
      ordinal = 32,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["canceler_id"] = {
      ordinal = 33,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["store_id"] = {
      ordinal = 34,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["state_lock_version"] = {
      ordinal = 35,
      data_type = {"integral", "int", 11, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["taxable_adjustment_total"] = {
      ordinal = 36,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["non_taxable_adjustment_total"] = {
      ordinal = 37,
      data_type = {"decimal", "decimal", 10, 2},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["active_storage_attachments"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["record_type"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = true, is_unique = true, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["record_id"] = {
      ordinal = 4,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["blob_id"] = {
      ordinal = 5,
      data_type = {"integral", "bigint", 20, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {{"active_storage_blobs", "id"}}
    },
    ["created_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipping_method_zones"] = {
    ["shipping_method_id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["zone_id"] = {
      ordinal = 2,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["id"] = {
      ordinal = 3,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_shipping_methods"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["display_on"] = {
      ordinal = 3,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["deleted_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", -1, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 5,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 6,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tracking_url"] = {
      ordinal = 7,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["admin_name"] = {
      ordinal = 8,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["tax_category_id"] = {
      ordinal = 9,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["code"] = {
      ordinal = 10,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
  ["spree_prototypes"] = {
    ["id"] = {
      ordinal = 1,
      data_type = {"integral", "int", 11, -1},
      is_indexed = true, is_unique = true, is_pk = true, is_pk_part = true,
      is_not_null = true, is_auto_increment = true, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["name"] = {
      ordinal = 2,
      data_type = {"string_like", "varchar", 255, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = false, is_auto_increment = false, has_default = true,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["created_at"] = {
      ordinal = 3,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
    ["updated_at"] = {
      ordinal = 4,
      data_type = {"datetime_like", "datetime", 6, -1},
      is_indexed = false, is_unique = false, is_pk = false, is_pk_part = false,
      is_not_null = true, is_auto_increment = false, has_default = false,
      is_boolean = false, is_enum = false,
      refers_to = {}
    },
  },
}

return {
  tables = _tables
}