function table.isempty(t)
    if t == nil or next(t) == nil then
        return true
    end
    return false
end

-- timing
local _posix_time = require("posix.time")

local function _timing_start()
    local _start = _posix_time.clock_gettime(1)
    -- last field is for stmt id
    return { _start.tv_sec, _start.tv_nsec, -1 }
end

local function _timing_end(_start)
    local _end = _posix_time.clock_gettime(1)
    _start[1] = _end.tv_sec - _start[1]
    _start[2] = _end.tv_sec - _start[2]
    return _start
end

local DATETIME_FORMAT = "'%d-%02d-%02d %02d:%02d:%02d'"
local DATETIME_PATTERN = "'20[0-9][0-9]%-[0-1][0-9]%-[0-3][0-9] [0-2][0-9]:[0-6][0-9]:[0-6][0-9]'"

local BASE_DATETIME = { 2020, 5, 1, 0, 0, 0 }

local function _int_to_datetime(_i)
    local _date = os.date("*t", _i)
    return { _date.year, _date.month, _date.day, _date.hour, _date.min, _date.sec, 0 }
end

local function _datetime_to_str(_datetime)
    local _ret = string.format(DATETIME_FORMAT, _datetime[1], _datetime[2], _datetime[3], _datetime[4], _datetime[5], _datetime[6])
    return _ret
end

local function _datetime_to_int(_datetime)
    return os.time({ year = _datetime[1], month = _datetime[2], day = _datetime[3], hour = _datetime[4], min = _datetime[5], sec = _datetime[6] })
end

local function _base_datetime()
    return _datetime_to_int(BASE_DATETIME)
end

-- related to runtime
local function _log(_content)
    if sysbench.opt.verbosity ~= 0 then
        io.write(_content)
    end
end

local function _begin(_con, _is_multi_stmt)
    _con:query("begin")
end

local function _commit(_con, _is_multi_stmt)
    _con:query("commit")
end

local function _get_columns(_table_desc)
    local _cols = {}
    for _k in pairs(_table_desc) do
        table.insert(_cols, "`" .. _k .. "`")
    end
    return table.concat(_cols, ", ")
end

local function _rand_seed(_seed)
    math.randomseed(_seed)
end

-- forward the random generator by n step
local function _rand_forward(_n)
    for _ = 1, _n do
        math.random()
    end
end

local function _rand_int(_a, _b)
    local _lower, _upper
    if _b == nil then
        _lower = 0
        _upper = _a
    else
        _lower = _a
        _upper = _b
    end

    return math.random(_a, _b)
end

local function _is_time_str(_val)
    return type(_val) == "string" and string.match(_val, DATETIME_PATTERN)
end

return {
    get_columns = _get_columns,
    log = _log,
    begin = _begin,
    commit = _commit,
    timing_start = _timing_start,
    timing_end = _timing_end,
    rand_seed = _rand_seed,
    rand_forward = _rand_forward,
    rand_int = _rand_int,
    int_to_datetime = _int_to_datetime,
    datetime_to_str = _datetime_to_str,
    is_time_str = _is_time_str,
    base_datetime = _base_datetime
}
